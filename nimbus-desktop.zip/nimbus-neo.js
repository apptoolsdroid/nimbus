/* Nimbus Desktop — "Neo" update: Reminders app (+ Apple Reminders bridge via Shortcuts), iPad app launchers,
   web-app gallery with real icons, Liquid Glass look, icon styles, Notification Center, Spotlight actions.
   Loaded last; starts the desktop. */
"use strict";

/* ================= styles ================= */
document.head.appendChild(html(`<style>
/* ---------- Liquid Glass (Neo) ---------- */
:root[data-neo="1"]{--win-bg:rgba(248,248,252,.74);--side-bg:rgba(255,255,255,.42);--glass:rgba(255,255,255,.42)}
:root[data-neo="1"][data-theme=dark]{--win-bg:rgba(28,28,34,.74);--side-bg:rgba(255,255,255,.07);--glass:rgba(40,40,50,.42)}
:root[data-neo="1"] #menubar{background:transparent;backdrop-filter:none;-webkit-backdrop-filter:none;text-shadow:0 1px 3px rgba(0,0,0,.35)}
:root[data-neo="1"] .win{border-radius:24px;backdrop-filter:blur(50px) saturate(190%);-webkit-backdrop-filter:blur(50px) saturate(190%);
  box-shadow:0 30px 70px rgba(0,0,0,.30),0 2px 8px rgba(0,0,0,.10),inset 0 1px 0 rgba(255,255,255,.65),inset 0 0 0 1px rgba(255,255,255,.22)}
:root[data-neo="1"][data-theme=dark] .win{box-shadow:0 30px 70px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.14),inset 0 0 0 1px rgba(255,255,255,.08)}
:root[data-neo="1"] .win .sidebar{margin:0 0 10px 10px;border-radius:18px;border:1px solid var(--glass-border);box-shadow:inset 0 1px 0 rgba(255,255,255,.5)}
:root[data-neo="1"] .win .toolbar .btn,:root[data-neo="1"] .tb-tools .btn{border-radius:999px}
:root[data-neo="1"] .btn{border-radius:999px}
:root[data-neo="1"] .field{border-radius:12px}
:root[data-neo="1"] #dock{border-radius:32px;background:rgba(255,255,255,.18);box-shadow:0 14px 44px rgba(0,0,0,.25),inset 0 1px 0 rgba(255,255,255,.6),inset 0 -1px 0 rgba(255,255,255,.15)}
:root[data-neo="1"] #dock::before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:linear-gradient(180deg,rgba(255,255,255,.28),rgba(255,255,255,0) 45%)}
:root[data-neo="1"] #dock{position:relative}
:root[data-neo="1"] .widget{border-radius:28px;background:rgba(255,255,255,.58);box-shadow:0 12px 34px rgba(0,0,0,.16),inset 0 1px 0 rgba(255,255,255,.6)}
:root[data-neo="1"][data-theme=dark] .widget{background:rgba(28,28,36,.58);box-shadow:0 12px 34px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.12)}
:root[data-neo="1"] .menu,:root[data-neo="1"] #cc,:root[data-neo="1"] #spotlight .box,:root[data-neo="1"] .toast,:root[data-neo="1"] #modal .dlg{border-radius:20px;box-shadow:var(--shadow),inset 0 1px 0 rgba(255,255,255,.55)}
:root[data-neo="1"] #spotlight .box{border-radius:28px}
/* icon styles */
:root[data-icons="dark"] #dock .ic,:root[data-icons="dark"] #launchpad .ic,:root[data-icons="dark"] .dicon .ic{filter:brightness(.62) contrast(1.25) saturate(1.25)}
:root[data-icons="clear"] #dock .ic,:root[data-icons="clear"] #launchpad .ic,:root[data-icons="clear"] .dicon .ic{filter:grayscale(1) brightness(1.18) contrast(.9);opacity:.82}
:root[data-icons="tinted"] #dock .ic,:root[data-icons="tinted"] #launchpad .ic,:root[data-icons="tinted"] .dicon .ic{filter:grayscale(1) sepia(1) saturate(3.2) hue-rotate(var(--tint-rot,180deg)) brightness(.95)}
/* new wallpapers */
.wp-tahoe{background:radial-gradient(70% 60% at 20% 80%,#27c4c9 0%,transparent 60%),radial-gradient(60% 60% at 80% 20%,#2b6fff 0%,transparent 60%),radial-gradient(50% 45% at 60% 75%,#9ae6ff 0%,transparent 60%),linear-gradient(170deg,#0b2a5a,#0e4a7a 55%,#07203f)}
.wp-citrus{background:radial-gradient(60% 60% at 25% 30%,#fff07a 0%,transparent 60%),radial-gradient(60% 60% at 80% 70%,#8be38f 0%,transparent 60%),radial-gradient(45% 45% at 70% 25%,#ffd25a 0%,transparent 60%),linear-gradient(160deg,#f6ffd9,#d7f5b9 50%,#b6e59a)}
.wp-blush{background:radial-gradient(60% 60% at 25% 25%,#ffc3d8 0%,transparent 60%),radial-gradient(60% 60% at 75% 75%,#c9b6ff 0%,transparent 60%),radial-gradient(45% 45% at 70% 30%,#ffd9c2 0%,transparent 60%),linear-gradient(160deg,#fff1f5,#f7dbe8 50%,#e7d6f7)}
.wp-indigo{background:radial-gradient(60% 60% at 20% 70%,#6c63ff 0%,transparent 60%),radial-gradient(55% 55% at 80% 25%,#3b2aa8 0%,transparent 60%),radial-gradient(40% 40% at 55% 50%,#a399ff 0%,transparent 60%),linear-gradient(170deg,#120d3a,#211a63 55%,#0b0828)}
/* ---------- Reminders ---------- */
.rm{flex:1;display:flex;min-width:0;min-height:0}
.rm .sidebar{width:250px;display:flex;flex-direction:column}
.rm .smart{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:6px 4px 10px}
.rm .tile{border-radius:14px;padding:9px 10px;background:var(--field);cursor:pointer;display:flex;flex-direction:column;gap:6px}
.rm .tile.act{outline:2px solid var(--accent)}
.rm .tile .tr{display:flex;justify-content:space-between;align-items:center}
.rm .tile .c{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff}
.rm .tile .c svg{width:15px;height:15px}
.rm .tile b{font-size:20px}.rm .tile span{font-size:12px;font-weight:600;color:var(--text2)}
.rm .li{display:flex;align-items:center;gap:9px;padding:6px 8px;border-radius:8px;cursor:default;font-size:13px}
.rm .li.act{background:var(--hover);font-weight:600}
.rm .li .lc{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;flex:none}
.rm .li .lc svg{width:12px;height:12px}
.rm .li .n{margin-left:auto;color:var(--text3);font-size:12px}
.rm .main{flex:1;display:flex;flex-direction:column;min-width:0}
.rm .rh{display:flex;align-items:flex-end;justify-content:space-between;padding:18px 24px 8px}
.rm .rh h1{margin:0;font-size:28px;font-weight:800}
.rm .rh .cnt{font-size:28px;font-weight:300;color:var(--text3)}
.rm .items{flex:1;overflow:auto;padding:0 14px 20px}
.rm .it{display:flex;gap:10px;padding:9px 10px;border-bottom:1px solid var(--hair);align-items:flex-start}
.rm .it .ck{width:20px;height:20px;border-radius:50%;border:2px solid var(--text3);flex:none;margin-top:1px;cursor:pointer;position:relative}
.rm .it.done .ck{background:var(--lc,var(--accent));border-color:var(--lc,var(--accent))}
.rm .it.done .ck::after{content:"";position:absolute;inset:4px;border-radius:50%;background:#fff}
.rm .it .bd{flex:1;min-width:0}
.rm .it .t{font-size:14px;outline:none;-webkit-user-select:text;user-select:text;word-break:break-word}
.rm .it.done .t{color:var(--text3)}
.rm .it .meta{font-size:12px;color:var(--text3);margin-top:2px;display:flex;gap:8px;flex-wrap:wrap}
.rm .it .meta .od{color:#ff3b30}
.rm .it .pr{color:var(--lc,var(--accent));font-weight:800;margin-right:4px}
.rm .it .fl{color:#ff9f0a}
.rm .it .inf{opacity:0;border:0;background:none;color:var(--accent);font-size:16px;padding:0 4px}
.rm .it:hover .inf,.rm .it.sel .inf{opacity:1}
.rm .newrow{display:flex;gap:10px;align-items:center;padding:10px;color:var(--text3)}
.rm .newrow input{flex:1;border:0;background:none;outline:none;font-size:14px;padding:4px 0}
.rm .hint2{font-size:11.5px;color:var(--text3);padding:2px 24px 10px}
.rm .bar2{display:flex;gap:6px;padding:8px 14px;border-top:1px solid var(--hair);flex-wrap:wrap}
.w-rem .ri{display:flex;gap:8px;align-items:flex-start;padding:4px 0;font-size:12.5px}
.w-rem .ri .ck{width:15px;height:15px;border-radius:50%;border:1.5px solid var(--text3);flex:none;margin-top:1px;cursor:pointer}
.w-rem .ri small{display:block;font-size:11px;color:var(--text3)}.w-rem .ri small.od{color:#ff3b30}
/* ---------- Notification Center ---------- */
#nc{position:fixed;right:10px;top:calc(var(--menubar-h) + var(--safe-top) + 6px);bottom:calc(var(--dock-size) + 30px);width:350px;z-index:9400;display:none;flex-direction:column;gap:10px;overflow:auto;padding:4px 2px 10px}
#nc.show{display:flex;animation:ncin .25s ease}
@keyframes ncin{from{transform:translateX(30px);opacity:0}}
#nc .card{border-radius:22px;padding:12px 14px;background:var(--glass-strong);color:var(--text);box-shadow:0 10px 30px rgba(0,0,0,.2),inset 0 1px 0 rgba(255,255,255,.5);
  backdrop-filter:blur(40px) saturate(180%);-webkit-backdrop-filter:blur(40px) saturate(180%);border:1px solid var(--glass-border)}
#nc h4{margin:0 0 8px;font-size:12px;color:var(--text2);text-transform:uppercase;letter-spacing:.04em;display:flex;justify-content:space-between}
#nc .nt{display:flex;gap:10px;padding:7px 0;border-top:1px solid var(--hair)}
#nc .nt:first-of-type{border-top:0}
#nc .nt .ic{width:30px;height:30px;flex:none}
#nc .nt b{font-size:13px;display:block}#nc .nt span{font-size:12.5px;color:var(--text2)}#nc .nt small{margin-left:auto;font-size:11px;color:var(--text3);white-space:nowrap}
#nc .big{font-size:40px;font-weight:700;line-height:1}
/* ---------- iPad apps folder ---------- */
#launchpad .lp.folder .ic{background:rgba(255,255,255,.22);border-radius:20px;padding:8px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:3px;width:84px;height:84px;box-sizing:border-box}
#launchpad .lp.folder .ic i{border-radius:5px;display:block}
#launchpad .lp-folder-head{color:#fff;font-size:26px;font-weight:700;margin-top:30px;display:flex;align-items:center;gap:14px;text-shadow:0 1px 4px rgba(0,0,0,.4)}
#launchpad .lp-folder-head button{border:0;background:rgba(255,255,255,.2);color:#fff;border-radius:999px;padding:6px 14px;font-size:13px}
.fav-ic svg{display:block}
/* gallery */
.gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}
.gal .gi{display:flex;gap:10px;align-items:center;background:var(--field);border-radius:14px;padding:10px}
.gal .gi .ic{width:42px;height:42px;flex:none}
.gal .gi .grow{flex:1;min-width:0}.gal .gi b{font-size:13px;display:block}.gal .gi small{font-size:11.5px;color:var(--text3);display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gal .gi .btn{padding:5px 12px;font-size:12px}
.gal-cat{font-size:12px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.05em;margin:14px 0 6px}
</style>`));

/* ================= small helpers ================= */
const DAY=864e5;
const startOfDay=t=>{const d=new Date(t);d.setHours(0,0,0,0);return d.getTime()};
const fmtDue=(r)=>{if(!r.due)return "";const d=new Date(r.due),now=Date.now();const day=startOfDay(r.due),today=startOfDay(now);
  const t=r.allDay?"":" "+d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"});
  if(day===today)return "Today"+t;if(day===today+DAY)return "Tomorrow"+t;if(day===today-DAY)return "Yesterday"+t;
  if(Math.abs(day-today)<6*DAY)return d.toLocaleDateString([], {weekday:"long"})+t;return d.toLocaleDateString([], {day:"numeric",month:"short",year:d.getFullYear()===new Date().getFullYear()?undefined:"numeric"})+t};
const isOverdue=r=>!r.done&&r.due&&(r.allDay?startOfDay(r.due)<startOfDay(Date.now()):r.due<Date.now());
/* natural language: "Call mum tomorrow 5pm !!", "pay rent friday", "dentist 20 nov 9:30", "stretch in 2 hours" */
function parseNatural(text){let s=" "+text+" ",due=null,allDay=true,prio=0,flag=false;const now=new Date();
  const m1=s.match(/\s(!{1,3})\s/);if(m1){prio=m1[1].length;s=s.replace(m1[0]," ")}
  if(/\s#?flag(ged)?\s/i.test(s)){flag=true;s=s.replace(/\s#?flag(ged)?\s/i," ")}
  let base=null;
  const rel=s.match(/\sin\s(\d+)\s(min(ute)?s?|hours?|hrs?|days?|weeks?)\s/i);
  if(rel){const n=+rel[1],u=rel[2].toLowerCase();const ms=u.startsWith("min")?6e4:u.startsWith("h")?36e5:u.startsWith("d")?DAY:7*DAY;due=Date.now()+n*ms;allDay=!(u.startsWith("min")||u.startsWith("h"));s=s.replace(rel[0]," ")}
  const dayWords=s.match(/\s(today|tonight|tomorrow|tmrw|next week|this weekend|(?:next\s)?(?:mon|tues?|wed(?:nes)?|thu(?:rs)?|fri|sat(?:ur)?|sun)(?:day)?)\s/i);
  if(dayWords&&!due){const w=dayWords[1].toLowerCase();base=new Date(now);base.setHours(0,0,0,0);
    if(w==="tomorrow"||w==="tmrw")base.setDate(base.getDate()+1);else if(w==="tonight"){base.setHours(20,0,0,0);allDay=false}
    else if(w==="next week"){base.setDate(base.getDate()+((8-base.getDay())%7||7))}else if(w==="this weekend"){base.setDate(base.getDate()+((6-base.getDay()+7)%7))}
    else if(w!=="today"){const names=["sun","mon","tue","wed","thu","fri","sat"];const k=names.findIndex(n=>w.replace("next ","").startsWith(n));let add=(k-base.getDay()+7)%7||7;if(w.startsWith("next "))add+=add<7?7:0;base.setDate(base.getDate()+add)}
    s=s.replace(dayWords[0]," ")}
  const dm=s.match(/\s(\d{1,2})(?:st|nd|rd|th)?\s(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s/i)||s.match(/\s(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s(\d{1,2})(?:st|nd|rd|th)?\s/i);
  if(dm&&!due&&!base){const mons=["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];const isFirstNum=/^\d/.test(dm[1]);const day=+(isFirstNum?dm[1]:dm[2]),mon=mons.indexOf((isFirstNum?dm[2]:dm[1]).toLowerCase().slice(0,3));
    base=new Date(now.getFullYear(),mon,day);if(base.getTime()<startOfDay(now))base.setFullYear(base.getFullYear()+1);s=s.replace(dm[0]," ")}
  const tm=s.match(/\s(?:at\s)?(\d{1,2})(?::(\d{2}))?\s?(am|pm)\s/i)||s.match(/\sat\s(\d{1,2}):(\d{2})\s/i)||s.match(/\s(\d{1,2}):(\d{2})\s/);
  if(tm&&!rel){let h=+tm[1],mi=+(tm[2]||0);const ap=(tm[3]||"").toLowerCase();if(ap==="pm"&&h<12)h+=12;if(ap==="am"&&h===12)h=0;
    if(!base){base=new Date(now);base.setHours(0,0,0,0);const cand=new Date(base);cand.setHours(h,mi);if(cand<now)base.setDate(base.getDate()+1)}
    base.setHours(h,mi,0,0);allDay=false;s=s.replace(tm[0]," ")}
  if(base&&!due){due=base.getTime();if(allDay){const d=new Date(due);d.setHours(9,0,0,0);due=d.getTime()}}
  return {title:s.replace(/\s+/g," ").replace(/\s(on|at|by)$/i,"").trim()||text.trim(),due,allDay,prio,flag}}

/* ================= Reminders data ================= */
const RCOL=["#0a84ff","#ff3b30","#ff9f0a","#ffd60a","#30d158","#64d2ff","#bf5af2","#ff375f","#a2845e","#8e8e93"];
const RM={lists:[],items:[],ready:null,
  load(){return RM.ready||(RM.ready=(async()=>{const d=await DB.get("reminders",null);
    if(d){RM.lists=d.lists;RM.items=d.items}else{RM.lists=[{id:"rem",name:"Reminders",color:"#0a84ff"},{id:"apple",name:"Apple Reminders",color:"#ff9f0a"}];
      RM.items=(S.todos||[]).map(t=>({id:uid(),list:"rem",title:t.t,done:!!t.d,due:null,allDay:true,prio:0,flag:false,notes:"",created:Date.now()}));RM.save()}})())},
  save(){DB.set("reminders",{lists:RM.lists,items:RM.items});RM.changed()},
  listeners:new Set(),changed(){RM.listeners.forEach(f=>{try{f()}catch(e){}});Widgets.rem&&Widgets.rem()},
  add(o){const r={id:uid(),list:o.list||RM.lists[0].id,title:o.title,done:false,due:o.due||null,allDay:o.allDay!==false,prio:o.prio||0,flag:!!o.flag,notes:o.notes||"",created:Date.now(),alerted:false};RM.items.push(r);RM.save();return r},
  addNatural(text,list){const p=parseNatural(text);return RM.add({...p,list})},
  toggle(r){r.done=!r.done;r.doneAt=r.done?Date.now():null;RM.save()},
  smart:{today:r=>!r.done&&r.due&&startOfDay(r.due)<=startOfDay(Date.now()),scheduled:r=>!r.done&&!!r.due,all:r=>!r.done,flagged:r=>!r.done&&r.flag,completed:r=>r.done},
  count(k){return RM.items.filter(RM.smart[k]).length},
  sort(a,b){if(a.done!==b.done)return a.done?1:-1;if(!!a.due!==!!b.due)return a.due?-1:1;if(a.due&&b.due&&a.due!==b.due)return a.due-b.due;return a.created-b.created}
};
/* alerts while Nimbus is open */
async function remindAlert(r){UI.toast("Reminder",r.title+(r.due?" · "+fmtDue(r):""),"reminders");try{const reg=await navigator.serviceWorker?.ready;if(reg&&Notification.permission==="granted")reg.showNotification(r.title,{body:"Reminder · "+fmtDue(r),icon:"icon-192.png",tag:r.id})}catch(e){}}
setInterval(()=>{if(!RM.items.length)return;const now=Date.now();let ch=false;
  RM.items.forEach(r=>{if(!r.done&&r.due&&!r.allDay&&!r.alerted&&r.due<=now&&now-r.due<6*36e5){r.alerted=true;ch=true;remindAlert(r)}});if(ch)RM.save()},20000);

/* ================= Apple Reminders bridge (Shortcuts) ================= */
const SC_GET="Nimbus Get Reminders",SC_ADD="Nimbus Add Reminder";
const Bridge={
  sendToApple(r){const text=r.title+(r.due?" | "+new Date(r.due).toISOString():"");openLink(`shortcuts://run-shortcut?name=${enc(SC_ADD)}&input=text&text=${enc(text)}`);UI.toast("Sending to Apple Reminders","Via your “"+SC_ADD+"” shortcut","reminders")},
  startImport(){Bridge.waiting=Date.now();openLink(`shortcuts://run-shortcut?name=${enc(SC_GET)}`)},
  async paste(){let t=null;try{t=await navigator.clipboard.readText()}catch(e){}
    if(!t){const r=await UI.dialog({title:"Paste your reminders",text:"Tap the box, choose Paste, then Import.",fields:[{ph:"Paste here"}],ok:"Import"});t=r&&r[0]}
    if(!t)return;Bridge.importText(t)},
  importText(t){const lines=t.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);let n=0;
    for(const l of lines){const [title,dueS,listName]=l.split(/\s*\|\s*/);if(!title)continue;
      let list=RM.lists.find(x=>listName&&x.name.toLowerCase()===listName.toLowerCase());if(!list&&listName){list={id:uid(),name:listName,color:RCOL[RM.lists.length%RCOL.length]};RM.lists.push(list)}if(!list)list=RM.lists.find(x=>x.id==="apple")||RM.lists[0];
      const due=dueS?Date.parse(dueS):NaN;
      if(RM.items.some(x=>x.list===list.id&&x.title===title&&!x.done))continue;
      RM.items.push({id:uid(),list:list.id,title,done:false,due:isNaN(due)?null:due,allDay:isNaN(due)?true:!/T\d\d:\d\d/.test(dueS)||/T00:00/.test(dueS),prio:0,flag:false,notes:"",created:Date.now(),src:"apple"});n++}
    RM.save();UI.toast("Imported from Apple Reminders",n?`${n} new reminder${n>1?"s":""}`:"Everything was already here","reminders")},
  help(host){const wrap=html(`<div class="sheet-wrap"><div class="sheet setup-sheet" style="width:min(560px,94%)"><h3>Connect Apple Reminders</h3>
    <p class="muted" style="font-size:12.5px;margin:0 0 8px">Websites can't read the Reminders app directly, but the iPad's <b>Shortcuts</b> app can pass them to Nimbus. Make these two small shortcuts once (2 minutes each):</p>
    <b style="font-size:13px">1 · “${SC_GET}” (Apple → Nimbus)</b><ol>
      <li>Shortcuts app → <b>+</b> → name it exactly <code>${SC_GET}</code>.</li>
      <li>Add <b>Find All Reminders</b> → Add Filter → <i>Is Not Completed</i>.</li>
      <li>Add <b>Repeat with Each</b>. Inside it add <b>Text</b> and type: <code>Repeat Item</code> <code>|</code> <code>Due Date</code> <code>|</code> <code>List</code> — insert each as a variable (tap Repeat Item → choose Title / Due Date / List; set Due Date format to <b>ISO 8601</b>).</li>
      <li>After the repeat, add <b>Combine Text</b> (with New Lines) → <b>Copy to Clipboard</b>.</li></ol>
    <b style="font-size:13px">2 · “${SC_ADD}” (Nimbus → Apple)</b><ol>
      <li>New shortcut named exactly <code>${SC_ADD}</code>, turn on <b>Receive Text input</b>.</li>
      <li>Add <b>Split Text</b> (Shortcut Input) by Custom <code>|</code>.</li>
      <li>Add <b>Add New Reminder</b>: title = <i>First Item</i> from Split Text; turn on Alert and set it to <i>Last Item</i> (optional).</li></ol>
    <p class="muted" style="font-size:12px">Then in Nimbus Reminders tap <b>Import from Apple</b>: Shortcuts runs, then switch back to Nimbus and tap <b>Paste reminders</b>. Use <b>Send to Apple Reminders</b> on any reminder to copy it the other way.</p>
    <div class="acts"><button class="btn primary" data-x>Done</button></div></div></div>`);host.appendChild(wrap);$("[data-x]",wrap).onclick=()=>wrap.remove()}
};
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&Bridge.waiting&&Date.now()-Bridge.waiting<5*6e4){Bridge.waiting=0;
  const t=html(`<div class="toast" style="align-items:center">${ICON.reminders()}<div style="flex:1"><b>Back from Shortcuts</b><span>Tap to import your Apple reminders</span></div><button class="btn primary" style="padding:6px 12px">Paste reminders</button></div>`);
  $("#toasts").appendChild(t);$("button",t).onclick=()=>{t.remove();Bridge.paste()};setTimeout(()=>t.remove(),30000)}});

/* ================= icons ================= */
Object.assign(ICON,{
  reminders:()=>squircle("rm","#ffffff","#e9e9ef",`${[0,1,2].map(i=>`<circle cx="19" cy="${21+i*11}" r="4.2" fill="${["#0a84ff","#ff3b30","#ff9f0a"][i]}"/><rect x="27" y="${19+i*11}" width="20" height="3.6" rx="1.8" fill="#c7c7cf"/>`).join("")}`),
  ipadfolder:()=>`<svg class="ic" viewBox="0 0 64 64"><rect x="3" y="3" width="58" height="58" rx="16" fill="rgba(255,255,255,.25)"/>${[0,1,2].map(r=>[0,1,2].map(c=>`<rect x="${12+c*14}" y="${12+r*14}" width="11" height="11" rx="3" fill="${["#30d158","#0a84ff","#ff9f0a","#ff375f","#bf5af2","#64d2ff","#ffd60a","#8e8e93","#ff3b30"][r*3+c]}"/>`).join("")).join("")}</svg>`
});
function faviconIcon(id,name,url,color){const host=hostOf(url);return ()=>`<span class="ic fav-ic" style="display:block;position:relative">${letterIcon("f"+id,name||host,color||favColor(host))().replace('class="ic"','class="ic" style="width:100%;height:100%"')}<img src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&amp;sz=128" alt="" onerror="this.remove()" onload="if(this.naturalWidth<32)this.remove()" style="position:absolute;inset:3%;width:94%;height:94%;border-radius:23%;background:#fff;object-fit:contain;padding:14%;box-sizing:border-box;box-shadow:inset 0 0 0 1px rgba(0,0,0,.06)"></span>`}

/* ================= Reminders app ================= */
const SMART=[["today","Today","#0a84ff",`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M9 3v4M15 3v4"/></svg>`],
  ["scheduled","Scheduled","#ff3b30",`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg>`],
  ["all","All","#3a3a3c",`<svg viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="5" width="16" height="3" rx="1.5"/><rect x="4" y="11" width="16" height="3" rx="1.5"/><rect x="4" y="17" width="16" height="3" rx="1.5"/></svg>`],
  ["flagged","Flagged","#ff9f0a",`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 3h2v18H5zM8 4h11l-2.5 4L19 12H8z"/></svg>`]];
const LISTGLYPH=`<svg viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="5" width="16" height="3" rx="1.5"/><rect x="4" y="11" width="16" height="3" rx="1.5"/><rect x="4" y="17" width="16" height="3" rx="1.5"/></svg>`;
APPS.reminders={name:"Reminders",icon:"reminders",w:880,h:620,single:true,
  create(w,opts){
    const st={view:opts.view||"today",sel:null,showDone:false};
    const draw=async()=>{await RM.load();const L=RM.lists;const list=L.find(l=>l.id===st.view);const smart=RM.smart[st.view];
      let items=list?RM.items.filter(r=>r.list===list.id&&(st.showDone||!r.done)):RM.items.filter(smart||RM.smart.all);
      if(st.view==="completed")items=RM.items.filter(r=>r.done).sort((a,b)=>(b.doneAt||0)-(a.doneAt||0));else items.sort(RM.sort);
      const title=list?list.name:(SMART.find(s=>s[0]===st.view)||[0,"Completed"])[1];const color=list?list.color:(SMART.find(s=>s[0]===st.view)||[0,0,"#8e8e93"])[2];
      w.setTitle(title);
      w.body.innerHTML=`<div class="rm"><div class="sidebar"><div class="smart">${SMART.map(([k,n,c,g])=>`<div class="tile ${st.view===k?"act":""}" data-v="${k}"><div class="tr"><div class="c" style="background:${c}">${g}</div><b>${RM.count(k)}</b></div><span>${n}</span></div>`).join("")}
          <div class="tile ${st.view==="completed"?"act":""}" data-v="completed" style="grid-column:span 2;flex-direction:row;justify-content:space-between;align-items:center"><span>✓ Completed</span><b style="font-size:15px">${RM.count("completed")}</b></div></div>
          <h5>My Lists</h5>${L.map(l=>`<div class="li ${st.view===l.id?"act":""}" data-v="${l.id}"><span class="lc" style="background:${l.color}">${LISTGLYPH}</span>${esc(l.name)}<span class="n">${RM.items.filter(r=>r.list===l.id&&!r.done).length}</span></div>`).join("")}
          <div style="flex:1"></div><button class="btn addacc" data-addlist>${SVG.plus} Add List</button><button class="btn addacc" data-apple style="margin-top:0">${ICON.reminders().replace('class="ic"','class="ic" width="16" height="16"')} Apple Reminders…</button></div>
        <div class="main"><div class="rh"><h1 style="color:${color}">${esc(title)}</h1><span class="cnt">${items.filter(r=>!r.done).length}</span></div>
          <div class="items" data-items>${items.map(r=>itemHTML(r,!list)).join("")||`<div class="empty">${st.view==="today"?"Nothing due today 🎉":"No reminders"}</div>`}
            ${st.view!=="completed"?`<div class="newrow"><span style="font-size:18px">＋</span><input data-new placeholder="New reminder — try “Call mum tomorrow 5pm !!”" enterkeyhint="done"></div>`:""}</div>
          <div class="hint2" data-preview></div>
          <div class="bar2">${list?`<button class="btn" data-showdone>${st.showDone?"Hide":"Show"} Completed</button><button class="btn" data-editlist>Edit List</button>`:""}
            <button class="btn primary" data-import>⟳ Sync with Apple</button><span class="muted" data-syncst style="font-size:11.5px"></span>
            ${"Notification" in window&&Notification.permission!=="granted"&&!SANDBOXED?`<button class="btn" data-notif>🔔 Allow alerts</button>`:""}</div></div></div>`;
      $$("[data-v]",w.body).forEach(e=>e.onclick=()=>{st.view=e.dataset.v;draw()});
      $("[data-addlist]",w.body).onclick=async()=>{const n=await UI.prompt("New List","My List");if(n){const l={id:uid(),name:n,color:RCOL[L.length%RCOL.length]};RM.lists.push(l);st.view=l.id;RM.save()}};
      $("[data-apple]",w.body).onclick=()=>Bridge.help(w.el);
      $("[data-import]",w.body).onclick=()=>{if(SANDBOXED)return Bridge.help(w.el);window.RSync?RSync.sync(true):Bridge.startImport()};window.RSync&&RSync.status(w.body);
      const nb=$("[data-notif]",w.body);if(nb)nb.onclick=async()=>{try{const p=await Notification.requestPermission();UI.toast("Alerts",p==="granted"?"Nimbus will alert you while it's open":"Not allowed — you can change this in iPad Settings › Notifications","reminders")}catch(e){}draw()};
      const sd=$("[data-showdone]",w.body);if(sd)sd.onclick=()=>{st.showDone=!st.showDone;draw()};
      const el=$("[data-editlist]",w.body);if(el)el.onclick=()=>listSheet(list);
      const ni=$("[data-new]",w.body);if(ni){const pv=$("[data-preview]",w.body);
        ni.oninput=()=>{const p=parseNatural(ni.value);pv.textContent=ni.value&&(p.due||p.prio||p.flag)?`→ “${p.title}”${p.due?" · "+fmtDue(p):""}${p.prio?" · priority "+"!".repeat(p.prio):""}${p.flag?" · flagged":""}`:""};
        ni.onkeydown=e=>{if(e.key==="Enter"&&ni.value.trim()){const p=parseNatural(ni.value);const target=list?list.id:RM.lists[0].id;
          if(st.view==="today"&&!p.due){const d=new Date();d.setHours(9,0,0,0);p.due=d.getTime();p.allDay=true}if(st.view==="flagged")p.flag=true;
          RM.add({...p,list:target});setTimeout(()=>{const n=$("[data-new]",w.body);n&&n.focus()},30)}};
        if(opts.focusNew)setTimeout(()=>ni.focus(),80)}
      $$(".it",w.body).forEach(row=>{const r=RM.items.find(x=>x.id===row.dataset.id);if(!r)return;
        $(".ck",row).onclick=()=>{RM.toggle(r)};
        const t=$(".t",row);t.onblur=()=>{const v=t.textContent.trim();if(v&&v!==r.title){r.title=v;RM.save()}};t.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();t.blur()}};
        $(".inf",row).onclick=()=>itemSheet(r);
        longPress(row,e=>UI.menu([{label:"Details…",action:()=>itemSheet(r)},{label:r.flag?"Unflag":"Flag",action:()=>{r.flag=!r.flag;RM.save()}},
          {label:"Due Today",action:()=>{const d=new Date();d.setHours(9,0,0,0);r.due=d.getTime();r.allDay=true;r.alerted=false;RM.save()}},{label:"Due Tomorrow",action:()=>{const d=new Date();d.setDate(d.getDate()+1);d.setHours(9,0,0,0);r.due=d.getTime();r.allDay=true;r.alerted=false;RM.save()}},
          {label:"Send to Apple Reminders",action:()=>Bridge.sendToApple(r)},"-",{label:"Delete",action:()=>{RM.items=RM.items.filter(x=>x!==r);RM.save()}}],e.clientX,e.clientY))})};
    const itemHTML=(r,showList)=>{const l=RM.lists.find(x=>x.id===r.list)||{color:"#8e8e93",name:""};
      return `<div class="it ${r.done?"done":""}" data-id="${r.id}" style="--lc:${l.color}"><div class="ck"></div><div class="bd"><div class="t" contenteditable="true">${r.prio?`<span class="pr">${"!".repeat(r.prio)}</span>`:""}${esc(r.title)}</div>
        <div class="meta">${r.due?`<span class="${isOverdue(r)?"od":""}">${esc(fmtDue(r))}</span>`:""}${showList?`<span style="color:${l.color}">${esc(l.name)}</span>`:""}${r.notes?`<span>${esc(r.notes.slice(0,60))}</span>`:""}${r.flag?`<span class="fl">⚑</span>`:""}</div></div><button class="inf" title="Details">ⓘ</button></div>`};
    const itemSheet=r=>{const d=r.due?new Date(r.due):null;const pad=n=>String(n).padStart(2,"0");
      const wrap=html(`<div class="sheet-wrap"><div class="sheet"><h3>Details</h3>
        <div class="frow"><label>Title</label><input class="field" data-t value="${esc(r.title)}"></div>
        <div class="frow" style="align-items:start"><label style="padding-top:8px">Notes</label><textarea class="field" data-n rows="3">${esc(r.notes||"")}</textarea></div>
        <div class="frow"><label>Date</label><input class="field" type="date" data-d value="${d?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`:""}"></div>
        <div class="frow"><label>Time</label><input class="field" type="time" data-tm value="${d&&!r.allDay?`${pad(d.getHours())}:${pad(d.getMinutes())}`:""}"></div>
        <div class="frow"><label>List</label><select data-l>${RM.lists.map(l=>`<option value="${l.id}" ${l.id===r.list?"selected":""}>${esc(l.name)}</option>`).join("")}</select></div>
        <div class="frow"><label>Priority</label><select data-p>${["None","Low !","Medium !!","High !!!"].map((p,i)=>`<option value="${i}" ${r.prio===i?"selected":""}>${p}</option>`).join("")}</select></div>
        <div class="frow"><label>Flag</label><div class="toggle ${r.flag?"on":""}" data-f></div></div>
        <div class="acts"><button class="btn" data-del style="color:#ff3b30;margin-right:auto">Delete</button><button class="btn" data-apple>To Apple Reminders</button><button class="btn" data-c>Cancel</button><button class="btn primary" data-ok>Done</button></div></div></div>`);
      w.el.appendChild(wrap);const q=k=>$(`[data-${k}]`,wrap);let flag=r.flag;q("f").onclick=()=>{flag=!flag;q("f").classList.toggle("on",flag)};
      q("c").onclick=()=>wrap.remove();q("del").onclick=()=>{RM.items=RM.items.filter(x=>x!==r);RM.save();wrap.remove()};q("apple").onclick=()=>Bridge.sendToApple(r);
      q("ok").onclick=()=>{r.title=q("t").value.trim()||r.title;r.notes=q("n").value;r.list=q("l").value;r.prio=+q("p").value;r.flag=flag;
        const dv=q("d").value,tv=q("tm").value;if(dv){const [y,m,dd]=dv.split("-").map(Number);const nd=new Date(y,m-1,dd,9,0);if(tv){const [h,mi]=tv.split(":").map(Number);nd.setHours(h,mi);r.allDay=false}else r.allDay=true;r.due=nd.getTime();r.alerted=false}else{r.due=null}
        RM.save();wrap.remove()}};
    const listSheet=l=>{const wrap=html(`<div class="sheet-wrap"><div class="sheet"><h3>Edit List</h3><div class="frow"><label>Name</label><input class="field" data-n value="${esc(l.name)}"></div>
        <div class="frow"><label>Colour</label><div class="sw2">${RCOL.map(c=>`<i style="background:${c}" data-c="${c}" class="${l.color===c?"on":""}"></i>`).join("")}</div></div>
        <div class="acts"><button class="btn" data-del style="color:#ff3b30;margin-right:auto" ${RM.lists.length<2?"disabled":""}>Delete List</button><button class="btn" data-x>Cancel</button><button class="btn primary" data-ok>Done</button></div></div></div>`);
      w.el.appendChild(wrap);let col=l.color;$$(".sw2 i",wrap).forEach(i=>i.onclick=()=>{$$(".sw2 i",wrap).forEach(x=>x.classList.remove("on"));i.classList.add("on");col=i.dataset.c});
      $("[data-x]",wrap).onclick=()=>wrap.remove();$("[data-ok]",wrap).onclick=()=>{l.name=$("[data-n]",wrap).value.trim()||l.name;l.color=col;RM.save();wrap.remove()};
      $("[data-del]",wrap).onclick=async()=>{if(await UI.confirm(`Delete “${l.name}”?`,"All its reminders will be deleted too.","Delete",true)){RM.items=RM.items.filter(r=>r.list!==l.id);RM.lists=RM.lists.filter(x=>x!==l);st.view="today";RM.save();wrap.remove()}}};
    RM.listeners.add(draw);draw();
    return {close(){RM.listeners.delete(draw)},reopenRem(o){if(o&&o.view){st.view=o.view}if(o&&o.focusNew)opts.focusNew=true;draw()}}},
  reopen(w,o){w.hooks.reopenRem&&w.hooks.reopenRem(o)}
};

/* ---------- Reminders desktop widget (replaces the simple one) ---------- */
const _wRender3=Widgets.render;
Widgets.render=async function(){await _wRender3.call(Widgets);await RM.load();const old=$("#wg-todos");if(!old)return;const wg=old.closest(".widget");wg.classList.add("w-rem");
  wg.innerHTML=`<h4>Reminders <span style="display:flex;gap:6px;align-items:center"><span class="muted" id="wg-rc"></span><span class="pill" style="cursor:pointer" data-ro>Open</span></span></h4><div id="wg-rlist"></div><input class="w-input" id="wg-rin" placeholder="New reminder… e.g. “pay rent friday”" enterkeyhint="done">`;
  $("[data-ro]",wg).onclick=()=>WM.open("reminders",{view:"today"});
  $("#wg-rin").onkeydown=e=>{if(e.key==="Enter"&&e.target.value.trim()){const r=RM.addNatural(e.target.value.trim());e.target.value="";UI.toast("Reminder added",r.title+(r.due?" · "+fmtDue(r):""),"reminders")}};
  Widgets.rem()};
Widgets.todos=function(){Widgets.rem&&Widgets.rem()};
Widgets.rem=function(){const el=$("#wg-rlist");if(!el)return;const due=RM.items.filter(r=>!r.done).sort(RM.sort);const today=due.filter(RM.smart.today);const show=(today.length?today:due).slice(0,5);
  $("#wg-rc").textContent=today.length?`${today.length} today`:due.length?`${due.length} open`:"";
  el.innerHTML=show.map(r=>{const l=RM.lists.find(x=>x.id===r.list)||{color:"#8e8e93"};return `<div class="ri" data-id="${r.id}"><div class="ck" style="border-color:${l.color}"></div><div style="min-width:0;flex:1"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${r.prio?`<b style="color:${l.color}">${"!".repeat(r.prio)}</b> `:""}${esc(r.title)}</div>${r.due?`<small class="${isOverdue(r)?"od":""}">${esc(fmtDue(r))}</small>`:""}</div></div>`}).join("")||`<div class="muted" style="font-size:12px">All done 🎉</div>`;
  $$(".ri",el).forEach(row=>{const r=RM.items.find(x=>x.id===row.dataset.id);$(".ck",row).onclick=()=>{$(".ck",row).style.background="var(--accent)";setTimeout(()=>RM.toggle(r),350)};
    row.ondblclick=()=>WM.open("reminders",{view:"today"});longPress(row,e=>UI.menu([{label:"Open Reminders",action:()=>WM.open("reminders",{view:"today"})},{label:"Send to Apple Reminders",action:()=>Bridge.sendToApple(r)},{label:"Delete",action:()=>{RM.items=RM.items.filter(x=>x!==r);RM.save()}}],e.clientX,e.clientY))})};

/* ================= iPad apps (launch real apps) ================= */
const IPAD_APPS=[
  ["Messages","sms:","#30d158"],["Mail","message://","#0a84ff"],["FaceTime","facetime://","#34c759"],["Photos","photos-redirect://","#ff9f0a"],["Calendar","calshow://","#ff3b30"],["Reminders","x-apple-reminderkit://","#ff9500"],
  ["Notes","mobilenotes://","#ffd60a"],["Files","shareddocuments://","#1e90ff"],["Music","music://","#fa2d48"],["Maps","maps://","#32ade6"],["Podcasts","podcasts://","#9b4dff"],["Books","ibooks://","#ff8a00"],
  ["Shortcuts","shortcuts://","#5e5ce6"],["App Store","itms-apps://","#0a84ff"],["Settings","App-prefs:","#8e8e93"],["Weather","weather://","#3d9bff"],
  ["WhatsApp","whatsapp://","#25d366"],["YouTube","youtube://","#ff0033"],["Spotify","spotify:","#1db954"],["Gmail","googlegmail://","#ea4335"],["Outlook","ms-outlook://","#0a64d8"],["Teams","msteams://","#5b5fc7"],
  ["Zoom","zoomus://","#2d8cff"],["Word","ms-word:","#2b579a"],["Excel","ms-excel:","#217346"],["PowerPoint","ms-powerpoint:","#d24726"],["Chrome","googlechrome://","#4285f4"],["Google Maps","comgooglemaps://","#34a853"],
  ["Google Drive","googledrive://","#1fa463"],["OneDrive","ms-onedrive://","#0364b8"],["Dropbox","dbapi-1://","#0061fe"],["Notion","notion://","#1d1d1f"],["Slack","slack://","#4a154b"],["Telegram","tg://","#2aabee"],
  ["Instagram","instagram://","#e1306c"],["Facebook","fb://","#1877f2"],["X","twitter://","#111111"],["LinkedIn","linkedin://","#0a66c2"],["Netflix","nflx://","#e50914"],["Uber","uber://","#000000"],["Discord","discord://","#5865f2"]];
function ipadAppId(n){return "ipad_"+n.toLowerCase().replace(/[^a-z0-9]+/g,"")}
function registerIpadApp(name,url,color,user){const id=ipadAppId(name);ICON[id]=letterIcon(id,name,color);
  APPS[id]={name,icon:id,ipad:true,url,hidden:true,user:!!user,launch(){openLink(url);UI.toast(`Opening ${name}`,"If it's installed on your iPad",id);return false},create(){}}}
IPAD_APPS.forEach(([n,u,c])=>registerIpadApp(n,u,c));
function loadUserIpadApps(){(S.ipadApps||[]).forEach(a=>registerIpadApp(a.name,a.url,a.color,true))}
const _lpOpen=Launchpad.open;
Launchpad.open=function(){Launchpad.folder=null;_lpOpen()};
const _lpDraw3=Launchpad.draw;
Launchpad.draw=function(q){const g=$("[data-lpg]");
  if(Launchpad.folder==="ipad"){const list=Object.entries(APPS).filter(([id,a])=>a.ipad&&a.name.toLowerCase().includes((q||"").toLowerCase()));
    g.innerHTML=`<div class="lp-folder-head" style="grid-column:1/-1"><button data-back>‹ Back</button>iPad Apps<button data-addipad>＋ Add app</button></div>`+list.map(([id,a])=>`<div class="lp" data-app="${id}">${ICON[a.icon]()}<span>${esc(a.name)}</span></div>`).join("")+
      `<div class="muted" style="grid-column:1/-1;color:rgba(255,255,255,.8);text-align:center;font-size:12.5px">These open the real app on your iPad — if it's installed. Long-press to keep one in the Dock.</div>`;
    $("[data-back]",g).onclick=e=>{e.stopPropagation();Launchpad.folder=null;Launchpad.draw(q)};$("[data-addipad]",g).onclick=e=>{e.stopPropagation();addIpadAppDialog()};
    $$(".lp[data-app]",g).forEach(el=>{el.onclick=e=>{e.stopPropagation();Launchpad.close();Dock.launch(el.dataset.app)};
      longPress(el,ev=>{const id=el.dataset.app,pinned=(S.pinned||[]).includes(id);UI.menu([{label:"Open",action:()=>{Launchpad.close();Dock.launch(id)}},{label:pinned?"Remove from Dock":"Keep in Dock",action:()=>{S.pinned=pinned?S.pinned.filter(x=>x!==id):[...(S.pinned||[]),id];saveSettings();rebuildDock()}},
        ...(APPS[id].user?[{label:"Delete",action:()=>{S.ipadApps=(S.ipadApps||[]).filter(a=>ipadAppId(a.name)!==id);S.pinned=(S.pinned||[]).filter(x=>x!==id);delete APPS[id];saveSettings();rebuildDock();Launchpad.draw(q)}}]:[])],ev.clientX,ev.clientY)})});return}
  _lpDraw3(q);
  const f=html(`<div class="lp folder">${ICON.ipadfolder()}<span>iPad Apps</span></div>`);f.onclick=e=>{e.stopPropagation();Launchpad.folder="ipad";Launchpad.draw("")};const add=$(".lp.add",g);g.insertBefore(f,add||null)};
async function addIpadAppDialog(){const r=await UI.dialog({title:"Add an iPad App",text:"Enter the app's link (URL scheme), e.g. <code>whatsapp://</code>. Search the web for “<i>app name</i> URL scheme” to find it.",fields:[{ph:"Name"},{ph:"Link, e.g. procreate://"}],ok:"Add"});
  if(!r||!r[0].trim()||!r[1].trim())return;let u=r[1].trim();if(!/:/.test(u))u+="://";const a={name:r[0].trim(),url:u,color:RCOL[(S.ipadApps||[]).length%RCOL.length]};S.ipadApps=[...(S.ipadApps||[]),a];saveSettings();registerIpadApp(a.name,a.url,a.color,true);
  if($("#launchpad").classList.contains("show"))Launchpad.draw("");UI.toast("Added",`${a.name} is in Launchpad › iPad Apps`)}

/* ================= web app gallery + real icons ================= */
const GALLERY=[
  ["Create & design",[["Photopea","https://www.photopea.com/","Photoshop-style image editor"],["Excalidraw","https://excalidraw.com/","Whiteboard & sketching"],["tldraw","https://www.tldraw.com/","Infinite canvas drawing"],["draw.io","https://app.diagrams.net/","Diagrams & flowcharts"],
    ["Graphite","https://editor.graphite.rs/","Vector & raster editor"],["JS Paint","https://jspaint.app/","Classic paint program"],["Kleki","https://kleki.com/","Digital painting"],["Squoosh","https://squoosh.app/","Compress & resize images"],["Canva","https://www.canva.com/","Designs & social posts"]]],
  ["Work & office",[["Word","https://www.office.com/launch/word","Microsoft Word on the web"],["Excel","https://www.office.com/launch/excel","Microsoft Excel on the web"],["PowerPoint","https://www.office.com/launch/powerpoint","Microsoft PowerPoint on the web"],
    ["Google Docs","https://docs.google.com/","Google documents"],["Google Calendar","https://calendar.google.com/","Your calendar"],["Notion","https://www.notion.so/","Notes & wikis"],["Trello","https://trello.com/","Boards & tasks"]]],
  ["Learn & tools",[["Wikipedia","https://en.m.wikipedia.org/","The free encyclopedia"],["GeoGebra","https://www.geogebra.org/calculator","Graphing calculator"],["Desmos","https://www.desmos.com/calculator","Graphing calculator"],["Translate","https://translate.google.com/","Google Translate"],
    ["Claude","https://claude.ai/","Your AI assistant"],["StackBlitz","https://stackblitz.com/","Code in the browser"],["Weather","https://wttr.in/","Weather forecast"]]],
  ["Watch & listen",[["YouTube","https://m.youtube.com/","Videos"],["Spotify","https://open.spotify.com/","Music"],["Netflix","https://www.netflix.com/","Films & series"],["SoundCloud","https://soundcloud.com/","Music & podcasts"]]]];
const _regWA2=registerWebApp;
registerWebApp=function(a){if(a.user||a.fav){ICON[a.icon]=faviconIcon(a.id,a.name,a.url,a.color)}_regWA2(a)};
function galleryHTML(){const have=new Set([...(S.webapps||[]).map(a=>a.url),...WEBAPPS_BUILTIN.map(a=>a.url)]);
  return GALLERY.map(([cat,apps])=>`<div class="gal-cat">${esc(cat)}</div><div class="gal">${apps.map(([n,u,d])=>`<div class="gi">${faviconIcon("g"+n.replace(/\W/g,""),n,u)()}<div class="grow"><b>${esc(n)}</b><small>${esc(d)} · ${frameBlocked(u)?"opens in Safari":"opens in Nimbus"}</small></div>
    ${have.has(u)?`<button class="btn" disabled>Added</button>`:`<button class="btn primary" data-gadd="${esc(u)}" data-gname="${esc(n)}">Get</button>`}</div>`).join("")}</div>`).join("")}
function bindGallery(root,after){$$("[data-gadd]",root).forEach(b=>b.onclick=()=>{const u=b.dataset.gadd;addWebApp(b.dataset.gname,u,frameBlocked(u)?"safari":"nimbus");b.textContent="Added";b.disabled=true;b.classList.remove("primary");after&&after()})}
/* Browser: install sheet + gallery tab on the start page */
const _webCreate=APPS.web.create;
APPS.web.create=function(w,opts){const hooks=_webCreate(w,opts);
  const dockBtn=$("[data-a=dock]",w.body);if(dockBtn){dockBtn.title="Install as app";dockBtn.innerHTML=`<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="4" y="4" width="16" height="16" rx="5"/><path d="M12 8v8M8 12h8"/></svg>`;
    const fresh=dockBtn.cloneNode(true);dockBtn.replaceWith(fresh);
    fresh.onclick=()=>{const u=$("[data-url]",w.body).value;if(!u)return UI.toast("Open a page first","Then tap Install to add it as an app");installSheet(w.el,u)}}
  const obs=new MutationObserver(()=>{$$(".web-start",w.body).forEach(s=>{if(s.dataset.gal)return;s.dataset.gal=1;const box=html(`<div style="width:100%;max-width:760px"><h2 style="margin:10px 0 0">App Gallery</h2><p class="muted" style="margin:4px 0 0;font-size:12.5px">Install web apps with one tap — they get a Dock icon and their own window.</p>${galleryHTML()}</div>`);
    s.insertBefore(box,s.children[2]||null);bindGallery(box)})});obs.observe(w.body,{childList:true,subtree:true});
  const _c=hooks.close;hooks.close=()=>{obs.disconnect();_c&&_c()};return hooks};
function installSheet(host,url){const name=hostOf(url).split(".").slice(-2,-1)[0]||hostOf(url);const nice=name.replace(/^\w/,c=>c.toUpperCase());const blocked=frameBlocked(url);
  const wrap=html(`<div class="sheet-wrap"><div class="sheet"><h3>Install as App</h3><div style="display:flex;gap:14px;align-items:center;margin-bottom:10px"><div style="width:64px;height:64px">${faviconIcon("ins",nice,url)()}</div><div class="muted" style="font-size:12.5px;word-break:break-all">${esc(url)}</div></div>
    <div class="frow"><label>Name</label><input class="field" data-n value="${esc(nice)}"></div>
    <div class="frow"><label>Opens</label><select data-m><option value="nimbus" ${blocked?"":"selected"}>Inside Nimbus (own window)</option><option value="safari" ${blocked?"selected":""}>In Safari</option></select></div>
    <div class="frow"><label>Also</label><label style="text-align:left;display:flex;gap:8px;align-items:center;color:var(--text)"><input type="checkbox" data-desk> Put an icon on the Desktop</label></div>
    ${blocked?`<small class="hint">This site blocks being shown inside other apps, so Safari is recommended.</small>`:""}
    <div class="acts"><button class="btn" data-x>Cancel</button><button class="btn primary" data-ok>Install</button></div></div></div>`);
  host.appendChild(wrap);$("[data-x]",wrap).onclick=()=>wrap.remove();
  $("[data-ok]",wrap).onclick=()=>{const a=addWebApp($("[data-n]",wrap).value.trim()||nice,url,$("[data-m]",wrap).value);if($("[data-desk]",wrap).checked){S.deskApps=[...(S.deskApps||[]),a.id];saveSettings();renderDesktopIcons()}wrap.remove()}}
/* desktop icons for apps */
const _rdi=renderDesktopIcons;
renderDesktopIcons=async function(){await _rdi();const box=$("#desk-icons");(S.deskApps||[]).filter(id=>APPS[id]).forEach(id=>{const a=APPS[id];const el=html(`<div class="dicon" data-appicon="${id}"><div class="ic">${ICON[a.icon]()}</div><span>${esc(a.name)}</span></div>`);
  el.onclick=e=>{$$(".dicon").forEach(x=>x.classList.remove("sel"));el.classList.add("sel");if(e.pointerType==="touch"||e.detail>=2)Dock.launch(id)};
  longPress(el,ev=>UI.menu([{label:"Open",action:()=>Dock.launch(id)},{label:"Remove from Desktop",action:()=>{S.deskApps=S.deskApps.filter(x=>x!==id);saveSettings();renderDesktopIcons()}}],ev.clientX,ev.clientY));box.appendChild(el)})};
/* App Installer gets the gallery too */
const _rInst=renderInstaller;
renderInstaller=async function(w,o){await _rInst(w,o);const inst=$(".inst",w.body);if(!inst||inst.dataset.gal)return;inst.dataset.gal=1;const box=html(`<div><h3>App Gallery</h3>${galleryHTML()}</div>`);inst.appendChild(box);bindGallery(box,()=>renderInstaller(w,o))};

/* ================= Notification Center ================= */
document.body.appendChild(html(`<div id="nc"></div>`));
const NC={log:[],
  toggle(){const n=$("#nc");if(n.classList.contains("show")){n.classList.remove("show");return}NC.render();n.classList.add("show");$("#cc").classList.remove("show")},
  async render(){await RM.load();const n=$("#nc");const d=new Date();const today=RM.items.filter(RM.smart.today).sort(RM.sort);
    const accs=(typeof mailAccounts==="function"?mailAccounts():[]);const unread=typeof Unread!=="undefined"?Unread.total():0;
    n.innerHTML=`<div class="card"><div class="muted" style="font-size:13px;font-weight:600">${esc(d.toLocaleDateString([], {weekday:"long",month:"long",day:"numeric"}))}</div><div class="big">${esc(d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}))}</div></div>
      <div class="card"><h4>Today's Reminders <a data-or style="color:var(--accent);cursor:pointer;text-transform:none">Open</a></h4>${today.length?today.slice(0,6).map(r=>`<div class="nt" data-rid="${r.id}">${ICON.reminders()}<div><b>${esc(r.title)}</b><span class="${isOverdue(r)?"":""}" style="${isOverdue(r)?"color:#ff3b30":""}">${esc(fmtDue(r))}</span></div></div>`).join(""):`<div class="muted" style="font-size:12.5px">Nothing due today 🎉</div>`}</div>
      ${accs.length?`<div class="card"><h4>Mail <a data-om style="color:var(--accent);cursor:pointer;text-transform:none">Open</a></h4><div style="font-size:13px">${unread?`<b>${unread}</b> unread email${unread>1?"s":""} in connected accounts`:"No unread email in connected accounts"}</div></div>`:""}
      <div class="card"><h4>Notifications ${NC.log.length?`<a data-clear style="color:var(--accent);cursor:pointer;text-transform:none">Clear</a>`:""}</h4>${NC.log.slice(0,25).map(x=>`<div class="nt">${ICON[x.icon]?ICON[x.icon]():`<div class="ic" style="color:var(--accent)">${ICON.logo()}</div>`}<div style="min-width:0"><b>${esc(x.title)}</b><span>${esc(x.body||"")}</span></div><small>${esc(new Date(x.t).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}))}</small></div>`).join("")||`<div class="muted" style="font-size:12.5px">No notifications</div>`}</div>`;
    const or=$("[data-or]",n);or&&(or.onclick=()=>{n.classList.remove("show");WM.open("reminders",{view:"today"})});const om=$("[data-om]",n);om&&(om.onclick=()=>{n.classList.remove("show");WM.open("mail")});
    const cl=$("[data-clear]",n);cl&&(cl.onclick=()=>{NC.log=[];NC.render()});$$("[data-rid]",n).forEach(x=>x.onclick=()=>{n.classList.remove("show");WM.open("reminders",{view:"today"})})}
};
const _toast=UI.toast;UI.toast=function(title,body,icon){NC.log.unshift({title,body,icon,t:Date.now()});NC.log=NC.log.slice(0,50);return _toast.call(UI,title,body,icon)};
document.addEventListener("pointerdown",e=>{if(!e.target.closest("#nc")&&!e.target.closest("#mb-clock"))$("#nc").classList.remove("show")},true);
const _mbRender=Menubar.render;
Menubar.render=function(){_mbRender();const c=$("#mb-clock");if(c){c.style.cursor="pointer";c.onclick=e=>{e.stopPropagation();NC.toggle()}}};

/* ================= Spotlight actions ================= */
const _spS3=Spotlight.search;
Spotlight.search=async function(q){await _spS3.call(Spotlight,q);const t=q.trim();if(!t)return;await RM.load();const acts=[];
  let m=t.match(/^(?:remind(?:er)?(?: me)?(?: to)?|rem|todo)\s+(.+)/i);
  if(m){const p=parseNatural(m[1]);acts.push({icon:ICON.reminders(),label:`New reminder: ${p.title}${p.due?" — "+fmtDue(p):""}`,sub:"Reminders",go:()=>{RM.add(p);UI.toast("Reminder added",p.title+(p.due?" · "+fmtDue(p):""),"reminders")}})}
  m=t.match(/^(?:e?mail|email to|write to)\s+(\S+@\S+)?\s*(.*)$/i);
  if(m&&(m[1]||/^e?mail$/i.test(t)))acts.push({icon:ICON.mail(),label:`New email${m[1]?" to "+m[1]:""}${m[2]?" — "+m[2]:""}`,sub:"Mail",go:()=>openCompose({to:m[1]||"",subject:m[2]||""})});
  m=t.match(/^note\s+(.+)/i);if(m)acts.push({icon:ICON.notes(),label:`New note: ${m[1]}`,sub:"Notes",go:async()=>{const notes=await DB.get("notes",[]);notes.unshift({id:uid(),text:m[1],mtime:Date.now()});await DB.set("notes",notes);Widgets.render();UI.toast("Note saved",m[1].slice(0,60),"notes")}});
  if(/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(t)||/^https?:\/\//.test(t)){const u=normalizeUrl(t);acts.push({icon:ICON.web(),label:`Open ${hostOf(u)}`,sub:"Browser",go:()=>openInBrowser(u)})}
  Object.entries(APPS).filter(([id,a])=>a.ipad&&a.name.toLowerCase().startsWith(t.toLowerCase())).slice(0,3).forEach(([id,a])=>acts.push({icon:ICON[a.icon](),label:a.name,sub:"iPad app",go:()=>Dock.launch(id)}));
  RM.items.filter(r=>!r.done&&r.title.toLowerCase().includes(t.toLowerCase())).slice(0,4).forEach(r=>acts.push({icon:ICON.reminders(),label:r.title,sub:r.due?fmtDue(r):"Reminder",go:()=>WM.open("reminders",{view:r.list})}));
  if(acts.length){Spotlight.items.unshift(...acts);Spotlight.sel=0;Spotlight.draw()}};
$("#sp-in").placeholder="Search, or try “remind me to call mum at 5pm”";

/* ================= look & feel settings ================= */
Object.assign(WALLS,{tahoe:"Tahoe",citrus:"Citrus",blush:"Blush",indigo:"Indigo"});
function hueOf(hex){const n=parseInt(hex.slice(1),16),r=(n>>16)/255,g=((n>>8)&255)/255,b=(n&255)/255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;if(!d)return 0;let h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;return (h*60+360)%360}
function applyNeo(){const r=document.documentElement;r.dataset.neo=S.neo===false?"0":"1";r.dataset.icons=S.iconStyle||"default";r.style.setProperty("--tint-rot",(hueOf(S.accent||"#0a84ff")-40)+"deg")}
const _applyTheme=applyTheme;applyTheme=function(){_applyTheme();applyNeo()};
const _setCreate2=APPS.settings.create;
APPS.settings.create=function(w,opts){const hooks=_setCreate2(w,opts);
  const obs=new MutationObserver(()=>{const P=$("[data-pane]",w.body);if(!P||P.dataset.neo||!$("[data-th]",P))return;P.dataset.neo=1;
    P.insertAdjacentHTML("beforeend",`<h3 style="margin:0;font-size:14px">Neo look</h3><div class="set-group">
      <div class="set-row"><div><label>Liquid Glass</label><small>Clearer glass, floating sidebars, rounder corners and a see-through menu bar</small></div><div class="toggle ${S.neo!==false?"on":""}" data-neo></div></div>
      <div class="set-row"><label>Icon style</label><div class="seg">${["default","dark","clear","tinted"].map(s=>`<button class="${(S.iconStyle||"default")===s?"on":""}" data-ist="${s}">${s[0].toUpperCase()+s.slice(1)}</button>`).join("")}</div></div></div>`);
    $("[data-neo]",P).onclick=e=>{S.neo=S.neo===false;e.currentTarget.classList.toggle("on",S.neo!==false);applyNeo();saveSettings()};
    $$("[data-ist]",P).forEach(b=>b.onclick=()=>{S.iconStyle=b.dataset.ist;$$("[data-ist]",P).forEach(x=>x.classList.toggle("on",x===b));applyNeo();saveSettings()})});
  obs.observe(w.body,{childList:true,subtree:true});const _c=hooks.close;hooks.close=()=>{obs.disconnect();_c&&_c()};return hooks};

/* Dock: Reminders in the base dock */
BASE_DOCK.splice(BASE_DOCK.indexOf("notes"),0,"reminders");

/* ================= boot ================= */
const _bootNeo=window.NIMBUS_BOOT;
window.NIMBUS_BOOT=async function(){await DB.open();await loadSettings();applyNeo();loadUserIpadApps();await RM.load();
  (S.webapps||[]).forEach(a=>{ICON["u_"+a.id]=faviconIcon(a.id,a.name,a.url,a.color)});
  await _bootNeo();applyNeo();FS.listeners.delete(_rdi);FS.listeners.add(renderDesktopIcons);renderDesktopIcons()};
/* boot is started by nimbus-bookmarks.js */
