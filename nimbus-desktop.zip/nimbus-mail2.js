/* Nimbus Desktop — real inboxes for Gmail (Gmail API) and Outlook / Hotmail / Microsoft 365 (Microsoft Graph).
   Sign-in uses the providers' own pages (OAuth). Tokens stay on this iPad. Other providers remain shortcuts.
   Loaded last; starts the desktop. */
"use strict";

document.head.appendChild(html(`<style>
.mx{flex:1;display:flex;min-width:0;min-height:0}
.mx .sidebar{width:220px;display:flex;flex-direction:column}
.mx .sidebar .grow{flex:1}
.mx .si .dot{width:10px;height:10px;border-radius:50%;flex:none;margin:0 3px}
.mx .si .ub{margin-left:auto;font-size:11px;font-weight:700;color:var(--text2);min-width:18px;text-align:right}
.mx .si.act .ub{color:var(--text)}
.mx .si .ext{margin-left:auto;opacity:.45;font-size:11px}
.mx .si.sub{padding-left:30px;font-size:12.5px}
.mx .si.sub svg{width:14px;height:14px}
.mx .mlist{width:340px;flex:none;border-right:1px solid var(--hair);display:flex;flex-direction:column;min-height:0}
.mx .mlist .lh{padding:10px 14px 6px;display:flex;align-items:baseline;gap:8px}
.mx .mlist .lh b{font-size:17px}.mx .mlist .lh small{color:var(--text3);font-size:12px}
.mx .msgs{flex:1;overflow:auto;-webkit-overflow-scrolling:touch}
.mx .m{position:relative;padding:9px 14px 10px 26px;border-bottom:1px solid var(--hair);cursor:default}
.mx .m:hover{background:var(--hover)}
.mx .m.act{background:var(--accent);color:#fff}.mx .m.act .sn,.mx .m.act .dt{color:rgba(255,255,255,.85)}
.mx .m .ud{position:absolute;left:10px;top:15px;width:9px;height:9px;border-radius:50%;background:var(--accent)}
.mx .m.act .ud{background:#fff}
.mx .m .strip{position:absolute;left:0;top:0;bottom:0;width:4px}
.mx .m .fr{display:flex;justify-content:space-between;gap:8px;font-size:13.5px}
.mx .m .fr b{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
.mx .m.unread .fr b{font-weight:700}
.mx .m .dt{font-size:11.5px;color:var(--text3);white-space:nowrap;flex:none}
.mx .m .sj{font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.mx .m.unread .sj{font-weight:600}
.mx .m .sn{font-size:12px;color:var(--text3);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:2px;line-height:1.35}
.mx .more{display:block;margin:12px auto;}
.mx .reader{flex:1;display:flex;flex-direction:column;min-width:0;min-height:0}
.mx .rbar{display:flex;gap:4px;padding:6px 10px;border-bottom:1px solid var(--hair);flex:none;flex-wrap:wrap}
.mx .rbar .btn{background:none;padding:5px 9px;font-size:12.5px}.mx .rbar .btn:hover{background:var(--hover)}
.mx .rhead{padding:16px 22px 12px;border-bottom:1px solid var(--hair);flex:none}
.mx .rhead h2{margin:0 0 10px;font-size:19px;line-height:1.3;-webkit-user-select:text;user-select:text}
.mx .rfrom{display:flex;gap:11px;align-items:center}
.mx .rfrom .av{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;flex:none}
.mx .rfrom .who{min-width:0;flex:1;font-size:13px}.mx .rfrom .who b{font-size:14px}
.mx .rfrom .who small{display:block;color:var(--text3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:text;user-select:text}
.mx .rbody{flex:1;min-height:0;position:relative;background:#fff}
.mx .rbody iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:#fff}
.mx .ratts{display:flex;gap:8px;flex-wrap:wrap;padding:8px 22px;border-top:1px solid var(--hair);flex:none}
.mx .ratt{display:flex;gap:8px;align-items:center;background:var(--field);border-radius:9px;padding:6px 10px;font-size:12px;cursor:pointer}
.mx .ratt b{font-weight:600;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mx .center{flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:var(--text3);text-align:center;padding:30px}
.mx .center .ic{width:64px;height:64px;opacity:.9}
.mx .spin{width:22px;height:22px;border-radius:50%;border:2.5px solid var(--hair);border-top-color:var(--accent);animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.mx .conn{margin:18px;background:var(--field);border-radius:14px;padding:16px;font-size:13px;line-height:1.5}
.mx .conn h4{margin:0 0 6px;font-size:14px}
.setup-sheet code{font-family:var(--mono);font-size:11.5px;background:var(--field);padding:2px 6px;border-radius:5px;word-break:break-all}
.setup-sheet ol{padding-left:18px;margin:6px 0;font-size:12.5px;line-height:1.55}
</style>`));

/* ================= configuration & tokens ================= */
const REDIRECT=location.origin+location.pathname.replace(/[^/]*$/,"");
const GOOGLE_SCOPES="https://www.googleapis.com/auth/gmail.modify https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/youtube.readonly";
const MS_SCOPES="offline_access User.Read Mail.ReadWrite Mail.Send Files.ReadWrite.All";
const MSAUTH="https://login.microsoftonline.com/common/oauth2/v2.0";
const GM="https://gmail.googleapis.com/gmail/v1/users/me";
const GR="https://graph.microsoft.com/v1.0/me";
const kindOf=a=>a.provider==="gmail"?"g":(a.provider==="outlook"||a.provider==="m365")?"m":null;
const MT={tokens:{},
  async load(){MT.tokens=await DB.get("mail-tokens",{})},
  save(){DB.set("mail-tokens",MT.tokens)},
  connected(a){return !!MT.tokens[a.id]},
  canConnect(a){const k=kindOf(a);return k==="g"?!!(S.mailCfg&&S.mailCfg.google):k==="m"?!!(S.mailCfg&&S.mailCfg.microsoft):false},
  forget(a){delete MT.tokens[a.id];MT.save()}};
class NeedAuth extends Error{constructor(a,why){super(why||"Sign-in needed");this.acc=a}}
const b64url=buf=>btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
const rnd=n=>b64url(crypto.getRandomValues(new Uint8Array(n)));
async function connectAccount(a,{silent=false}={}){
  const k=kindOf(a);if(!k)return;
  if(SANDBOXED)return UI.toast("Needs the installed version","Connecting email works in the version on your Home Screen.","mail");
  if(!MT.canConnect(a))return openSetup();
  if(!silent&&!(await UI.dialog({title:`Connect ${accLabel(a)}`,text:`You'll sign in on ${k==="g"?"Google":"Microsoft"}'s own page, then come straight back.<br><b>Nimbus will reload</b> — save any open documents first.`,ok:"Continue"})))return;
  const nonce=rnd(12);const pend={acc:a.id,k,t:Date.now()};
  let url;
  if(k==="g"){url=`https://accounts.google.com/o/oauth2/v2/auth?${qs({client_id:S.mailCfg.google,redirect_uri:REDIRECT,response_type:"token",scope:GOOGLE_SCOPES,include_granted_scopes:"true",login_hint:a.email,state:nonce,prompt:silent?"none":"consent"})}`}
  else{const ver=rnd(48);pend.ver=ver;const ch=b64url(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(ver)));
    url=`${MSAUTH}/authorize?${qs({client_id:S.mailCfg.microsoft,response_type:"code",redirect_uri:REDIRECT,response_mode:"query",scope:MS_SCOPES,state:nonce,code_challenge:ch,code_challenge_method:"S256",login_hint:a.email,prompt:silent?"":"select_account"})}`}
  await DB.set("oauth-pending",{...pend,nonce});
  await DB.set("oauth-reopen",{acc:a.id});
  location.href=url}
async function handleOAuthReturn(){
  const h=new URLSearchParams(location.hash.slice(1)),q=new URLSearchParams(location.search);
  const state=h.get("state")||q.get("state");if(!state)return null;
  const pend=await DB.get("oauth-pending");history.replaceState(null,"",location.pathname);
  if(!pend||pend.nonce!==state){UI.toast("Sign-in expired","Please try connecting again.","mail");return null}
  await DB.del("oauth-pending");const a=mailAccounts().find(x=>x.id===pend.acc);if(!a)return null;
  const err=h.get("error")||q.get("error");
  if(err){if(err==="interaction_required"||err==="login_required"){connectAccount(a,{silent:false});return null}
    UI.toast("Couldn't connect",(h.get("error_description")||q.get("error_description")||err).replace(/\+/g," ").slice(0,140),"mail");return a}
  try{
    if(pend.k==="g"){MT.tokens[a.id]={k:"g",access:h.get("access_token"),scope:h.get("scope")||"",exp:Date.now()+(+h.get("expires_in")||3600)*1000}}
    else{const r=await fetch(`${MSAUTH}/token`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
        body:qs({client_id:S.mailCfg.microsoft,grant_type:"authorization_code",code:q.get("code"),redirect_uri:REDIRECT,code_verifier:pend.ver,scope:MS_SCOPES})});
      const j=await r.json();if(!r.ok)throw new Error(j.error_description||j.error||"Token error");
      MT.tokens[a.id]={k:"m",access:j.access_token,refresh:j.refresh_token,scope:j.scope||"",exp:Date.now()+(j.expires_in||3600)*1000}}
    MT.save();
    const who=await Mail.whoami(a);MT.tokens[a.id].email=who;MT.save();
    if(who&&who.toLowerCase()!==a.email.toLowerCase())UI.toast("Connected — different address",`Signed in as ${who}, but this account is ${a.email}. Edit the account if that's wrong.`,"mail");
    else UI.toast(`${accLabel(a)} connected`,"Your emails now show in Mail","mail")}
  catch(e){MT.forget(a);UI.toast("Couldn't connect",String(e.message||e).slice(0,140),"mail")}
  return a}
async function tokenFor(a){const t=MT.tokens[a.id];if(!t)throw new NeedAuth(a,"Not connected");
  if(t.exp>Date.now()+60000)return t.access;
  if(t.k==="m"&&t.refresh){const r=await fetch(`${MSAUTH}/token`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body:qs({client_id:S.mailCfg.microsoft,grant_type:"refresh_token",refresh_token:t.refresh,scope:MS_SCOPES})});
    const j=await r.json();if(r.ok){t.access=j.access_token;if(j.refresh_token)t.refresh=j.refresh_token;t.exp=Date.now()+(j.expires_in||3600)*1000;MT.save();return t.access}
    throw new NeedAuth(a,"Session expired")}
  throw new NeedAuth(a,"Session expired")}
async function api(a,url,opt={},retry=true){const tok=await tokenFor(a);
  const r=await fetch(url,{...opt,headers:{Authorization:"Bearer "+tok,...(opt.body&&typeof opt.body==="string"?{"Content-Type":"application/json"}:{}),...(opt.headers||{})}});
  if(r.status===401){const t=MT.tokens[a.id];if(t)t.exp=0;if(retry&&t&&t.k==="m"&&t.refresh)return api(a,url,opt,false);throw new NeedAuth(a,"Session expired")}
  if(r.status===204||r.status===202)return {};
  const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error((j.error&&(j.error.message||j.error))||("HTTP "+r.status));return j}

/* ================= provider adapters ================= */
const dec=new TextDecoder();
const fromB64url=s=>{s=s.replace(/-/g,"+").replace(/_/g,"/");const bin=atob(s);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u};
const parseAddr=s=>{if(!s)return {name:"",email:""};const m=s.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>/);return m?{name:m[1].trim(),email:m[2].trim()}:{name:"",email:s.trim()}};
const hdr=(hs,n)=>(hs.find(h=>h.name.toLowerCase()===n.toLowerCase())||{}).value||"";
const GFOLD={inbox:"INBOX",starred:"STARRED",sent:"SENT",drafts:"DRAFT",spam:"SPAM",trash:"TRASH",all:null};
const MFOLD={inbox:"inbox",starred:null,sent:"sentitems",drafts:"drafts",spam:"junkemail",trash:"deleteditems",archive:"archive"};
const FOLDERS_FOR={g:["inbox","starred","sent","drafts","spam","trash","all"],m:["inbox","starred","sent","drafts","spam","trash","archive"]};
const FNAMES={...FOLDER_NAMES,trash:"Trash",starred:"Starred"};
async function pool(items,n,fn){const out=new Array(items.length);let i=0;await Promise.all(Array.from({length:Math.min(n,items.length)},async()=>{while(i<items.length){const k=i++;try{out[k]=await fn(items[k])}catch(e){out[k]=null}}}));return out}
function mimeEncodeHeader(s){return /^[\x20-\x7e]*$/.test(s)?s:`=?UTF-8?B?${btoa(unescape(encodeURIComponent(s)))}?=`}
async function buildMime(a,m){const B="nimbus_"+rnd(10);const lines=[`From: ${mimeEncodeHeader(accLabel(a))} <${a.email}>`,`To: ${m.to}`];
  if(m.cc)lines.push(`Cc: ${m.cc}`);lines.push(`Subject: ${mimeEncodeHeader(m.subject||"")}`,"MIME-Version: 1.0");
  if(m.inReplyTo){lines.push(`In-Reply-To: ${m.inReplyTo}`,`References: ${(m.references?m.references+" ":"")+m.inReplyTo}`)}
  const textPart=["Content-Type: text/plain; charset=UTF-8","Content-Transfer-Encoding: base64","",btoa(unescape(encodeURIComponent(m.body||""))).replace(/.{76}/g,"$&\r\n")].join("\r\n");
  let body;if(!m.atts||!m.atts.length){body=lines.join("\r\n")+"\r\n"+textPart}
  else{const parts=[textPart];for(const f of m.atts){const b=new Uint8Array(await f.arrayBuffer());let s="";for(let i=0;i<b.length;i+=32768)s+=String.fromCharCode(...b.subarray(i,i+32768));
      parts.push([`Content-Type: ${f.type||"application/octet-stream"}; name="${mimeEncodeHeader(f.name)}"`,`Content-Disposition: attachment; filename="${mimeEncodeHeader(f.name)}"`,"Content-Transfer-Encoding: base64","",btoa(s).replace(/.{76}/g,"$&\r\n")].join("\r\n"))}
    body=lines.join("\r\n")+`\r\nContent-Type: multipart/mixed; boundary="${B}"\r\n\r\n`+parts.map(p=>`--${B}\r\n${p}`).join("\r\n")+`\r\n--${B}--`}
  const bytes=new TextEncoder().encode(body);let s="";for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));
  return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
async function fileToB64(f){const b=new Uint8Array(await f.arrayBuffer());let s="";for(let i=0;i<b.length;i+=32768)s+=String.fromCharCode(...b.subarray(i,i+32768));return btoa(s)}
const Mail={
  async whoami(a){const k=kindOf(a);if(k==="g")return (await api(a,`${GM}/profile`)).emailAddress;const j=await api(a,`${GR}?$select=mail,userPrincipalName`);return j.mail||j.userPrincipalName},
  async list(a,folder,{q="",page=null}={}){const k=kindOf(a);
    if(k==="g"){const p={maxResults:"25"};if(GFOLD[folder])p.labelIds=GFOLD[folder];if(q)p.q=q;if(page)p.pageToken=page;
      const j=await api(a,`${GM}/messages?${qs(p)}`);const ids=(j.messages||[]).map(x=>x.id);
      const metas=await pool(ids,8,id=>api(a,`${GM}/messages/${id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=To`));
      return {next:j.nextPageToken||null,items:metas.filter(Boolean).map(mm=>{const hs=mm.payload?.headers||[];const fr=parseAddr(hdr(hs,"From"));
        return {acc:a.id,id:mm.id,thread:mm.threadId,from:fr,to:hdr(hs,"To"),subject:hdr(hs,"Subject"),snippet:(mm.snippet||"").replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">"),
          date:+mm.internalDate,unread:(mm.labelIds||[]).includes("UNREAD"),starred:(mm.labelIds||[]).includes("STARRED"),att:mm.payload?.mimeType==="multipart/mixed"}})}}
    const sel="$select=id,subject,from,toRecipients,receivedDateTime,isRead,bodyPreview,hasAttachments,conversationId,flag";
    let url;if(page)url=page;else if(q)url=`${GR}/messages?$search=${enc('"'+q.replace(/"/g,"")+'"')}&$top=25&${sel}`;
    else if(folder==="starred")url=`${GR}/messages?$filter=${enc("flag/flagStatus eq 'flagged'")}&$top=25&${sel}`;
    else url=`${GR}/mailFolders/${MFOLD[folder]||"inbox"}/messages?$top=25&${sel}&$orderby=receivedDateTime desc`;
    const j=await api(a,url);
    return {next:j["@odata.nextLink"]||null,items:(j.value||[]).map(m=>({acc:a.id,id:m.id,thread:m.conversationId,from:{name:m.from?.emailAddress?.name||"",email:m.from?.emailAddress?.address||""},
      to:(m.toRecipients||[]).map(r=>r.emailAddress.address).join(", "),subject:m.subject||"",snippet:m.bodyPreview||"",date:Date.parse(m.receivedDateTime),unread:!m.isRead,starred:m.flag?.flagStatus==="flagged",att:!!m.hasAttachments}))}},
  async get(a,id){const k=kindOf(a);
    if(k==="g"){const m=await api(a,`${GM}/messages/${id}?format=full`);const hs=m.payload.headers||[];let htmlB="",textB="";const atts=[];
      const walk=p=>{if(p.parts)p.parts.forEach(walk);const fn=p.filename;if(fn&&p.body&&p.body.attachmentId){atts.push({name:fn,mime:p.mimeType,size:p.body.size,aid:p.body.attachmentId});return}
        if(p.body&&p.body.data){const s=dec.decode(fromB64url(p.body.data));if(p.mimeType==="text/html"&&!htmlB)htmlB=s;else if(p.mimeType==="text/plain"&&!textB)textB=s}};
      walk(m.payload);
      return {id,thread:m.threadId,from:parseAddr(hdr(hs,"From")),to:hdr(hs,"To"),cc:hdr(hs,"Cc"),subject:hdr(hs,"Subject"),date:+m.internalDate,html:htmlB,text:textB,atts,
        msgId:hdr(hs,"Message-ID")||hdr(hs,"Message-Id"),refs:hdr(hs,"References"),unread:(m.labelIds||[]).includes("UNREAD"),starred:(m.labelIds||[]).includes("STARRED")}}
    const m=await api(a,`${GR}/messages/${id}?$select=subject,from,toRecipients,ccRecipients,receivedDateTime,body,hasAttachments,internetMessageId,isRead,flag`,{headers:{Prefer:'outlook.body-content-type="html"'}});
    let atts=[];if(m.hasAttachments){const j=await api(a,`${GR}/messages/${id}/attachments?$select=id,name,contentType,size,isInline`);atts=(j.value||[]).filter(x=>!x.isInline).map(x=>({name:x.name,mime:x.contentType,size:x.size,aid:x.id}))}
    const addrs=l=>(l||[]).map(r=>r.emailAddress.name?`${r.emailAddress.name} <${r.emailAddress.address}>`:r.emailAddress.address).join(", ");
    return {id,from:{name:m.from?.emailAddress?.name||"",email:m.from?.emailAddress?.address||""},to:addrs(m.toRecipients),cc:addrs(m.ccRecipients),subject:m.subject||"",date:Date.parse(m.receivedDateTime),
      html:m.body?.contentType==="html"?m.body.content:"",text:m.body?.contentType!=="html"?m.body?.content||"":"",atts,msgId:m.internetMessageId,unread:!m.isRead,starred:m.flag?.flagStatus==="flagged"}},
  async attachment(a,id,att){const k=kindOf(a);
    if(k==="g"){const j=await api(a,`${GM}/messages/${id}/attachments/${att.aid}`);return new Blob([fromB64url(j.data)],{type:att.mime||"application/octet-stream"})}
    const j=await api(a,`${GR}/messages/${id}/attachments/${att.aid}`);const bin=atob(j.contentBytes||"");const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return new Blob([u],{type:att.mime||j.contentType||"application/octet-stream"})},
  async setRead(a,id,read){if(kindOf(a)==="g")return api(a,`${GM}/messages/${id}/modify`,{method:"POST",body:JSON.stringify(read?{removeLabelIds:["UNREAD"]}:{addLabelIds:["UNREAD"]})});
    return api(a,`${GR}/messages/${id}`,{method:"PATCH",body:JSON.stringify({isRead:read})})},
  async setStar(a,id,on){if(kindOf(a)==="g")return api(a,`${GM}/messages/${id}/modify`,{method:"POST",body:JSON.stringify(on?{addLabelIds:["STARRED"]}:{removeLabelIds:["STARRED"]})});
    return api(a,`${GR}/messages/${id}`,{method:"PATCH",body:JSON.stringify({flag:{flagStatus:on?"flagged":"notFlagged"}})})},
  async archive(a,id){if(kindOf(a)==="g")return api(a,`${GM}/messages/${id}/modify`,{method:"POST",body:JSON.stringify({removeLabelIds:["INBOX"]})});
    return api(a,`${GR}/messages/${id}/move`,{method:"POST",body:JSON.stringify({destinationId:"archive"})})},
  async trash(a,id){if(kindOf(a)==="g")return api(a,`${GM}/messages/${id}/trash`,{method:"POST"});
    return api(a,`${GR}/messages/${id}/move`,{method:"POST",body:JSON.stringify({destinationId:"deleteditems"})})},
  async unread(a){if(kindOf(a)==="g")return (await api(a,`${GM}/labels/INBOX`)).messagesUnread||0;return (await api(a,`${GR}/mailFolders/inbox?$select=unreadItemCount`)).unreadItemCount||0},
  async send(a,m){
    if(kindOf(a)==="g"){const raw=await buildMime(a,m);const body={raw};if(m.thread)body.threadId=m.thread;return api(a,`${GM}/messages/send`,{method:"POST",body:JSON.stringify(body)})}
    const rcp=s=>(s||"").split(/[,;]+/).map(x=>parseAddr(x).email).filter(Boolean).map(address=>({emailAddress:{address}}));
    if(m.replyId&&!(m.atts&&m.atts.length))return api(a,`${GR}/messages/${m.replyId}/${m.replyAll?"replyAll":"reply"}`,{method:"POST",body:JSON.stringify({comment:m.body.replace(/\n/g,"<br>")})});
    const msg={subject:m.subject||"",body:{contentType:"Text",content:m.body||""},toRecipients:rcp(m.to),ccRecipients:rcp(m.cc)};
    if(m.atts&&m.atts.length)msg.attachments=await Promise.all(m.atts.map(async f=>({"@odata.type":"#microsoft.graph.fileAttachment",name:f.name,contentType:f.type||"application/octet-stream",contentBytes:await fileToB64(f)})));
    return api(a,`${GR}/sendMail`,{method:"POST",body:JSON.stringify({message:msg,saveToSentItems:true})})}
};

/* ================= unread counts, dock badge, polling ================= */
const Unread={map:{},
  async refresh(){const accs=mailAccounts().filter(a=>MT.connected(a));await Promise.all(accs.map(async a=>{try{Unread.map[a.id]=await Mail.unread(a)}catch(e){if(e instanceof NeedAuth)Unread.map[a.id]=null}}));Unread.paint()},
  total(){return Object.values(Unread.map).reduce((t,v)=>t+(v||0),0)},
  paint(){const dk=$('#dock .dk[data-app="mail"]');if(dk){let b=$(".badge",dk);if(!b){b=html(`<span class="badge"></span>`);dk.appendChild(b)}const t=Unread.total();b.textContent=t>99?"99+":t;b.style.display=t?"flex":"none"}
    $$("#wg-mail .chip").forEach(c=>{const n=Unread.map[c.dataset.id];let s=$("b",c);if(!s){s=html(`<b style="margin-left:auto;font-size:10.5px;opacity:.8"></b>`);c.appendChild(s)}s.textContent=n?n:""});
    WM.wins.filter(w=>w.app==="mail").forEach(w=>w.hooks.badges&&w.hooks.badges())}};
setInterval(()=>{if(document.visibilityState==="visible")Unread.refresh()},4*60*1000);
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")Unread.refresh()});
const _dockR4=Dock.render;Dock.render=function(){_dockR4();Unread.paint()};
const _wMail=Widgets.mail;Widgets.mail=function(){_wMail();Unread.paint()};

/* ================= setup sheet (client IDs) ================= */
function openSetup(){const w=WM.wins.find(x=>x.app==="mail")||WM.open("mail");setTimeout(()=>setupSheet(w.el),50)}
function setupSheet(host){
  const cfg=S.mailCfg||{};
  const wrap=html(`<div class="sheet-wrap"><div class="sheet setup-sheet"><h3>Connect Gmail, Outlook, Google Drive & OneDrive</h3>
    <p class="muted" style="font-size:12.5px;margin:0 0 10px">To show your emails inside Nimbus, register Nimbus once with Google and/or Microsoft (free). You'll paste the IDs they give you here. Full step-by-step guide: tap <b>Show steps</b>.</p>
    ${SANDBOXED?`<div class="warn" style="background:color-mix(in srgb,#ff9f0a 16%,transparent);border-radius:10px;padding:8px 12px;font-size:12px;margin-bottom:8px">⚠️ This only works in the installed version (your Home Screen app), not in this preview.</div>`:""}
    <div class="frow"><label>Your Nimbus address</label><div><code data-copy>${esc(REDIRECT)}</code> <button class="btn" data-cp style="padding:3px 8px;font-size:11.5px">Copy</button><small class="hint">Use this as the redirect URI (and the origin <code>${esc(location.origin)}</code>) when registering.</small></div></div>
    <div class="frow"><label>Google Client ID</label><input class="field" data-g placeholder="1234…apps.googleusercontent.com" value="${esc(cfg.google||"")}" autocapitalize="off" autocorrect="off"></div>
    <div class="frow"><label>Microsoft App ID</label><input class="field" data-m placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" value="${esc(cfg.microsoft||"")}" autocapitalize="off" autocorrect="off"></div>
    <details style="margin-top:8px"><summary style="cursor:pointer;font-weight:600;font-size:13px">Show steps</summary>
      <b style="font-size:12.5px;display:block;margin-top:8px">Google (for Gmail)</b><ol>
        <li>Open <a href="https://console.cloud.google.com/projectcreate" target="_blank" rel="noopener">console.cloud.google.com</a> → create a project called <i>Nimbus</i>.</li>
        <li>APIs & Services → Library → search and enable <b>Gmail API</b>, <b>Google Drive API</b> and <b>YouTube Data API v3</b>.</li>
        <li>OAuth consent screen (Google Auth Platform) → External → app name <i>Nimbus</i>, your email → Audience: add <b>each of your Gmail addresses as a test user</b>.</li>
        <li>Data access → Add scopes → <code>gmail.modify</code>, <code>gmail.send</code>, <code>drive</code> (Google Drive in Files and Photos) and <code>youtube.readonly</code> (the YouTube app).</li>
        <li>Clients → Create client → <b>Web application</b> → Authorized JavaScript origin: <code>${esc(location.origin)}</code> → Authorized redirect URI: <code>${esc(REDIRECT)}</code> → Create → copy the <b>Client ID</b> here.</li></ol>
      <b style="font-size:12.5px;display:block">Microsoft (for Outlook / Hotmail / 365)</b><ol>
        <li>Open <a href="https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade" target="_blank" rel="noopener">entra.microsoft.com</a> → App registrations → New registration.</li>
        <li>Name <i>Nimbus</i> → Supported accounts: <b>any organizational directory and personal Microsoft accounts</b>.</li>
        <li>Redirect URI: platform <b>Single-page application (SPA)</b> → <code>${esc(REDIRECT)}</code> → Register.</li>
        <li>API permissions → Add → Microsoft Graph → Delegated: <code>Mail.ReadWrite</code>, <code>Mail.Send</code>, <code>Files.ReadWrite.All</code> (for OneDrive in Files), <code>User.Read</code>, <code>offline_access</code>.</li>
        <li>Copy the <b>Application (client) ID</b> from Overview here.</li></ol>
      <p class="muted" style="font-size:11.5px">Google shows a "Google hasn't verified this app" screen the first time — that's expected for your own personal app: tap Advanced → Continue.</p></details>
    <div class="acts"><button class="btn" data-cancel>Close</button><button class="btn primary" data-ok>Save</button></div></div></div>`);
  host.appendChild(wrap);
  $("[data-cp]",wrap).onclick=()=>{try{navigator.clipboard.writeText(REDIRECT);UI.toast("Copied",REDIRECT,"mail")}catch(e){}};
  const close=()=>wrap.remove();$("[data-cancel]",wrap).onclick=close;wrap.addEventListener("pointerdown",e=>{if(e.target===wrap)close()});
  $("[data-ok]",wrap).onclick=()=>{S.mailCfg={google:$("[data-g]",wrap).value.trim(),microsoft:$("[data-m]",wrap).value.trim()};saveSettings();close();UI.toast("Saved","Now tap Connect on a Gmail or Outlook account","mail");MailHub.refresh()}}

/* ================= Mail window (rebuilt) ================= */
const fmtMailDate=t=>{const d=new Date(t),n=new Date();if(d.toDateString()===n.toDateString())return d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"});
  const y=new Date(n);y.setDate(n.getDate()-1);if(d.toDateString()===y.toDateString())return "Yesterday";if(n-d<6*864e5)return d.toLocaleDateString([], {weekday:"long"});return d.toLocaleDateString([], {day:"numeric",month:"short",year:d.getFullYear()===n.getFullYear()?undefined:"2-digit"})};
const htmlToText=h=>{const d=new DOMParser().parseFromString((h||"").replace(/<(br|\/p|\/div|\/h[1-6]|\/li|\/tr)[^>]*>/gi,"$&\n"),"text/html");d.querySelectorAll("style,script,head").forEach(e=>e.remove());return (d.body.textContent||"").replace(/\n{3,}/g,"\n\n").trim()};
const linkify=s=>esc(s).replace(/(https?:\/\/[^\s<]+)/g,'<a href="$1" target="_blank" rel="noopener">$1</a>');
function emailDoc(m){const body=m.html||`<pre style="white-space:pre-wrap;font:14px/1.5 -apple-system,Helvetica,Arial,sans-serif;margin:0">${linkify(m.text||"")}</pre>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="script-src 'none'; object-src 'none'"><base target="_blank">
  <style>body{margin:0;padding:18px 22px;font:14px/1.5 -apple-system,Helvetica,Arial,sans-serif;color:#1d1d1f;word-wrap:break-word;overflow-wrap:anywhere}img{max-width:100%;height:auto}table{max-width:100%}a{color:#0a66d8}blockquote{margin:0 0 0 .6em;padding-left:.8em;border-left:3px solid #ccc;color:#555}</style></head><body>${body}</body></html>`}
APPS.mail={name:"Mail",icon:"mail",w:1180,h:700,single:true,
  create(w,opts){
    const st={view:"all",folder:"inbox",sel:null,items:[],next:{},q:"",loading:false,err:null,msg:null,reqId:0};
    const accs=()=>mailAccounts();const conn=()=>accs().filter(a=>MT.connected(a));
    w.tools.innerHTML=`<input class="field" data-search placeholder="Search" style="width:200px;padding:5px 10px" enterkeyhint="search"><button class="btn icon" data-refresh title="Refresh"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg></button><button class="btn icon" data-compose title="New Message (⌘N)">${PEN}</button>`;
    $("[data-compose]",w.tools).onclick=()=>openCompose({from:currentAcc()?.id});
    $("[data-refresh]",w.tools).onclick=()=>{loadList();Unread.refresh()};
    const si=$("[data-search]",w.tools);si.onkeydown=e=>{if(e.key==="Enter"){st.q=si.value.trim();loadList()}};si.oninput=()=>{if(!si.value&&st.q){st.q="";loadList()}};
    const currentAcc=()=>st.view==="all"?null:accs().find(a=>a.id===st.view);
    const shell=()=>{w.body.innerHTML=`<div class="mx"><div class="sidebar" data-side></div><div class="mlist" data-list></div><div class="reader" data-reader></div></div>`;drawSide()};
    const drawSide=()=>{const side=$("[data-side]",w.body);if(!side)return;const A=accs();const total=Unread.total();
      side.innerHTML=`<h5>Favourites</h5><div class="si ${st.view==="all"?"act":""}" data-v="all">${SVG.imp}All Inboxes<span class="ub">${total||""}</span></div>
        <h5>Accounts</h5>${A.map(a=>{const c=MT.connected(a),open=st.view===a.id&&c;return `<div class="si ${st.view===a.id?"act":""}" data-v="${a.id}"><span class="dot" style="background:${accColor(a)}"></span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(accLabel(a))}</span>${c?`<span class="ub">${Unread.map[a.id]||""}</span>`:`<span class="ext">↗</span>`}</div>
          ${open?FOLDERS_FOR[kindOf(a)].map(f=>`<div class="si sub ${st.folder===f?"act":""}" data-f="${f}">${FOLDER_ICONS[f]||SVG.docs}${FNAMES[f]||f}</div>`).join(""):""}`}).join("")}
        <div class="grow"></div><button class="btn addacc" data-add>${SVG.plus} Add Account</button><button class="btn addacc" data-setup style="margin-top:0">Connection setup…</button>`;
      $$(".si[data-v]",side).forEach(s=>s.onclick=()=>{if(st.view!==s.dataset.v){st.view=s.dataset.v;st.folder="inbox";st.sel=null;st.q="";si.value=""}drawSide();loadList()});
      $$(".si[data-f]",side).forEach(s=>s.onclick=()=>{st.folder=s.dataset.f;st.sel=null;drawSide();loadList()});
      $$(".si[data-v]",side).forEach(s=>{if(s.dataset.v==="all")return;longPress(s,e=>{const a=accs().find(x=>x.id===s.dataset.v);UI.menu([
        ...(kindOf(a)?[MT.connected(a)?{label:"Disconnect",action:()=>{MT.forget(a);delete Unread.map[a.id];Unread.paint();drawSide();loadList()}}:{label:"Connect…",action:()=>connectAccount(a)}]:[]),
        {label:"Open in "+(a.openWith==="web"?"Safari":"its app"),action:()=>MailHub.inbox(a)},{label:"New Message",action:()=>openCompose({from:a.id})},"-",
        {label:"Edit Account…",action:()=>accountSheet(w.el,a,()=>{drawSide();Widgets.mail()})}],e.clientX,e.clientY)})});
      $("[data-add]",side).onclick=()=>accountSheet(w.el,null,acc=>{if(acc){st.view=acc.id;st.folder="inbox"}drawSide();loadList();Widgets.mail()});
      $("[data-setup]",side).onclick=()=>setupSheet(w.el)};
    const listPane=()=>$("[data-list]",w.body),reader=()=>$("[data-reader]",w.body);
    const loadList=async(more=false)=>{const L=listPane();if(!L)return;const A=currentAcc();
      if(!accs().length){w.body.innerHTML=`<div class="mx"><div class="center">${ICON.mail()}<h2 style="margin:0;color:var(--text)">Welcome to Mail</h2><p>Add your email accounts. Gmail and Outlook accounts can show your emails right here; others open with one tap.</p><button class="btn primary" data-first style="padding:10px 18px">${SVG.plus} Add Your First Account</button></div></div>`;
        $("[data-first]",w.body).onclick=()=>accountSheet(w.el,null,acc=>{shell();if(acc)st.view=acc.id;drawSide();loadList();Widgets.mail()});return}
      if(A&&!MT.connected(A)){showShortcut(A);return}
      const targets=A?[A]:conn();
      if(!targets.length){const all=accs();
        L.innerHTML=`<div class="lh"><b>Your inboxes</b><small>Tap to open</small></div><div class="msgs">${all.map(a=>`<div class="m" data-open="${a.id}"><i class="strip" style="background:${accColor(a)}"></i><div class="fr"><b>${esc(accLabel(a))}</b><span class="dt" style="color:var(--accent);font-weight:600">Open ↗</span></div><div class="sn">${esc(a.email)} · ${esc(OPEN_WITH[a.openWith]||(MAILP[a.provider]||{}).name||"")}</div></div>`).join("")||`<div class="center" style="padding:40px 20px">Add your email accounts with <b>Add Account</b>.</div>`}</div>`;
        $$("[data-open]",L).forEach(el=>el.onclick=()=>MailHub.inbox(accs().find(a=>a.id===el.dataset.open)));
        reader().innerHTML=`<div class="center">${ICON.mail()}<div style="max-width:340px">Tap an account to open its inbox in one tap.${accs().some(a=>kindOf(a))?`<br><span class="muted" style="font-size:12px">To read Gmail and Outlook emails right inside Nimbus instead, do the one-time <a href="#" data-setup3>connection setup</a>.</span>`:""}</div></div>`;
        const s3=$("[data-setup3]",reader());if(s3)s3.onclick=e=>{e.preventDefault();setupSheet(w.el)};return}
      const rid=++st.reqId;if(!more){st.items=[];st.next={};L.innerHTML=`<div class="lh"><b>${esc(A?FNAMES[st.folder]||"Inbox":"All Inboxes")}</b><small>${esc(A?accLabel(A):`${targets.length} accounts`)}</small></div><div class="center"><div class="spin"></div></div>`}
      const errs=[];
      const res=await Promise.all(targets.map(async a=>{if(more&&!st.next[a.id])return [];try{const r=await Mail.list(a,A?st.folder:"inbox",{q:st.q,page:more?st.next[a.id]:null});st.next[a.id]=r.next;return r.items}catch(e){errs.push([a,e]);return []}}));
      if(rid!==st.reqId)return;
      st.items=[...st.items,...res.flat()];st.items.sort((x,y)=>y.date-x.date);drawList(errs);
      if(!st.sel&&st.items[0]&&innerWidth>900){} };
    const drawList=(errs=[])=>{const L=listPane();if(!L)return;const A=currentAcc();
      const needAuth=errs.filter(([a,e])=>e instanceof NeedAuth);const other=errs.filter(([a,e])=>!(e instanceof NeedAuth));
      L.innerHTML=`<div class="lh"><b>${esc(st.q?`“${st.q}”`:A?FNAMES[st.folder]||"Inbox":"All Inboxes")}</b><small>${st.items.length} message${st.items.length===1?"":"s"}</small></div>
        ${needAuth.map(([a])=>`<div class="conn" style="margin:8px 12px;padding:10px 12px"><b>${esc(accLabel(a))}</b> needs you to sign in again. <button class="btn primary" data-reauth="${a.id}" style="padding:4px 10px;font-size:12px;margin-left:6px">Reconnect</button></div>`).join("")}
        ${other.map(([a,e])=>`<div class="conn" style="margin:8px 12px;padding:10px 12px;color:#ff3b30">${esc(accLabel(a))}: ${esc(String(e.message||e).slice(0,120))}</div>`).join("")}
        <div class="msgs">${st.items.map(m=>{const a=accs().find(x=>x.id===m.acc);return `<div class="m ${m.unread?"unread":""} ${st.sel&&st.sel.id===m.id?"act":""}" data-id="${esc(m.id)}" data-acc="${m.acc}">${!A&&a?`<i class="strip" style="background:${accColor(a)}"></i>`:""}${m.unread?`<i class="ud"></i>`:""}
          <div class="fr"><b>${esc(st.folder==="sent"&&A?("To: "+(m.to||"")):(m.from.name||m.from.email||"(unknown)"))}</b><span class="dt">${m.att?"📎 ":""}${m.starred?"★ ":""}${esc(fmtMailDate(m.date))}</span></div>
          <div class="sj">${esc(m.subject||"(no subject)")}</div><div class="sn">${esc(m.snippet||"")}</div></div>`}).join("")||`<div class="center" style="padding:40px 20px">No messages</div>`}
          ${Object.values(st.next).some(Boolean)?`<button class="btn more" data-more>Load more</button>`:""}</div>`;
      $$("[data-reauth]",L).forEach(b=>b.onclick=()=>connectAccount(accs().find(a=>a.id===b.dataset.reauth),{silent:true}));
      $$(".m",L).forEach(el=>{el.onclick=()=>openMsg(st.items.find(x=>x.id===el.dataset.id&&x.acc===el.dataset.acc));
        longPress(el,e=>{const m=st.items.find(x=>x.id===el.dataset.id&&x.acc===el.dataset.acc);UI.menu([{label:"Open",action:()=>openMsg(m)},{label:m.unread?"Mark as Read":"Mark as Unread",action:()=>act("read",m)},{label:m.starred?"Unstar":"Star",action:()=>act("star",m)},"-",{label:"Archive",action:()=>act("archive",m)},{label:"Delete",action:()=>act("trash",m)}],e.clientX,e.clientY)})});
      const mb=$("[data-more]",L);if(mb)mb.onclick=()=>loadList(true);
      if(!st.sel)reader().innerHTML=`<div class="center">${ICON.mail()}<div>${st.items.length?"Select a message to read it":"Nothing here"}</div></div>`};
    const act=async(kind,m,silent)=>{const a=accs().find(x=>x.id===m.acc);try{
        if(kind==="read"){await Mail.setRead(a,m.id,m.unread);m.unread=!m.unread}
        if(kind==="star"){await Mail.setStar(a,m.id,!m.starred);m.starred=!m.starred}
        if(kind==="archive"||kind==="trash"){await Mail[kind](a,m.id);st.items=st.items.filter(x=>x!==m);if(st.sel&&st.sel.id===m.id){st.sel=null}if(!silent)UI.toast(kind==="archive"?"Archived":"Moved to Trash",m.subject||"","mail")}
        drawList();Unread.refresh()}catch(e){if(e instanceof NeedAuth)return connectAccount(a,{silent:true});UI.toast("Couldn't do that",String(e.message||e).slice(0,120),"mail")}};
    const openMsg=async m=>{if(!m)return;st.sel=m;$$(".m",listPane()).forEach(el=>el.classList.toggle("act",el.dataset.id===m.id&&el.dataset.acc===m.acc));
      const a=accs().find(x=>x.id===m.acc);const R=reader();R.innerHTML=`<div class="center"><div class="spin"></div></div>`;
      let full;try{full=await Mail.get(a,m.id)}catch(e){if(e instanceof NeedAuth){R.innerHTML=`<div class="center"><p>${esc(accLabel(a))} needs you to sign in again.</p><button class="btn primary" data-re>Reconnect</button></div>`;$("[data-re]",R).onclick=()=>connectAccount(a,{silent:true});return}
        R.innerHTML=`<div class="center" style="color:#ff3b30">${esc(String(e.message||e))}</div>`;return}
      if(st.sel!==m)return;st.msg={...full,acc:a.id};
      const fr=full.from;const nm=fr.name||fr.email;
      R.innerHTML=`<div class="rbar"><button class="btn" data-r="reply">↩︎ Reply</button><button class="btn" data-r="all">↩︎↩︎ Reply All</button><button class="btn" data-r="fwd">↪︎ Forward</button>
          <span style="flex:1"></span><button class="btn" data-r="star">${m.starred?"★ Unstar":"☆ Star"}</button><button class="btn" data-r="unread">Mark Unread</button><button class="btn" data-r="archive">Archive</button><button class="btn" data-r="trash" style="color:#ff3b30">Delete</button></div>
        <div class="rhead"><h2>${esc(full.subject||"(no subject)")}</h2><div class="rfrom"><div class="av" style="background:${favColor(fr.email||nm)}">${esc(initials(nm))}</div>
          <div class="who"><b>${esc(nm)}</b> <span class="muted">${esc(fr.name?`<${fr.email}>`:"")}</span><small>To: ${esc(full.to||"")}${full.cc?" · Cc: "+esc(full.cc):""}</small></div>
          <div class="muted" style="font-size:12px;text-align:right;white-space:nowrap">${esc(new Date(full.date).toLocaleString([], {weekday:"short",day:"numeric",month:"short",hour:"numeric",minute:"2-digit"}))}<br><span style="color:${accColor(a)}">● ${esc(accLabel(a))}</span></div></div></div>
        <div class="rbody"><iframe sandbox="allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer"></iframe></div>
        ${full.atts.length?`<div class="ratts">${full.atts.map((t,i)=>`<div class="ratt" data-att="${i}">📎 <b>${esc(t.name)}</b><span class="muted">${fmtSize(t.size)}</span></div>`).join("")}</div>`:""}`;
      $("iframe",R).srcdoc=emailDoc(full);
      $$("[data-att]",R).forEach(el=>el.onclick=e=>{const t=full.atts[+el.dataset.att];const r=el.getBoundingClientRect();UI.menu([
        {label:"Open",action:()=>saveAtt(a,full,t,true)},{label:"Save to Downloads",action:()=>saveAtt(a,full,t,false)},{label:"Share / Export…",action:async()=>{const b=await Mail.attachment(a,full.id,t);shareFile({blob:b,name:t.name,mime:t.mime})}}],r.left,r.top-140)});
      $$("[data-r]",R).forEach(b=>b.onclick=()=>{const k=b.dataset.r;if(k==="reply"||k==="all"||k==="fwd")return replyTo(a,full,k);
        if(k==="unread"){act("read",m)}else if(k==="star"){act("star",m).then(()=>openMsg(m))}else act(k,m)});
      if(m.unread){m.unread=false;$(`.m[data-id="${CSS.escape(m.id)}"]`,listPane())?.classList.remove("unread");$(`.m[data-id="${CSS.escape(m.id)}"] .ud`,listPane())?.remove();Mail.setRead(a,m.id,true).then(()=>Unread.refresh()).catch(()=>{})}};
    const saveAtt=async(a,full,t,open)=>{try{UI.toast("Downloading",t.name,"mail");const b=await Mail.attachment(a,full.id,t);const id=await FS.addBlob("downloads",t.name,b);
        if(open){const e=await DB.fs.get(id);openEntry(e)}else UI.toast("Saved","Files › Downloads › "+t.name,"files")}catch(e){UI.toast("Couldn't download",String(e.message||e),"mail")}};
    const replyTo=async(a,full,kind)=>{const quote=`\n\nOn ${new Date(full.date).toLocaleString()}, ${full.from.name||full.from.email} wrote:\n`+(full.text||htmlToText(full.html)).split("\n").map(l=>"> "+l).join("\n");
      const subj=full.subject||"";
      if(kind==="fwd"){let atts=[];if(full.atts.length){UI.toast("Attaching",`${full.atts.length} file(s) from the original`,"mail");for(const t of full.atts){try{atts.push(new File([await Mail.attachment(a,full.id,t)],t.name,{type:t.mime||"application/octet-stream"}))}catch(e){}}}
        return openCompose({from:a.id,subject:/^fwd?:/i.test(subj)?subj:"Fwd: "+subj,body:`\n\n---------- Forwarded message ----------\nFrom: ${full.from.name||""} <${full.from.email}>\nDate: ${new Date(full.date).toLocaleString()}\nSubject: ${subj}\nTo: ${full.to}\n\n`+(full.text||htmlToText(full.html)),attach:atts})}
      const me=a.email.toLowerCase();const others=kind==="all"?[full.to,full.cc].join(",").split(",").map(s=>s.trim()).filter(s=>s&&!s.toLowerCase().includes(me)):[];
      openCompose({from:a.id,to:full.from.email,cc:others.join(", "),subject:/^re:/i.test(subj)?subj:"Re: "+subj,body:quote,reply:{acc:a.id,id:full.id,thread:full.thread,msgId:full.msgId,refs:full.refs,all:kind==="all"}})};
    const showShortcut=A=>{const L=listPane(),R=reader();const k=kindOf(A);const p=MAILP[A.provider]||MAILP.other;
      L.innerHTML=`<div class="lh"><b>${esc(accLabel(A))}</b><small>${esc(A.email)}</small></div>
        <div class="conn"><h4>Open ${esc(accLabel(A))}</h4><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" data-openin>${SVG.imp} Open Inbox ↗</button><button class="btn" data-newin>${PEN} New Message</button></div></div>
        ${k?`<div class="conn" style="opacity:.92"><h4 style="font-size:13px">Read these emails inside Nimbus instead?</h4>${MT.canConnect(A)?`Sign in once with ${k==="g"?"Google":"Microsoft"} and the inbox appears right here.<div style="margin-top:8px"><button class="btn" data-connect>Connect ${esc(p.name.split(" ")[0])}</button></div>`
          :`That needs a one-time registration with ${k==="g"?"Google":"Microsoft"}. Until then, Open Inbox takes you straight to your emails.<div style="margin-top:8px"><button class="btn" data-setup2>Connection setup…</button></div>`}</div>`
          :`<div class="conn"><h4>${esc(p.name)} opens with one tap</h4>${esc(p.name)} doesn't let other apps read your emails, so this account opens in ${A.openWith==="web"?"Safari":"its app"} — your passwords and Face ID work there.</div>`}`;
      R.innerHTML=`<div class="mh" style="flex:1;display:flex;min-height:0"><div class="detail" data-detail></div></div>`;
      const d=$("[data-detail]",R);const fl=p.folderUrl&&A.openWith!=="applemail"&&A.openWith!=="spark"?Object.keys(p.folders):[];
      d.innerHTML=`<div class="dhead"><div class="av" style="background:${accColor(A)}">${esc(accInitial(A))}</div><div style="min-width:0"><h2>${esc(accLabel(A))}</h2><div class="em">${esc(A.email)}</div><div class="muted" style="font-size:12px;margin-top:3px">${badge(A)} ${esc(p.name)} · opens with ${esc(OPEN_WITH[A.openWith]||"")}</div></div><button class="btn" data-edit style="margin-left:auto">Edit</button></div>
        <div class="dbody"><div class="big"><button class="btn primary" data-inbox>${SVG.imp} Open Inbox</button><button class="btn" data-new>${PEN} New Message</button></div>
        ${fl.length?`<div class="sect">Mailboxes</div><div class="folders">${fl.map(f=>`<div class="folder" data-folder="${f}">${FOLDER_ICONS[f]||SVG.docs}${FOLDER_NAMES[f]||f}</div>`).join("")}</div>`:""}
        <div class="sect">Search</div><div class="searchrow"><input class="field" data-sq placeholder="Search ${esc(accLabel(A))} mail…"><button class="btn" data-sgo>${SVG.search.replace("<svg",'<svg width="15" height="15"')}</button></div></div>`;
      $("[data-edit]",d).onclick=()=>accountSheet(w.el,A,()=>{drawSide();loadList();Widgets.mail()});$("[data-inbox]",d).onclick=()=>MailHub.inbox(A);$("[data-new]",d).onclick=()=>openCompose({from:A.id});
      $$("[data-folder]",d).forEach(f=>f.onclick=()=>MailHub.folder(A,f.dataset.folder));const sq=$("[data-sq]",d);$("[data-sgo]",d).onclick=()=>sq.value.trim()&&MailHub.search(A,sq.value.trim());sq.onkeydown=e=>{if(e.key==="Enter"&&sq.value.trim())MailHub.search(A,sq.value.trim())};
      $("[data-openin]",L).onclick=()=>MailHub.inbox(A);$("[data-newin]",L).onclick=()=>openCompose({from:A.id});
      const c=$("[data-connect]",L);if(c)c.onclick=()=>connectAccount(A);const s2=$("[data-setup2]",L);if(s2)s2.onclick=()=>setupSheet(w.el)};
    if(opts&&opts.account){st.view=opts.account}
    if(accs().length)shell();loadList();
    const kh=e=>{if(WM.active!==w)return;if((e.metaKey||e.ctrlKey)&&e.key==="n"){e.preventDefault();openCompose({from:currentAcc()?.id})}
      if(st.sel&&!e.target.closest("input,textarea")){const i=st.items.indexOf(st.sel);if(e.key==="ArrowDown"&&i<st.items.length-1){e.preventDefault();openMsg(st.items[i+1])}if(e.key==="ArrowUp"&&i>0){e.preventDefault();openMsg(st.items[i-1])}
        if(e.key==="Backspace"||e.key==="Delete"){e.preventDefault();act("trash",st.sel)}}};
    document.addEventListener("keydown",kh);
    const poll=setInterval(()=>{if(document.visibilityState==="visible"&&!st.q&&st.folder==="inbox")loadList()},3*60*1000);
    return {redraw(){if(!$("[data-side]",w.body)&&accs().length)shell();drawSide();loadList()},badges:drawSide,
      reopenMail(o){if(o&&o.account){st.view=o.account;st.folder="inbox";st.sel=null;drawSide();loadList()}},close(){document.removeEventListener("keydown",kh);clearInterval(poll)}}},
  reopen(w,o){w.hooks.reopenMail&&w.hooks.reopenMail(o)}
};

/* ================= Compose (sends directly from connected accounts) ================= */
APPS.compose={name:"New Message",icon:"mail",w:680,h:600,hidden:true,
  create(w,opts){
    const accs=mailAccounts();let atts=[...(opts.attach||[])];
    const pick=accs.find(a=>a.id===opts.from)||accs.find(a=>MT.connected(a))||accs[0];
    w.body.innerHTML=`<div class="compose"><div class="ctool"><button class="sendb" data-send title="Send (⌘↩)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M21 3 10 14M21 3l-7 18-4-7-7-4z"/></svg></button>
        <button class="btn" data-attach><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m21 12-8.5 8.5a5 5 0 0 1-7-7L14 5a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 8"/></svg>Attach</button>
        <span style="flex:1"></span><span class="muted" style="font-size:12px" data-sendvia></span></div>
      <div class="cf"><span>To:</span><input data-to type="email" multiple autocapitalize="off" autocorrect="off" value="${esc(opts.to||"")}"></div>
      <div class="cf"><span>Cc:</span><input data-cc type="email" multiple autocapitalize="off" autocorrect="off" value="${esc(opts.cc||"")}"></div>
      <div class="cf"><span>Subject:</span><input data-sub value="${esc(opts.subject||"")}" style="font-weight:600"></div>
      <div class="cf"><span>From:</span>${accs.length?`<span data-fdot style="width:10px;height:10px;border-radius:50%;flex:none;display:inline-block"></span><select data-from>${accs.map(a=>`<option value="${a.id}" ${pick&&a.id===pick.id?"selected":""}>${esc(accLabel(a))} — ${esc(a.email)}${MT.connected(a)?"  ✓":""}</option>`).join("")}</select>`:`<em class="muted" style="font-size:13px">No accounts yet — the iPad's Mail app will be used.</em>`}</div>
      <textarea class="editor" data-body placeholder="Write your message…"></textarea>
      <div class="atts" data-atts style="display:none"></div><div class="via" data-via></div></div>`;
    const f=k=>$(`[data-${k}]`,w.body);const cur=()=>accs.find(a=>a.id===(f("from")&&f("from").value));
    f("body").value=opts.body||"";let lastSig="";
    const applySig=()=>{const a=cur();const body=f("body");const sig=a&&a.signature?`\n\n${a.signature}`:"";
      if(opts.body){if(lastSig&&body.value.startsWith(lastSig))body.value=body.value.slice(lastSig.length);body.value=sig+body.value}
      else{if(lastSig&&body.value.endsWith(lastSig))body.value=body.value.slice(0,-lastSig.length);body.value+=sig}
      lastSig=sig;if(f("fdot"))f("fdot").style.background=a?accColor(a):"#8e8e93";updVia()};
    const direct=()=>{const a=cur();return a&&MT.connected(a)};
    const updVia=()=>{const a=cur();const p=a?MAILP[a.provider]||MAILP.other:null;
      if(direct()){f("via").textContent=`Sends directly from ${a.email}${atts.length?` with ${atts.length} attachment${atts.length>1?"s":""}`:""}. A copy goes to your Sent folder.`;f("sendvia").textContent="✓ Sends from Nimbus";return}
      f("via").textContent=atts.length?"With attachments, Send opens the iPad share sheet — choose your mail app there.":!a?"Send opens the iPad's Mail app.":a.openWith==="web"&&p.compose?`Send opens ${p.name} in Safari with everything filled in — tap Send there.${kindOf(a)?" Connect this account in Mail to send directly from Nimbus.":""}`:"Send opens your mail app with everything filled in.";
      f("sendvia").textContent=a?`via ${a.openWith==="web"?p.name:OPEN_WITH[a.openWith]}`:""};
    if(f("from"))f("from").onchange=applySig;applySig();
    const drawAtts=()=>{const box=f("atts");box.style.display=atts.length?"flex":"none";box.innerHTML=atts.map((x,i)=>`<div class="att">📎 ${esc(x.name)} <span class="muted">${fmtSize(x.size)}</span><u data-i="${i}">✕</u></div>`).join("");
      $$("u",box).forEach(u=>u.onclick=()=>{atts.splice(+u.dataset.i,1);drawAtts()});updVia()};drawAtts();
    f("attach").onclick=e=>{const r=e.target.getBoundingClientRect();UI.menu([{label:"From the iPad…",action:()=>pickFiles(fl=>{atts.push(...fl);drawAtts()})},
      {label:"From Nimbus Files…",action:async()=>{const all=(await DB.fs.all()).filter(x=>x.type==="file").sort((a,b)=>b.mtime-a.mtime).slice(0,25);
        UI.menu(all.length?all.map(x=>({label:x.name,action:()=>{atts.push(new File([x.blob],x.name,{type:x.mime||"application/octet-stream"}));drawAtts()}})):[{label:"No files yet",disabled:true}],r.left,r.bottom+4)}}],r.left,r.bottom+4)};
    w.setTitle(opts.subject||"New Message");f("sub").oninput=()=>w.setTitle(f("sub").value||"New Message");
    let dirty=false,sending=false;["to","cc","sub","body"].forEach(k=>f(k).addEventListener("input",()=>dirty=true));
    const send=async()=>{if(sending)return;const m={to:f("to").value.trim(),cc:f("cc").value.trim(),subject:f("sub").value,body:f("body").value,atts};const a=cur();
      if(direct()){if(!m.to)return f("to").focus();const size=atts.reduce((t,x)=>t+x.size,0);
        if(kindOf(a)==="m"&&size>3*1048576)return UI.toast("Attachments too big for direct send","Outlook allows about 3 MB here. Remove some, or use the share sheet.","mail");
        if(size>24*1048576)return UI.toast("Attachments too big","Email allows about 25 MB in total.","mail");
        sending=true;f("send").style.opacity=.5;f("sendvia").textContent="Sending…";
        try{const r=opts.reply&&opts.reply.acc===a.id?opts.reply:null;
          await Mail.send(a,{...m,thread:r&&r.thread,inReplyTo:r&&r.msgId,references:r&&r.refs,replyId:r&&r.id,replyAll:r&&r.all});
          UI.toast("Sent",`From ${a.email}`,"mail");dirty=false;WM.close(w)}
        catch(e){sending=false;f("send").style.opacity=1;updVia();if(e instanceof NeedAuth){if(await UI.confirm("Sign in again?",`${accLabel(a)} needs you to sign in again before sending. Your message will be lost when Nimbus reloads — copy it first if needed.`,"Reconnect"))connectAccount(a,{silent:true});return}
          UI.toast("Couldn't send",String(e.message||e).slice(0,140),"mail")}return}
      if(atts.length){const text=(m.to?`To: ${m.to}\n`:"")+m.body;try{if(navigator.canShare&&navigator.canShare({files:atts})){await navigator.share({files:atts,title:m.subject,text});WM.close(w);return}}catch(err){if(err.name==="AbortError")return}
        return UI.toast("Can't attach here","This browser can't share files.","mail")}
      const url=a?MailHub.composeUrl(a,m):MailHub.composeUrl({provider:"other",openWith:"applemail"},m);if(a){a.lastOpened=Date.now();saveSettings()}
      openLink(url);UI.toast("Handed off","Tap Send in the mail app to deliver it.","mail");dirty=false;WM.close(w)};
    f("send").onclick=send;
    w.body.addEventListener("keydown",e=>{if((e.metaKey||e.ctrlKey)&&e.key==="Enter"){e.preventDefault();send()}});
    setTimeout(()=>{const t=opts.to?f("body"):f("to");t.focus();if(t===f("body"))t.setSelectionRange(0,0)},80);
    return {async beforeClose(){if(!dirty||sending)return true;return !!(await UI.confirm("Discard this message?","It hasn't been sent.","Discard",true))}}}
};

/* account sheet: add Connect button for Gmail/Outlook */
const _accSheet=accountSheet;
accountSheet=function(host,acc,onDone){_accSheet(host,acc,a=>{onDone&&onDone(a);if(a&&kindOf(a)&&!MT.connected(a)&&acc==null&&!SANDBOXED){setTimeout(async()=>{
    if(!MT.canConnect(a)){if(await UI.confirm("Show emails inside Nimbus?",`${accLabel(a)} is a ${(MAILP[a.provider]||{}).name} account — it can show your emails right here after a one-time setup.`,"Set up now"))setupSheet(host)}
    else if(await UI.confirm(`Connect ${accLabel(a)}?`,"Sign in now so this account's emails show in Nimbus.","Connect"))connectAccount(a,{silent:true})},300)}})};

/* ================= boot ================= */
const _bootPrev=window.NIMBUS_BOOT;
window.NIMBUS_BOOT=async function(){await _bootPrev();await MT.load();
  const a=await handleOAuthReturn();const reopen=await DB.get("oauth-reopen");await DB.del("oauth-reopen");
  const reApp=await DB.get("oauth-reopen-app");await DB.del("oauth-reopen-app");
  if(reApp&&reApp.app){setTimeout(()=>WM.open(reApp.app,{acc:reApp.acc}),400)}else if(a||reopen){setTimeout(()=>WM.open("mail",{account:(a||{}).id||(reopen||{}).acc}),400)}
  Unread.refresh()};
/* boot is started by nimbus-neo.js */
