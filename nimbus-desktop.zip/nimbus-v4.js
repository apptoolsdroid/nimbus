/* =====================================================================
   Nimbus 4.0
   - Nimbus Linux: Tiny Core boots straight into a Nimbus-styled Terminal
     (kernel + core.gz read from the ISO, serial console, xterm.js).
     The old Tiny Core desktop stays available as "Classic desktop".
   - Version, What's New and update checks.
   ===================================================================== */

/* ---------------------------- Release notes ---------------------------- */
const CHANGELOG=[
  {v:"4.0",date:"16 Nov 2026",title:"Nimbus Linux, reimagined",items:[
    ["linux","Linux opens as a Nimbus Terminal","Tiny Core now starts straight into a clean, glassy terminal that works with the iPad keyboard. It boots faster because it skips the old desktop."],
    ["settings","Classic desktop is one tap away","Need the graphical Tiny Core desktop? Switch the Linux window to Classic desktop at any time."],
    ["logo","Know which version you have","This What's New screen shows each release. Nimbus checks your GitHub site and offers a one-tap update when a newer version is there."],
    ["files","Updates actually arrive","Nimbus now loads its own files from the network first, so a new upload shows up on the next launch instead of staying stuck on an old copy. It still works offline."]]},
  {v:"3.7",date:"Nov 2026",title:"Cloud drives and a better browser",items:[
    ["files","Google Drive and OneDrive in Files","Browse, open, edit and save back to your cloud drives without leaving Nimbus."],
    ["web","Favourites bar, bookmarks and history","Star pages, keep a favourites bar, and add any site to the Dock as an app. Outside links open in a Safari window instead of taking over the screen."],
    ["preview","PDF, video and audio viewer","Open PDFs and media straight from Files or Cloud Drive."]]},
  {v:"3.x",date:"Earlier",title:"Earlier highlights",items:[
    ["mail","Real Gmail and Outlook inboxes","A unified inbox for your accounts, with sending, replying and unread badges."],
    ["reminders","Reminders, widgets and the Neo look","Reminders with Apple Reminders import, desktop widgets, Liquid Glass and new wallpapers."],
    ["docs","Documents, Sheets and Code","Word and Excel files, formulas, Monaco editor and Python."]]}
];
const VERSION=window.NIMBUS_VERSION||"4.0";
const vnum=v=>String(v).split(".").map(n=>parseInt(n,10)||0);
const newer=(a,b)=>{const x=vnum(a),y=vnum(b);for(let i=0;i<Math.max(x.length,y.length);i++){if((x[i]||0)!==(y[i]||0))return (x[i]||0)>(y[i]||0)}return false};

const V4CSS=`
.wn{flex:1;overflow:auto;padding:26px 30px 22px;background:var(--win-bg)}
.wn-hero{display:flex;gap:16px;align-items:center;margin-bottom:6px}
.wn-hero .lg{width:62px;height:62px;color:var(--accent);flex:none}
.wn-hero h1{margin:0;font-size:24px;letter-spacing:-.02em}
.wn-pill{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:99px;background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent);margin-top:5px}
.wn-pill.up{background:#ff9f0a22;color:#ff9f0a}
.wn-rel{margin-top:22px}
.wn-rel h3{margin:0 0 10px;font-size:13px;color:var(--muted,#888);font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.wn-rel h3 b{color:var(--fg,inherit);text-transform:none;letter-spacing:0;font-size:15px;margin-right:6px}
.wn-item{display:flex;gap:14px;align-items:flex-start;padding:10px 0}
.wn-item .ic{width:38px;height:38px;flex:none}
.wn-item b{display:block;font-size:14px;margin-bottom:2px}
.wn-item span{font-size:13px;line-height:1.45;opacity:.75}
.wn-foot{display:flex;gap:8px;justify-content:flex-end;margin-top:18px}
.upd-banner{position:fixed;top:38px;left:50%;transform:translateX(-50%);z-index:99990;display:flex;gap:12px;align-items:center;padding:9px 10px 9px 16px;border-radius:16px;font-size:13px;box-shadow:0 10px 40px rgba(0,0,0,.25)}
.upd-banner b{font-weight:600}
/* Nimbus Linux terminal */
.nlx{flex:1;display:flex;flex-direction:column;min-height:0;background:linear-gradient(160deg,rgba(28,30,44,.94),rgba(14,15,24,.96));color:#e8e8ef;position:relative}
.nlx-bar{display:flex;gap:6px;padding:7px 9px;align-items:center;flex-wrap:wrap;background:rgba(255,255,255,.04);border-bottom:1px solid rgba(255,255,255,.07)}
.nlx-bar .btn{padding:5px 9px;font-size:12px;background:rgba(255,255,255,.08);color:#e8e8ef;border-color:rgba(255,255,255,.08)}
.nlx-bar .btn.on{background:var(--accent);color:#fff}
.nlx-bar .seg{background:rgba(255,255,255,.08)}
.nlx-bar .seg button{color:#e8e8ef;padding:4px 10px;font-size:12px}
.nlx-bar .seg button.on{background:rgba(255,255,255,.2);color:#fff}
.nlx-bar .info{margin-left:auto;font-size:11.5px;opacity:.6}
.nlx-term{flex:1;min-height:0;padding:10px 4px 6px 12px;position:relative}
.nlx-term .xterm{height:100%}
.nlx-term .xterm-viewport{background:transparent!important}
.nlx-term .xterm-viewport::-webkit-scrollbar{width:8px}
.nlx-term .xterm-viewport::-webkit-scrollbar-thumb{background:rgba(255,255,255,.18);border-radius:8px}
.nlx-card{position:absolute;inset:44px 0 0 0;display:flex;align-items:center;justify-content:center;transition:opacity .45s;z-index:3;background:radial-gradient(circle at 50% 40%,rgba(60,70,120,.35),rgba(10,10,18,.2) 70%)}
.nlx-card.hide{opacity:0;pointer-events:none}
.nlx-card .box{width:min(380px,86%);text-align:center;padding:26px 24px 20px;border-radius:22px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(30px);-webkit-backdrop-filter:blur(30px);box-shadow:0 20px 60px rgba(0,0,0,.35)}
.nlx-card .lg{width:58px;height:58px;margin:0 auto 10px;color:#8fc3ff}
.nlx-card h2{margin:0 0 4px;font-size:19px;font-weight:650;letter-spacing:-.01em}
.nlx-card p{margin:6px 0;font-size:13px;opacity:.75;line-height:1.45}
.nlx-card .bar{height:5px;border-radius:5px;background:rgba(255,255,255,.12);overflow:hidden;margin:14px 0 6px}
.nlx-card .bar i{display:block;height:100%;width:3%;border-radius:5px;background:linear-gradient(90deg,#64d2ff,#bf5af2);transition:width .5s}
.nlx-card .acts{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px}
.nlx-card .acts .btn{background:rgba(255,255,255,.1);color:#fff;border-color:rgba(255,255,255,.12)}
.nlx-card .acts .btn.primary{background:var(--accent);border-color:transparent}
.nlx-card .lnk{font-size:12px;opacity:.6;cursor:pointer;text-decoration:underline;margin-top:6px;display:inline-block}
.nlx-card ol{text-align:left;font-size:12.5px;line-height:1.55;opacity:.8;padding-left:18px;margin:10px 0 0}
.nlx-card a{color:#8fc3ff}
.lx-bar .seg{margin-left:4px}
`;
document.head.appendChild(Object.assign(document.createElement("style"),{textContent:V4CSS}));

/* ------------------------------ What's New ----------------------------- */
const Upd={latest:null,checking:false};
APPS.whatsnew={name:"What's New",icon:"logo",w:600,h:640,single:true,hidden:true,
  create(w){
    w.setTitle("What's New in Nimbus");
    const draw=()=>{
      const upd=Upd.latest&&newer(Upd.latest.version,VERSION);
      w.body.innerHTML=`<div class="wn">
        <div class="wn-hero"><div class="lg">${ICON.logo()}</div><div><h1>Nimbus ${esc(VERSION)}</h1>
          ${upd?`<span class="wn-pill up">Version ${esc(Upd.latest.version)} is available</span>`:`<span class="wn-pill">${Upd.latest?"You're on the latest version":"Installed version"}</span>`}</div></div>
        ${CHANGELOG.map((r,i)=>`<div class="wn-rel"><h3><b>${r.v===VERSION?"New in "+esc(r.v):esc(r.v==="3.x"?"Earlier":"Version "+r.v)}</b>${esc(r.date)} · ${esc(r.title)}</h3>
          ${r.items.map(([ic,t,d])=>`<div class="wn-item"><div class="ic" style="${ic==="logo"?"color:var(--accent)":""}">${(ICON[ic]||ICON.logo)()}</div><div><b>${esc(t)}</b><span>${esc(d)}</span></div></div>`).join("")}</div>`).join("")}
        <div class="wn-foot">${upd?`<button class="btn primary" data-up>Update to ${esc(Upd.latest.version)}</button>`:`<button class="btn" data-chk>Check for updates</button>`}<button class="btn ${upd?"":"primary"}" data-ok>Continue</button></div></div>`;
      $("[data-ok]",w.body).onclick=()=>WM.close(w);
      const u=$("[data-up]",w.body);if(u)u.onclick=()=>applyUpdate();
      const c=$("[data-chk]",w.body);if(c)c.onclick=async()=>{c.textContent="Checking…";await checkUpdate(true);draw()};
    };
    draw();S.seenVersion=VERSION;saveSettings();
    return {}}
};
function whatsNew(){WM.open("whatsnew")}
window.whatsNew=whatsNew;

async function checkUpdate(manual){
  if(Upd.checking)return Upd.latest;
  if(SANDBOXED||!/^https?:$/.test(location.protocol)){if(manual)UI.toast("Can't check here","Update checks work in the installed version of Nimbus.");return null}
  Upd.checking=true;
  try{
    const r=await fetch("version.json?t="+Date.now(),{cache:"no-store"});
    if(!r.ok)throw new Error("version.json not found ("+r.status+")");
    Upd.latest=await r.json();
    if(newer(Upd.latest.version,VERSION))showUpdateBanner();
    else if(manual)UI.toast("Nimbus is up to date",`Version ${VERSION} is the latest.`);
  }catch(e){if(manual)UI.toast("Couldn't check for updates",e.message)}
  finally{Upd.checking=false}
  return Upd.latest}
window.checkUpdate=checkUpdate;

function showUpdateBanner(){
  if($(".upd-banner"))return;
  const b=html(`<div class="upd-banner glass"><div><b>Nimbus ${esc(Upd.latest.version)} is available</b><div style="font-size:12px;opacity:.8">${esc(Upd.latest.headline||"Tap Update to get the latest version.")}</div></div>
    <button class="btn" data-n>What's New</button><button class="btn primary" data-u>Update</button><button class="btn" data-x title="Later">✕</button></div>`);
  document.body.appendChild(b);
  $("[data-u]",b).onclick=()=>applyUpdate();
  $("[data-n]",b).onclick=()=>{b.remove();whatsNew()};
  $("[data-x]",b).onclick=()=>b.remove()}

async function applyUpdate(){
  if(LX.running){const ok=await UI.dialog({title:"Linux is running",text:"Updating reloads Nimbus and stops Linux. Continue?",ok:"Update",cancel:"Later"});if(!ok)return}
  UI.toast("Updating Nimbus…","This takes a few seconds.");
  try{
    const reg=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();
    if(reg){try{await reg.update()}catch(e){}}
    if(window.caches){const ks=await caches.keys();await Promise.all(ks.filter(k=>/^nimbus-v/.test(k)).map(k=>caches.delete(k)))}
  }catch(e){console.warn(e)}
  setTimeout(()=>location.reload(),600)}
window.applyUpdate=applyUpdate;

/* menu + settings hooks (buttons rendered by index.html) */
document.addEventListener("click",e=>{
  if(e.target.closest("[data-whatsnew]"))whatsNew();
  else if(e.target.closest("[data-checkupd]"))checkUpdate(true)});

/* ------------------------- ISO 9660 + cpio tools ------------------------ */
const ISO9660={
  async open(blob){
    const sec=async(lba,n=1)=>new Uint8Array(await blob.slice(lba*2048,(lba+n)*2048).arrayBuffer());
    let pvd=null;
    for(let i=16;i<40;i++){const s=await sec(i);if(s[1]===0x43&&s[2]===0x44&&s[3]===0x30&&s[4]===0x30&&s[5]===0x31){if(s[0]===1){pvd=s;break}if(s[0]===255)break}else break}
    if(!pvd)return null;
    const u32=(a,o)=>a[o]|(a[o+1]<<8)|(a[o+2]<<16)|(a[o+3]*16777216);
    const root={lba:u32(pvd,156+2),size:u32(pvd,156+10),dir:true};
    const list=async d=>{const n=Math.ceil(d.size/2048),buf=await sec(d.lba,n),out=[];let o=0;
      while(o<d.size&&o<buf.length){const len=buf[o];if(!len){o=(Math.floor(o/2048)+1)*2048;continue}
        const nl=buf[o+32];let name="";for(let i=0;i<nl;i++)name+=String.fromCharCode(buf[o+33+i]);
        if(nl===1&&(name==="\0"||name==="\x01")){o+=len;continue}
        name=name.replace(/;\d+$/,"").replace(/\.$/,"").toLowerCase();
        out.push({name,lba:u32(buf,o+2),size:u32(buf,o+10),dir:!!(buf[o+25]&2)});o+=len}
      return out};
    const find=async path=>{let cur=root;for(const part of path.split("/").filter(Boolean)){if(!cur.dir)return null;const hit=(await list(cur)).find(e=>e.name===part.toLowerCase());if(!hit)return null;cur=hit}return cur};
    return {find,list,
      async file(path){const e=await find(path);return e&&!e.dir?blob.slice(e.lba*2048,e.lba*2048+e.size):null},
      async text(path){const b=await this.file(path);return b?await b.text():null}}}
};
const CPIO={
  /* find files by name in an uncompressed newc archive */
  extract(u8,wanted){const td=new TextDecoder(),out={};let o=0;const hex=(a,b)=>parseInt(td.decode(u8.subarray(a,b)),16);
    while(o+110<=u8.length){const mg=td.decode(u8.subarray(o,o+6));if(mg!=="070701"&&mg!=="070702")break;
      const fsz=hex(o+54,o+62),nsz=hex(o+94,o+102);const name=td.decode(u8.subarray(o+110,o+110+nsz-1)).replace(/^\.?\//,"");
      if(name==="TRAILER!!!")break;let d=(o+110+nsz+3)&~3;
      if(wanted.includes(name))out[name]=u8.subarray(d,d+fsz);
      o=(d+fsz+3)&~3}
    return out},
  build(files){const te=new TextEncoder(),parts=[];let ino=900000,len=0;
    const h=n=>n.toString(16).padStart(8,"0");
    const push=a=>{parts.push(a);len+=a.length;const pad=(4-(len%4))%4;if(pad){parts.push(new Uint8Array(pad));len+=pad}};
    const add=(name,data,mode)=>{const nb=te.encode(name+"\0");
      const hdr="070701"+h(ino++)+h(mode)+h(0)+h(0)+h(1)+h(Math.floor(Date.now()/1000))+h(data.length)+h(0)+h(0)+h(0)+h(0)+h(nb.length)+h(0);
      const hb=te.encode(hdr),hn=new Uint8Array(hb.length+nb.length);hn.set(hb);hn.set(nb,hb.length);push(hn);if(data.length)push(data)};
    for(const f of files)add(f.name,typeof f.data==="string"?te.encode(f.data):f.data,f.mode||0o100644);
    add("TRAILER!!!",new Uint8Array(0),0);
    const out=new Uint8Array(len);let p=0;for(const a of parts){out.set(a,p);p+=a.length}return out}
};
const gunzip=async blob=>new Uint8Array(await new Response(blob.stream().pipeThrough(new DecompressionStream("gzip"))).arrayBuffer());
const gzip=async u8=>new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new CompressionStream("gzip"))).arrayBuffer());

/* files added on top of Tiny Core's own core.gz */
const NIMBUS_INIT=`# Nimbus terminal setup (sourced by the login shell)
stty cols \${1:-100} rows \${2:-30} 2>/dev/null
for t in xterm-256color xterm vt100; do
  for d in /usr/share/terminfo /usr/local/share/terminfo /usr/lib/terminfo; do
    [ -e "$d/\${t%"\${t#?}"}/$t" ] && { export TERM=$t; break 2; }
  done
done
export PS1='\\[\\033[38;5;117m\\]\\u\\[\\033[0m\\]@\\[\\033[38;5;183m\\]nimbus\\[\\033[0m\\] \\[\\033[38;5;151m\\]\\w\\[\\033[0m\\] \\$ '
alias ls='ls --color=auto' ll='ls -lh --color=auto' la='ls -lah --color=auto'
clear
printf '\\033]0;Nimbus Linux\\007'
V=$(version 2>/dev/null)
printf '\\n  \\033[1;38;5;117m\\342\\230\\201  Nimbus Linux\\033[0m  \\033[2m\\302\\267  Tiny Core %s  \\302\\267  32-bit\\033[0m\\n' "$V"
cat /etc/nimbus-motd
`;
const NIMBUS_MOTD=`  \x1b[2m──────────────────────────────────────────────\x1b[0m
  \x1b[38;5;151mtce-load -wi nano\x1b[0m    install an app (needs a network relay)
  \x1b[38;5;151mmount /mnt/sdb\x1b[0m       your Files › Linux Shared folder
  \x1b[38;5;151mls /mnt/sda1\x1b[0m         the permanent Linux drive
  \x1b[38;5;151mfiletool.sh -b\x1b[0m       back up your home folder before stopping
  \x1b[2m──────────────────────────────────────────────\x1b[0m

`;

/* ------------------------- Nimbus Linux (terminal) ------------------------ */
S.linuxMode=S.linuxMode||"terminal";
Object.assign(LX,{
  kit:null,
  /* read kernel, initrd and boot options from a Tiny Core ISO, add the Nimbus overlay */
  async tcKit(iso,progress=()=>{}){
    const key=(LX.isoName||"")+":"+iso.size;
    if(LX.kit&&LX.kit.key===key)return LX.kit;
    progress("Reading the Linux disk…",6);
    const fs=await ISO9660.open(iso);if(!fs)return null;
    let kernel="/boot/vmlinuz",initrd="/boot/core.gz",append="loglevel=3 cde";
    const cfg=await fs.text("/boot/isolinux/isolinux.cfg")||await fs.text("/isolinux/isolinux.cfg");
    if(cfg){const lines=cfg.split(/\r?\n/).map(l=>l.trim());
      const def=(lines.find(l=>/^default\s+/i.test(l))||"").split(/\s+/)[1];
      const blocks={};let cur=null;
      for(const l of lines){const m=l.match(/^label\s+(\S+)/i);if(m){cur=blocks[m[1].toLowerCase()]={};continue}
        if(!cur)continue;const k=l.match(/^(kernel|linux)\s+(\S+)/i),a=l.match(/^append\s+(.*)/i),i=l.match(/^initrd\s+(\S+)/i);
        if(k)cur.kernel=k[2];if(a)cur.append=a[1];if(i)cur.initrd=i[1]}
      const b=(def&&blocks[def.toLowerCase()])||Object.values(blocks).find(x=>x.kernel&&/vmlinuz/.test(x.kernel));
      if(b){if(b.kernel)kernel=b.kernel;if(b.append){const ir=b.append.match(/initrd=(\S+)/);if(ir)initrd=ir[1].split(",")[0];append=b.append}if(b.initrd)initrd=b.initrd}}
    const kb=await fs.file(kernel),ib=await fs.file(initrd);
    if(!kb||!ib)return null;
    progress("Preparing Nimbus Linux…",14);
    const core=await gunzip(ib);
    const found=CPIO.extract(core,["etc/inittab"]);
    let inittab=found["etc/inittab"]?new TextDecoder().decode(found["etc/inittab"]):
      "::sysinit:/etc/init.d/rcS\ntty1::respawn:/sbin/getty -nl /sbin/autologin 38400 tty1\n::restart:/etc/init.d/rc.shutdown\n::restart:/sbin/init\n::ctrlaltdel:/sbin/reboot\n::shutdown:/etc/init.d/rc.shutdown\n";
    if(!/^ttyS0:/m.test(inittab))inittab=inittab.replace(/\s*$/,"\n")+"ttyS0::respawn:/sbin/getty -L 115200 ttyS0 vt100\n";
    const overlay=await gzip(CPIO.build([
      {name:"etc/inittab",data:inittab},
      {name:"usr/bin/nimbus-init",data:NIMBUS_INIT,mode:0o100755},
      {name:"etc/nimbus-motd",data:NIMBUS_MOTD}]));
    const ibuf=new Uint8Array(await ib.arrayBuffer());const padded=(ibuf.length+3)&~3;
    const all=new Uint8Array(padded+overlay.length);all.set(ibuf);all.set(overlay,padded);
    const cmd=append.replace(/\binitrd=\S+/g,"").replace(/\bvga=\S+/g,"").replace(/\bquiet\b/g,"").replace(/\bconsole=\S+/g,"").replace(/\s+/g," ").trim();
    LX.kit={key,bzimage:await kb.arrayBuffer(),initrd:all.buffer,cmdline:`${cmd} text loglevel=3 console=tty0 console=ttyS0,115200`.trim()};
    return LX.kit},
  async startTerminal(progress){
    const iso=await LX.getIso();if(!iso)throw new Error("No Linux disk loaded yet.");
    await LX.loadScript();
    const kit=await LX.tcKit(iso,progress);if(!kit)return null;
    progress("Starting the kernel…",22);
    LX.hddBuf=await LX.getHdd();LX.shBuf=await LX.buildShared();
    const opts={wasm_path:"v86.wasm",memory_size:S.linuxMem*1048576,vga_memory_size:8*1048576,
      bios:LX.bios("seabios"),vga_bios:LX.bios("vgabios"),cdrom:{buffer:await iso.arrayBuffer()},hda:{buffer:LX.hddBuf},hdb:{buffer:LX.shBuf},
      bzimage:{buffer:kit.bzimage.slice(0)},initrd:{buffer:kit.initrd.slice(0)},cmdline:kit.cmdline,
      autostart:true,disable_mouse:true,disable_keyboard:true};
    if(S.relay&&!SANDBOXED)opts.net_device={type:"ne2k",relay_url:S.relay};
    LX.emu=new V86(opts);LX.running=true;LX.termMode=true;Widgets.render();return LX.emu},
  async loadXterm(){
    if(window.Terminal&&window.FitAddon)return;
    if(!document.querySelector("link[data-xterm]")){const l=document.createElement("link");l.rel="stylesheet";l.href="lib/xterm/xterm.css";l.setAttribute("data-xterm","1");document.head.appendChild(l)}
    const d=window.define;try{window.define=undefined;await loadJS("lib/xterm/xterm.js");await loadJS("lib/xterm/addon-fit.js")}finally{window.define=d}}
});
const _lxStop4=LX.stop;
LX.stop=async function(){if(LX.emu&&LX.termMode){try{LX.emu.serial0_send("\x15sync\r")}catch(e){}await new Promise(r=>setTimeout(r,900))}LX.termMode=false;return _lxStop4()};

const TERM_THEME={background:"rgba(0,0,0,0)",foreground:"#e6e8f0",cursor:"#8fc3ff",cursorAccent:"#14151f",selectionBackground:"rgba(143,195,255,.3)",
  black:"#1c1d26",red:"#ff6b6b",green:"#7ee2a8",yellow:"#ffd479",blue:"#7cb8ff",magenta:"#d4a5ff",cyan:"#7fe0e8",white:"#d7dae4",
  brightBlack:"#6b6f80",brightRed:"#ff8f8f",brightGreen:"#9ff0bf",brightYellow:"#ffe3a3",brightBlue:"#a3ceff",brightMagenta:"#e3c2ff",brightCyan:"#a6eef3",brightWhite:"#ffffff"};

function linuxTerminalUI(w,opts,switchMode){
  LX.win=w;
  w.body.innerHTML=`<div class="nlx">
    <div class="nlx-bar">
      <button class="btn" data-a="power">${SVG.power}<span>Start</span></button>
      <div class="seg"><button class="on" data-m="terminal">Terminal</button><button data-m="desktop">Classic desktop</button></div>
      <button class="btn" data-k="esc">Esc</button><button class="btn" data-k="tab">Tab</button><button class="btn" data-a="ctrl">Ctrl</button><button class="btn" data-k="ctrlc">⌃C</button>
      <button class="btn" data-k="up">↑</button><button class="btn" data-k="down">↓</button><button class="btn" data-k="left">←</button><button class="btn" data-k="right">→</button>
      <button class="btn" data-a="paste">Paste</button><button class="btn" data-a="shared">${SVG.folderPlus||""}Shared</button><button class="btn" data-a="more">More…</button>
      <span class="info" data-info></span></div>
    <div class="nlx-term" data-term></div>
    <div class="nlx-card" data-card><div class="box" data-box></div></div></div>`;
  const termEl=$("[data-term]",w.body),card=$("[data-card]",w.body),box=$("[data-box]",w.body),pwr=$("[data-a=power]",w.body);
  const info=t=>$("[data-info]",w.body).textContent=t;
  let term=null,fit=null,state="off",tail="",ctrl=false,watchdog=null,lastSize="";
  const KEYSEQ={esc:"\x1b",tab:"\t",ctrlc:"\x03",up:"\x1b[A",down:"\x1b[B",right:"\x1b[C",left:"\x1b[D"};
  const enc=new TextEncoder();
  const send=s=>{if(!LX.emu)return;const b=enc.encode(s);let t="";for(const x of b)t+=String.fromCharCode(x);LX.emu.serial0_send(t)};
  const showCard=h=>{box.innerHTML=h;card.classList.remove("hide")};
  const hideCard=()=>card.classList.add("hide");
  const progressCard=(msg,pct)=>{if(!$(".bar",box))showCard(`<div class="lg">${ICON.logo()}</div><h2>Nimbus Linux</h2><p data-msg></p><div class="bar"><i data-pct></i></div><span class="lnk" data-log>Show boot messages</span>`);
    $("[data-msg]",box).textContent=msg;$("[data-pct]",box).style.width=Math.max(3,Math.min(100,pct))+"%";
    const l=$("[data-log]",box);if(l)l.onclick=hideCard};
  let pct=22;
  const setup=()=>{state="off";
    showCard(`<div class="lg">${ICON.logo()}</div><h2>Nimbus Linux</h2>
      ${LX.isoName?`<p>Disk: <b>${esc(LX.isoName)}</b></p><div class="acts"><button class="btn primary" data-go>${SVG.power} Start Linux</button><button class="btn" data-pick>Change disk…</button></div>`:
      `<p>Choose a Tiny Core Linux disk to get started.</p><div class="acts"><button class="btn primary" data-pick>Choose disk (.iso)…</button><button class="btn" data-lib>From Nimbus Files</button></div>
       <ol><li>In Safari, download <a href="http://www.tinycorelinux.net/17.x/x86/release/TinyCore-current.iso" target="_blank" rel="noopener">TinyCore-current.iso</a> (32-bit, about 25 MB).</li><li>Tap <b>Choose disk</b> and pick it from Downloads.</li></ol>`}
      <p style="font-size:11.5px;opacity:.55;margin-top:12px">Opens as a terminal. Switch to Classic desktop for the graphical Tiny Core.</p>`);
    const g=$("[data-go]",box);if(g)g.onclick=()=>boot();
    $("[data-pick]",box).onclick=()=>pickFiles(async f=>{if(!f[0])return;await LX.setIso(f[0],f[0].name);LX.kit=null;boot()},".iso,.img");
    const lb=$("[data-lib]",box);if(lb)lb.onclick=async()=>{const isos=(await DB.fs.all()).filter(e=>e.type==="file"&&isISO(e));
      if(!isos.length){UI.toast("No disk images in Files","Import an .iso into Files first.","linux");return}
      const r=lb.getBoundingClientRect();UI.menu(isos.map(e=>({label:e.name,action:async()=>{await LX.setIso(e.blob,e.name);LX.kit=null;boot()}})),r.left,r.bottom+4)}};
  const ensureTerm=async()=>{if(term)return;await LX.loadXterm();
    const big=Math.min(innerWidth,innerHeight)>700;
    term=new Terminal({fontFamily:'"SF Mono",ui-monospace,Menlo,Monaco,"Cascadia Mono",monospace',fontSize:S.termFont||(big?14:13),lineHeight:1.15,
      cursorBlink:true,cursorStyle:"bar",allowTransparency:true,theme:TERM_THEME,scrollback:5000,macOptionIsMeta:true,convertEol:false});
    fit=new FitAddon.FitAddon();term.loadAddon(fit);term.open(termEl);try{fit.fit()}catch(e){}
    term.onData(d=>{if(ctrl&&d.length===1){const c=d.toUpperCase().charCodeAt(0);if(c>=64&&c<=95)d=String.fromCharCode(c-64);ctrl=false;$("[data-a=ctrl]",w.body).classList.remove("on")}send(d)});
    term.onTitleChange(()=>{if(state==="init"){state="ready";$("[data-pct]",box)&&($("[data-pct]",box).style.width="100%");setTimeout(hideCard,250);term.focus()}});
    new ResizeObserver(()=>resized()).observe(termEl)};
  let rzT;const resized=()=>{clearTimeout(rzT);rzT=setTimeout(()=>{if(!fit)return;try{fit.fit()}catch(e){}
    const sz=term.cols+"x"+term.rows;if(state==="ready"&&sz!==lastSize&&/[$#] $/.test(tail)){lastSize=sz;send(`\x15stty cols ${term.cols} rows ${term.rows};printf '\\033[A\\033[2K\\r'\r`)}},350)};
  let buf=[],raf=0;
  const onByte=b=>{buf.push(b);tail=(tail+(b===13?"":String.fromCharCode(b))).slice(-160);if(!raf)raf=requestAnimationFrame(flush)};
  const flush=()=>{raf=0;if(!buf.length)return;const a=new Uint8Array(buf);buf=[];term&&term.write(a);
    const clean=tail.replace(/\x1b\[[0-9;?]*[A-Za-z]/g,"");
    if(state==="boot"){pct=Math.min(88,pct+0.6);progressCard(/extension|tce/i.test(clean)?"Loading apps…":/udev|module|device/i.test(clean)?"Finding devices…":"Starting Linux…",pct);
      if(/login:\s*$/.test(clean)){state="login";clearTimeout(watchdog);progressCard("Signing in…",92);setTimeout(()=>send("tc\r"),150)}}
    else if(state==="login"){if(/[$#] $/.test(clean)){state="init";progressCard("Almost ready…",96);lastSize=term.cols+"x"+term.rows;send(`\x15. /usr/bin/nimbus-init ${term.cols} ${term.rows}\r`);setTimeout(()=>{if(state==="init"){state="ready";hideCard();term.focus()}},5000)}
      else if(/password:\s*$/i.test(clean)){state="ready";hideCard();term.focus()}}};
  const boot=async()=>{
    if(LX.running)return;
    try{await ensureTerm();term.reset();state="starting";pct=4;progressCard("Getting ready…",3);pwr.querySelector("span").textContent="Stop";
      const emu=await LX.startTerminal((m,p)=>{pct=p;progressCard(m,p)});
      if(!emu){pwr.querySelector("span").textContent="Start";state="off";
        showCard(`<div class="lg">${ICON.logo()}</div><h2>This disk needs Classic desktop</h2><p>Terminal mode works with Tiny Core disks. <b>${esc(LX.isoName)}</b> doesn't look like one, so it will start in Classic desktop.</p><div class="acts"><button class="btn primary" data-cl>Open Classic desktop</button><button class="btn" data-pick>Choose another disk…</button></div>`);
        $("[data-cl]",box).onclick=()=>switchMode("desktop",{autostart:true});
        $("[data-pick]",box).onclick=()=>pickFiles(async f=>{if(!f[0])return;await LX.setIso(f[0],f[0].name);LX.kit=null;boot()},".iso,.img");return}
      state="boot";info(`${S.linuxMem} MB RAM · Terminal`);
      emu.add_listener("serial0-output-byte",onByte);
      clearTimeout(watchdog);watchdog=setTimeout(()=>{if(state!=="boot")return;
        showCard(`<div class="lg">${ICON.logo()}</div><h2>Linux is taking a while</h2><p>Tiny Core hasn't reached the sign-in step yet. You can keep waiting, look at the boot messages, or use the Classic desktop instead.</p>
          <div class="acts"><button class="btn" data-w>Keep waiting</button><button class="btn" data-l>Show messages</button><button class="btn primary" data-cl>Classic desktop</button></div>`);
        $("[data-w]",box).onclick=()=>progressCard("Starting Linux…",pct);$("[data-l]",box).onclick=hideCard;
        $("[data-cl]",box).onclick=async()=>{await LX.stop();switchMode("desktop",{autostart:true})}},150000);
    }catch(err){console.error(err);LX.running=false;state="off";pwr.querySelector("span").textContent="Start";
      showCard(`<div class="lg">${ICON.logo()}</div><h2>Couldn't start Linux</h2><p>${esc(err.message||String(err))}</p>${SANDBOXED?`<p>This preview may block the emulator. The installed version of Nimbus avoids that.</p>`:""}<div class="acts"><button class="btn" data-s>Back</button></div>`);
      $("[data-s]",box).onclick=setup}};
  const stop=async()=>{clearTimeout(watchdog);info("Stopping…");await LX.stop();state="off";pwr.querySelector("span").textContent="Start";info("");setup()};
  pwr.onclick=()=>LX.running?stop():(LX.isoName?boot():setup());
  $$("[data-k]",w.body).forEach(b=>{b.addEventListener("pointerdown",e=>e.preventDefault());b.onclick=()=>{send(KEYSEQ[b.dataset.k]);term&&term.focus()}});
  const cb=$("[data-a=ctrl]",w.body);cb.addEventListener("pointerdown",e=>e.preventDefault());cb.onclick=()=>{ctrl=!ctrl;cb.classList.toggle("on",ctrl);term&&term.focus()};
  $("[data-a=paste]",w.body).onclick=async()=>{let t=null;try{t=await navigator.clipboard.readText()}catch(e){}
    if(t==null)t=await UI.prompt("Paste text into Linux","","Text");if(t&&LX.emu)send(t.replace(/\r?\n/g,"\r"));term&&term.focus()};
  $("[data-a=shared]",w.body).onclick=()=>WM.open("files",{folder:"linuxshared"});
  $("[data-a=more]",w.body).onclick=e=>{const r=e.target.getBoundingClientRect();UI.menu([
    {label:"Bigger text",action:()=>{S.termFont=Math.min(22,(term?term.options.fontSize:14)+1);saveSettings();if(term){term.options.fontSize=S.termFont;resized()}}},
    {label:"Smaller text",action:()=>{S.termFont=Math.max(10,(term?term.options.fontSize:14)-1);saveSettings();if(term){term.options.fontSize=S.termFont;resized()}}},
    {label:"Clear screen",disabled:!LX.running,action:()=>send("\x15clear\r")},"-",
    {label:"Back up home folder",disabled:state!=="ready",action:()=>send("\x15filetool.sh -b\r")},
    {label:"Sync shared folder now",disabled:!LX.running,action:async()=>{send("\x15sync\r");setTimeout(async()=>{const n=await LX.syncShared();UI.toast("Shared folder",n?`${n} change(s) copied from Linux`:"No changes","linux")},800)}},
    {label:"Save Linux drive now",disabled:!LX.running,action:async()=>{send("\x15sync\r");setTimeout(async()=>{await DB.set("linux-hdd",new Blob([LX.hddBuf]));UI.toast("Linux drive saved","256 MB","linux")},800)}},"-",
    {label:"Restart Linux",disabled:!LX.running,action:async()=>{await LX.stop();pwr.querySelector("span").textContent="Start";boot()}},
    {label:"Change disk…",disabled:LX.running,action:()=>setup()},
    {label:"Open Classic desktop",action:()=>$("[data-m=desktop]",w.body).click()}],r.left,r.bottom+4)};
  $("[data-m=desktop]",w.body).onclick=async()=>{if(LX.running){const ok=await UI.dialog({title:"Switch to Classic desktop?",text:"Linux will restart with the graphical Tiny Core desktop.",ok:"Switch",cancel:"Cancel"});if(!ok)return;await stop()}switchMode("desktop")};
  termEl.addEventListener("pointerdown",()=>term&&term.focus());
  (async()=>{if(opts&&opts.isoEntry){const e=await DB.fs.get(opts.isoEntry);if(e){await LX.setIso(e.blob,e.name);LX.kit=null;boot();return}}
    if(opts&&opts.autostart&&LX.isoName){boot();return}setup()})();
  return {focus(){term&&term.focus()},blur(){},resize(){resized()},
    async beforeClose(){if(!LX.running)return true;const r=await UI.dialog({title:"Quit Linux?",text:"Linux will stop. Your permanent drive and shared folder are saved.",ok:"Quit",cancel:"Cancel"});if(!r)return false;await LX.stop();return true},
    close(){clearTimeout(watchdog);LX.win=null;try{term&&term.dispose()}catch(e){}}}}

/* wrap the Linux app: Terminal (default) or Classic desktop */
const _lxCreate4=APPS.linux.create;
APPS.linux.create=function(w,opts){
  let inner={};
  const proxy={focus(){inner.focus&&inner.focus()},blur(){inner.blur&&inner.blur()},resize(){inner.resize&&inner.resize()},
    async beforeClose(){return inner.beforeClose?inner.beforeClose():true},close(){inner.close&&inner.close()}};
  const mount=(mode,o)=>{try{inner.close&&inner.close()}catch(e){}
    S.linuxMode=mode;saveSettings();
    if(mode==="terminal"){inner=linuxTerminalUI(w,o||{},mount)||{};return}
    inner=_lxCreate4(w,o||{})||{};
    const bar=$(".lx-bar",w.body);if(bar){const seg=html(`<div class="seg"><button data-m="terminal">Terminal</button><button class="on" data-m="desktop">Classic desktop</button></div>`);
      bar.insertBefore(seg,bar.children[1]||null);
      $("[data-m=terminal]",seg).onclick=async()=>{if(LX.running){const ok=await UI.dialog({title:"Switch to Terminal?",text:"Linux will restart in the Nimbus Terminal.",ok:"Switch",cancel:"Cancel"});if(!ok)return;await LX.stop()}mount("terminal")}}
    if(o&&o.autostart&&LX.isoName){setTimeout(()=>{const p=$("[data-go]",w.body)||$("[data-a=power]",w.body);p&&p.click()},300)}};
  mount(S.linuxMode==="desktop"?"desktop":"terminal",opts);
  return proxy};
APPS.linux.reopen=function(w,opts){if(opts&&opts.isoEntry&&!LX.running){DB.fs.get(opts.isoEntry).then(async e=>{if(e){await LX.setIso(e.blob,e.name);LX.kit=null;const p=$("[data-a=power]",w.body);p&&p.click()}})}};

/* --------------------------------- Boot -------------------------------- */
const _boot4=window.NIMBUS_BOOT;
window.NIMBUS_BOOT=async function(){
  await _boot4();
  if(S.seenVersion!==VERSION){setTimeout(whatsNew,1200)}
  setTimeout(()=>checkUpdate(false),6000);
  setInterval(()=>checkUpdate(false),6*3600*1000);
  document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&Date.now()-(Upd._t||0)>3600*1000){Upd._t=Date.now();checkUpdate(false)}});
};
