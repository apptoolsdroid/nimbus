/* =====================================================================
   Nimbus 4.3: one-button Apple Reminders sync, automatic when possible.
   - Sync with Apple: runs the "Nimbus Get Reminders" shortcut and imports
     the result (one tap when you come back).
   - Automatic sync: if the shortcut saves its list to OneDrive or Google
     Drive (Nimbus/reminders.txt), Nimbus checks that file every 3 minutes
     and whenever you return to Nimbus. A Shortcuts automation ("when
     Reminders is closed") keeps the file fresh, so no taps are needed.
   - Sync mirrors: reminders completed or deleted in Apple are ticked off here.
   ===================================================================== */
const RSYNC_FILE="reminders.txt",RSYNC_DIR="Nimbus";

/* import with mirroring: the shortcut exports every open Apple reminder */
Bridge.importText=function(t,{quiet=false}={}){
  const lines=t.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);let added=0,closed=0,changed=0;const seen=new Set();
  for(const l of lines){const [title,dueS,listName]=l.split(/\s*\|\s*/);if(!title)continue;
    let list=RM.lists.find(x=>listName&&x.name.toLowerCase()===listName.toLowerCase());
    if(!list&&listName){list={id:uid(),name:listName,color:RCOL[RM.lists.length%RCOL.length]};RM.lists.push(list)}
    if(!list)list=RM.lists.find(x=>x.id==="apple")||RM.lists[0];
    const due=dueS?Date.parse(dueS):NaN;const dueV=isNaN(due)?null:due;
    seen.add(list.id+"\u0000"+title.toLowerCase());
    const ex=RM.items.find(x=>x.list===list.id&&x.title.toLowerCase()===title.toLowerCase()&&!x.done);
    if(ex){if(ex.src==="apple"&&(ex.due||null)!==dueV){ex.due=dueV;ex.allDay=dueV==null||!/T\d\d:\d\d/.test(dueS)||/T00:00/.test(dueS);changed++}continue}
    RM.items.push({id:uid(),list:list.id,title,done:false,due:dueV,allDay:isNaN(due)?true:!/T\d\d:\d\d/.test(dueS)||/T00:00/.test(dueS),prio:0,flag:false,notes:"",created:Date.now(),src:"apple"});added++}
  if(lines.length&&lines.every(l=>l.includes("|"))){for(const r of RM.items){if(r.src==="apple"&&!r.done&&!seen.has(r.list+"\u0000"+r.title.toLowerCase())){r.done=true;r.doneAt=Date.now();closed++}}}
  RM.save();
  const parts=[];if(added)parts.push(`${added} new`);if(changed)parts.push(`${changed} updated`);if(closed)parts.push(`${closed} completed in Apple`);
  if(!quiet||parts.length)UI.toast("Synced with Apple Reminders",parts.length?parts.join(" · "):"Everything is up to date","reminders");
  S.rmSyncAt=Date.now();saveSettings();RSync.status();
  return {added,changed,closed}};

const RSync={
  acc(){const id=S.rmSyncAcc;return id?mailAccounts().find(a=>a.id===id&&MT.connected(a)&&hasDrive(a))||null:null},
  candidates(){return mailAccounts().filter(a=>kindOf(a)&&MT.connected(a)&&hasDrive(a))},
  busy:false,
  async fetch(a){
    if(kindOf(a)==="m"){
      let meta;try{meta=await api(a,`https://graph.microsoft.com/v1.0/me/drive/root:/${RSYNC_DIR}/${RSYNC_FILE}`)}catch(e){if(e instanceof NeedAuth)throw e;throw new Error(`OneDrive › ${RSYNC_DIR} › ${RSYNC_FILE} isn't there yet. Run the shortcut once.`)}
      if(meta.lastModifiedDateTime===S.rmSyncStamp)return null;
      const r=await fetch(meta["@microsoft.graph.downloadUrl"]);return {text:await r.text(),stamp:meta.lastModifiedDateTime}}
    const q=encodeURIComponent(`name='${RSYNC_FILE}' and trashed=false`);
    const j=await api(a,`https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=modifiedTime desc&pageSize=1&fields=files(id,modifiedTime)`);
    const f=(j.files||[])[0];if(!f)throw new Error(`Google Drive › ${RSYNC_DIR} › ${RSYNC_FILE} isn't there yet. Run the shortcut once.`);
    if(f.modifiedTime===S.rmSyncStamp)return null;
    const tok=await tokenFor(a);const r=await fetch(`https://www.googleapis.com/drive/v3/files/${f.id}?alt=media`,{headers:{Authorization:"Bearer "+tok}});
    if(!r.ok)throw new Error("HTTP "+r.status);return {text:await r.text(),stamp:f.modifiedTime}},
  async sync(manual){
    const a=RSync.acc();
    if(!a){if(manual){if(S.rmSyncAcc&&RSync.candidates().length===0){UI.toast("Automatic sync is paused","Reconnect OneDrive or Google in Mail. Syncing through Shortcuts for now.","reminders")}Bridge.startImport()}return}
    if(RSync.busy)return;RSync.busy=true;RSync.status("Syncing…");
    try{const r=await RSync.fetch(a);
      if(r){Bridge.importText(r.text,{quiet:!manual});S.rmSyncStamp=r.stamp;saveSettings()}
      else if(manual){UI.toast("Apple Reminders","Already up to date. Close the Reminders app to refresh the list.","reminders")}
      S.rmSyncAt=Date.now();saveSettings()}
    catch(e){if(manual){if(e instanceof NeedAuth){if(await UI.confirm("Sign in again?",`${esc(a.email)}'s session expired.`,"Reconnect")){await DB.set("oauth-reopen-app",{app:"reminders"});connectAccount(a,{silent:true})}}else UI.toast("Couldn't sync",String(e.message||e).slice(0,120),"reminders")}}
    finally{RSync.busy=false;RSync.status()}},
  status(arg){const txt=typeof arg==="string"?arg:null;
    $$("[data-syncst]").forEach(el=>{const a=RSync.acc();el.style.cursor="pointer";el.onclick=()=>RSync.setup();
      el.textContent=txt||(a?`Auto · ${S.rmSyncAt?"synced "+new Date(S.rmSyncAt).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}):"waiting for first sync"}`:(S.rmSyncAt?"Last synced "+new Date(S.rmSyncAt).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})+" · ":"")+"Make it automatic…")})},
  setup(host){
    const cands=RSync.candidates();const cur=RSync.acc();
    const d=UI.dialog({title:"Sync with Apple Reminders",text:`
      <div style="font-size:13px;line-height:1.5;text-align:left">
      <b>Now:</b> tap <b>⟳ Sync with Apple</b>. Shortcuts runs; come back to Nimbus and tap <b>Paste reminders</b>.<br><br>
      <b>Automatic (no taps):</b> let the shortcut save its list to OneDrive or Google Drive. Nimbus then checks it every 3 minutes.
      <ol style="padding-left:18px;margin:6px 0">
        <li>In Shortcuts, edit <b>Nimbus Get Reminders</b>. Replace <i>Copy to Clipboard</i> with <b>Save File</b>: turn off <i>Ask Where to Save</i>, choose <b>OneDrive</b> (or Google Drive) › folder <b>${RSYNC_DIR}</b>, name it <b>${RSYNC_FILE}</b>, and turn on <i>Overwrite If File Exists</i>.</li>
        <li>Shortcuts › <b>Automation</b> › <b>+</b> › <b>App</b> › Reminders › <b>Is Closed</b> › <b>Run Immediately</b> › choose <b>Nimbus Get Reminders</b>. Now each time you leave Apple Reminders, the list refreshes.</li>
        <li>Below, pick the account that holds the file.</li></ol>
      ${cands.length?"":`<span style="color:#ff9f0a">Automatic sync needs OneDrive or Google Drive connected in Mail first (the one-time connection setup).</span>`}
      ${cur?`<br>Currently syncing from <b>${esc(cur.email)}</b>.`:""}</div>`,ok:cands.length?"Choose Account":"OK",cancel:cur?"Turn Off Auto":"Close"});
    Promise.resolve(d).then(ok=>{
      if(ok&&cands.length){const r=$(".dock")||document.body;UI.menu(cands.map(a=>({label:`${kindOf(a)==="m"?"OneDrive":"Google Drive"} · ${a.email}`,action:()=>{S.rmSyncAcc=a.id;S.rmSyncStamp=null;saveSettings();RSync.sync(true);RSync.start()}})),innerWidth/2-120,innerHeight/3)}
      else if(!ok&&cur){S.rmSyncAcc=null;saveSettings();RSync.status();UI.toast("Automatic sync off","Use ⟳ Sync with Apple any time.","reminders")}})},
  timer:null,
  start(){clearInterval(RSync.timer);if(!S.rmSyncAcc)return;RSync.timer=setInterval(()=>{if(document.visibilityState==="visible")RSync.sync(false)},3*60000)}
};
window.RSync=RSync;

/* coming back to Nimbus: check the cloud file */
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&RSync.acc()&&Date.now()-(S.rmSyncAt||0)>45000)RSync.sync(false)});

/* help sheet → show both ways */
const _bridgeHelp43=Bridge.help;
Bridge.help=function(host){_bridgeHelp43.call(Bridge,host);setTimeout(()=>{const sheet=$$(".sheet,.dialog,.modal").pop();if(!sheet)return;
  const b=html(`<div style="margin-top:10px"><button class="btn primary">Set up automatic sync…</button></div>`);$("button",b).onclick=()=>{const x=sheet.closest(".sheet-wrap,.modal-wrap,.dim")||sheet;x.remove();RSync.setup(host)};
  (sheet.querySelector(".body,.sheet-body")||sheet).appendChild(b)},60)};

const _boot43=window.NIMBUS_BOOT;
window.NIMBUS_BOOT=async function(){await _boot43();RSync.start();if(RSync.acc())setTimeout(()=>RSync.sync(false),4000)};
