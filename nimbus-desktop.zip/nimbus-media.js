/* =====================================================================
   Nimbus 4.2: Photos and YouTube
   Photos: one timeline of every photo and video in Nimbus (imports from the
   iPad Photos library, linked iPad folders, Files) plus OneDrive Camera Roll
   and Google Drive photos. Indexed by date taken (EXIF) and place.
   YouTube: search, subscriptions, liked videos, playlists, history and
   Watch Later, playing inside Nimbus. youtube.com pages in the Browser open here.
   ===================================================================== */
document.head.appendChild(Object.assign(document.createElement("style"),{textContent:`
.ph{flex:1;display:flex;min-height:0;position:relative}
.ph .sidebar{width:200px}
.ph .main{display:flex;flex-direction:column;min-width:0;flex:1}
.ph-top{display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--hair)}
.ph-top h2{margin:0;font-size:17px;font-weight:650;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ph-top .field{width:190px;padding:6px 10px}
.ph-top input[type=range]{width:80px}
.ph-scroll{flex:1;overflow:auto;padding:4px 14px 20px}
.ph-month{position:sticky;top:0;z-index:2;padding:12px 2px 8px;font-weight:700;font-size:15px;background:linear-gradient(var(--win-bg) 75%,transparent)}
.ph-month small{font-weight:500;opacity:.55;margin-left:6px;font-size:12px}
.ph-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(var(--ph,128px),1fr));gap:3px}
.ph-cell{position:relative;aspect-ratio:1;background:var(--hover);border-radius:6px;overflow:hidden;cursor:pointer}
.ph-cell img{width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .25s}
.ph-cell img.ok{opacity:1}
.ph-cell .b{position:absolute;bottom:4px;right:6px;color:#fff;font-size:11px;font-weight:600;text-shadow:0 1px 3px rgba(0,0,0,.6)}
.ph-cell .fav{position:absolute;bottom:4px;left:6px;color:#fff;font-size:12px;text-shadow:0 1px 3px rgba(0,0,0,.6)}
.ph-cell .src{position:absolute;top:5px;right:5px;width:16px;height:16px;border-radius:5px;font-size:9px;font-weight:800;color:#fff;display:flex;align-items:center;justify-content:center;opacity:.9}
.ph-empty{max-width:460px;margin:60px auto;text-align:center;line-height:1.5;font-size:13.5px;color:var(--text2)}
.ph-empty .ic{width:70px;height:70px;margin:0 auto 10px}
.ph-empty h3{color:var(--text);font-size:18px;margin:0 0 6px}
.ph-empty .acts{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:14px}
.ph-tip{font-size:12px;text-align:left;background:var(--hover);border-radius:12px;padding:10px 14px;margin-top:16px}
.ph-view{position:absolute;inset:0;background:#0b0b0e;z-index:10;display:flex;flex-direction:column;color:#fff}
.ph-view .bar{display:flex;gap:6px;align-items:center;padding:8px 10px;background:rgba(255,255,255,.04)}
.ph-view .bar .btn{background:rgba(255,255,255,.1);color:#fff;border-color:transparent}
.ph-view .bar .btn.on{color:#ff6b8a}
.ph-view .bar .t{flex:1;font-size:13px;line-height:1.25;min-width:0}
.ph-view .bar .t b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ph-view .bar .t span{opacity:.6;font-size:11.5px}
.ph-view .stage{flex:1;display:flex;align-items:center;justify-content:center;min-height:0;position:relative;touch-action:pan-y}
.ph-view .stage img,.ph-view .stage video{max-width:100%;max-height:100%;object-fit:contain}
.ph-view .nav{position:absolute;top:50%;transform:translateY(-50%);width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.12);border:0;color:#fff;font-size:20px}
.ph-view .nav.l{left:10px}.ph-view .nav.r{right:10px}
.ph-view .info{position:absolute;right:12px;top:58px;width:260px;padding:14px;border-radius:14px;background:rgba(40,40,48,.92);font-size:12.5px;line-height:1.6;z-index:3}
.ph-view .info a{color:#8fc3ff}
.ph-view .spin{opacity:.6;font-size:13px}
.yt{flex:1;display:flex;min-height:0}
.yt .sidebar{width:190px}
.yt .main{flex:1;display:flex;flex-direction:column;min-width:0}
.yt-top{display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--hair)}
.yt-top form{flex:1;display:flex;gap:6px;max-width:560px;margin:0 auto}
.yt-top .field{flex:1;padding:7px 12px;border-radius:99px}
.yt-scroll{flex:1;overflow:auto;padding:14px 16px 24px}
.yt-scroll h3{margin:4px 2px 12px;font-size:16px}
.yt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:16px 14px}
.yt-card{cursor:pointer;min-width:0}
.yt-card .th{position:relative;aspect-ratio:16/9;border-radius:12px;overflow:hidden;background:var(--hover)}
.yt-card .th img{width:100%;height:100%;object-fit:cover;display:block}
.yt-card .th i{position:absolute;right:6px;bottom:6px;background:rgba(0,0,0,.75);color:#fff;font-style:normal;font-size:11px;font-weight:600;padding:1px 5px;border-radius:5px}
.yt-card b{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:13.5px;line-height:1.3;margin-top:8px}
.yt-card span{display:block;font-size:12px;color:var(--text2);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.yt-chan{display:flex;align-items:center;gap:10px;padding:8px;border-radius:12px;cursor:pointer}
.yt-chan:hover{background:var(--hover)}
.yt-chan img{width:40px;height:40px;border-radius:50%}
.yt-player{max-width:1000px;margin:0 auto}
.yt-player .frame{position:relative;aspect-ratio:16/9;border-radius:14px;overflow:hidden;background:#000}
.yt-player iframe{position:absolute;inset:0;width:100%;height:100%;border:0}
.yt-player h2{font-size:18px;margin:12px 0 4px;line-height:1.3}
.yt-player .meta{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:13px;color:var(--text2)}
.yt-player .meta .btn{font-size:12.5px}
.yt-player .desc{white-space:pre-wrap;font-size:13px;line-height:1.5;background:var(--hover);border-radius:12px;padding:10px 14px;margin-top:12px;max-height:120px;overflow:hidden;cursor:pointer}
.yt-player .desc.open{max-height:none}
.yt-note{background:var(--hover);border-radius:14px;padding:14px 16px;font-size:13px;line-height:1.5;margin-bottom:16px}
.yt-note .btn{margin-top:8px;margin-right:6px}
`}));

Object.assign(ICON,{
  photos:()=>squircle("pho","#ffffff","#eef0f4",[["#ff9f0a",0],["#ffd60a",45],["#30d158",90],["#64d2ff",135],["#0a84ff",180],["#bf5af2",225],["#ff375f",270],["#ff6b6b",315]].map(([c,r])=>`<ellipse cx="32" cy="20" rx="7" ry="12" fill="${c}" opacity=".85" transform="rotate(${r} 32 32)" style="mix-blend-mode:multiply"/>`).join("")),
  youtube:()=>squircle("ytb","#ff5a52","#d4141c",`<rect x="13" y="19" width="38" height="26" rx="8" fill="#fff"/><path d="M28.5 25.5v13l11-6.5z" fill="#e0242b"/>`)
});

/* ------------------------------ helpers ------------------------------ */
const isMedia=e=>e&&e.type==="file"&&/^(image|video)\//.test(e.mime||guessMime(e.name));
const isVid=e=>/^video\//.test(e.mime||guessMime(e.name||""));
const monthKey=t=>{const d=new Date(t);return d.getFullYear()*100+d.getMonth()};
const monthName=t=>new Date(t).toLocaleDateString([], {month:"long",year:"numeric"});
const dayName=t=>new Date(t).toLocaleDateString([], {weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit"});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

/* EXIF: date taken + GPS from the start of a JPEG */
async function readExif(blob){
  try{const b=new DataView(await blob.slice(0,196608).arrayBuffer());if(b.getUint16(0)!==0xFFD8)return null;
    let o=2;while(o+4<b.byteLength){const m=b.getUint16(o),len=b.getUint16(o+2);
      if(m===0xFFE1&&b.getUint32(o+4)===0x45786966){return parseTiff(b,o+10)}
      if((m&0xFF00)!==0xFF00)break;o+=2+len}
  }catch(e){}return null}
function parseTiff(b,t){const le=b.getUint16(t)===0x4949;const u16=o=>b.getUint16(t+o,le),u32=o=>b.getUint32(t+o,le);
  const ifd=o=>{const n=u16(o),out={};for(let i=0;i<n;i++){const e=o+2+i*12;out[u16(e)]={type:u16(e+2),count:u32(e+4),val:e+8}}return out};
  const str=(en)=>{const off=en.count>4?u32(en.val):en.val;let s="";for(let i=0;i<en.count-1;i++)s+=String.fromCharCode(b.getUint8(t+off+i));return s};
  const rat=(off,i)=>u32(off+i*8)/(u32(off+i*8+4)||1);
  const r={};const i0=ifd(u32(4));
  const dt=en=>{const m=str(en).match(/(\d{4}):(\d\d):(\d\d) (\d\d):(\d\d):(\d\d)/);return m?new Date(+m[1],m[2]-1,+m[3],+m[4],+m[5],+m[6]).getTime():null};
  if(i0[0x8769]){const ex=ifd(u32(i0[0x8769].val));if(ex[0x9003])r.t=dt(ex[0x9003]);else if(ex[0x9004])r.t=dt(ex[0x9004])}
  if(!r.t&&i0[0x0132])r.t=dt(i0[0x0132]);
  if(i0[0x8825]){const g=ifd(u32(i0[0x8825].val));
    if(g[2]&&g[4]){const la=u32(g[2].val),lo=u32(g[4].val);let lat=rat(la,0)+rat(la,1)/60+rat(la,2)/3600,lng=rat(lo,0)+rat(lo,1)/60+rat(lo,2)/3600;
      if(g[1]&&String.fromCharCode(b.getUint8(g[1].val))==="S")lat=-lat;if(g[3]&&String.fromCharCode(b.getUint8(g[3].val))==="W")lng=-lng;
      if(isFinite(lat)&&isFinite(lng)&&(lat||lng))r.lat=+lat.toFixed(5),r.lng=+lng.toFixed(5)}}
  if(i0[0x0110])r.cam=str(i0[0x0110]);
  return r}

/* small thumbnails for Nimbus files, cached */
const Thumbs={mem:new Map(),queue:Promise.resolve(),
  get(e){if(Thumbs.mem.has(e.id))return Promise.resolve(Thumbs.mem.get(e.id));
    const p=Thumbs.queue=Thumbs.queue.then(()=>Thumbs.make(e)).catch(()=>null);return p},
  async make(e){const key="pthumb:"+e.id+":"+e.size;let b=await DB.get(key);
    if(!b){b=isVid(e)?await Thumbs.video(e.blob):await Thumbs.image(e.blob);if(b)DB.set(key,b)}
    const u=b?URL.createObjectURL(b):(isVid(e)?null:URL.createObjectURL(e.blob));Thumbs.mem.set(e.id,u);return u},
  async image(blob){try{const bm=await createImageBitmap(blob);const s=320/Math.min(bm.width,bm.height);const w=Math.max(1,Math.round(bm.width*Math.min(1,s))),h=Math.max(1,Math.round(bm.height*Math.min(1,s)));
      const c=document.createElement("canvas");c.width=w;c.height=h;c.getContext("2d").drawImage(bm,0,0,w,h);bm.close&&bm.close();
      return await new Promise(r=>c.toBlob(r,"image/jpeg",.78))}catch(err){return null}},
  async video(blob){return new Promise(res=>{const v=document.createElement("video");const u=URL.createObjectURL(blob);let done=false;
    const fin=b=>{if(done)return;done=true;URL.revokeObjectURL(u);res(b)};setTimeout(()=>fin(null),4000);
    v.muted=true;v.playsInline=true;v.preload="metadata";v.src=u;
    v.onloadeddata=()=>{try{v.currentTime=Math.min(1,(v.duration||2)/3)}catch(e){fin(null)}};
    v.onseeked=()=>{try{const s=320/Math.min(v.videoWidth,v.videoHeight);const c=document.createElement("canvas");c.width=Math.round(v.videoWidth*s);c.height=Math.round(v.videoHeight*s);
      c.getContext("2d").drawImage(v,0,0,c.width,c.height);c.toBlob(b=>fin(b),"image/jpeg",.75)}catch(e){fin(null)}};v.onerror=()=>fin(null)})}};

/* ------------------------------ Photo library ------------------------------ */
const PL={items:[],meta:null,cloud:null,loading:false,
  favs(){return S.photoFavs||(S.photoFavs=[])},
  albums(){return S.photoAlbums||(S.photoAlbums=[])},
  cloudAccounts(){return mailAccounts().filter(a=>kindOf(a)&&MT.connected(a)&&hasDrive(a))},
  async loadMeta(){if(!PL.meta)PL.meta=await DB.get("photo-meta")||{};if(!PL.cloud)PL.cloud=await DB.get("photo-cloud")||{};},
  async local(){await PL.loadMeta();const all=await DB.fs.all();const byId=new Map(all.map(e=>[e.id,e]));
    const skip=id=>{let e=byId.get(id),g=0;while(e&&g++<40){if(e.id==="cloudcache"||e.parent==="cloudcache")return true;e=byId.get(e.parent)}return false};
    const out=[];let dirty=false;
    for(const e of all){if(!isMedia(e)||skip(e.id))continue;const mk=e.id+":"+e.size;let m=PL.meta[e.id];
      if(!m||m.k!==mk){m={k:mk};if(/jpe?g/i.test(e.mime||guessMime(e.name)))Object.assign(m,await readExif(e.blob)||{});PL.meta[e.id]=m;dirty=true}
      out.push({key:"l:"+e.id,src:"local",id:e.id,name:e.name,t:m.t||e.mtime,added:e.mtime,lat:m.lat,lng:m.lng,cam:m.cam,video:isVid(e),size:e.size,entry:e})}
    if(dirty)DB.set("photo-meta",PL.meta);return out},
  async syncCloud(a,force){await PL.loadMeta();const c=PL.cloud[a.id];
    if(!force&&c&&Date.now()-c.at<30*60000)return c.items;
    const items=[];
    if(kindOf(a)==="m"){
      const walk=async(url,depth)=>{let next=url;while(next&&items.length<4000){const j=await api(a,next);
          for(const it of j.value||[]){if(it.folder){if(depth<4)await walk(`https://graph.microsoft.com/v1.0/me/drive/items/${it.id}/children?$expand=thumbnails&$top=200`,depth+1);continue}
            const mime=(it.file&&it.file.mimeType)||guessMime(it.name);if(!/^(image|video)\//.test(mime))continue;
            const th=it.thumbnails&&it.thumbnails[0];
            items.push({key:"m:"+a.id+":"+it.id,src:"m",acc:a.id,id:it.id,name:it.name,t:Date.parse((it.photo&&it.photo.takenDateTime)||it.createdDateTime)||Date.now(),added:Date.parse(it.createdDateTime),
              lat:it.location&&it.location.latitude,lng:it.location&&it.location.longitude,cam:it.photo&&[it.photo.cameraMake,it.photo.cameraModel].filter(Boolean).join(" "),
              video:/^video\//.test(mime),size:it.size,thumb:th&&(th.large||th.medium||th.small||{}).url,full:it["@microsoft.graph.downloadUrl"]})}
          next=j["@odata.nextLink"]}};
      try{await walk("https://graph.microsoft.com/v1.0/me/drive/special/cameraroll/children?$expand=thumbnails&$top=200",0)}
      catch(e){if(e instanceof NeedAuth)throw e;await walk("https://graph.microsoft.com/v1.0/me/drive/special/photos/children?$expand=thumbnails&$top=200",0)}}
    else{let tok="";const q=encodeURIComponent("(mimeType contains 'image/' or mimeType contains 'video/') and trashed=false");
      do{const j=await api(a,`https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=createdTime desc&pageSize=500&fields=nextPageToken,files(id,name,mimeType,size,thumbnailLink,createdTime,imageMediaMetadata(time,location,cameraModel),videoMediaMetadata(durationMillis))${tok?"&pageToken="+tok:""}`);
        for(const f of j.files||[]){const im=f.imageMediaMetadata||{};const m=(im.time||"").match(/(\d{4}):(\d\d):(\d\d) (\d\d):(\d\d):(\d\d)/);
          items.push({key:"g:"+a.id+":"+f.id,src:"g",acc:a.id,id:f.id,name:f.name,t:m?new Date(+m[1],m[2]-1,+m[3],+m[4],+m[5],+m[6]).getTime():Date.parse(f.createdTime),added:Date.parse(f.createdTime),
            lat:im.location&&im.location.latitude,lng:im.location&&im.location.longitude,cam:im.cameraModel,video:/^video\//.test(f.mimeType),size:+f.size||0,
            thumb:f.thumbnailLink&&f.thumbnailLink.replace(/=s\d+$/,"=s400")})}
        tok=j.nextPageToken}while(tok&&items.length<4000)}
    PL.cloud[a.id]={at:Date.now(),items};DB.set("photo-cloud",PL.cloud);return items},
  async load(force){const local=await PL.local();const cloud=[];await PL.loadMeta();
    for(const a of PL.cloudAccounts()){const c=PL.cloud[a.id];if(c)cloud.push(...c.items)}
    PL.items=[...local,...cloud].sort((x,y)=>y.t-x.t);return PL.items},
  async refreshCloud(force,onDone){const errs=[];
    for(const a of PL.cloudAccounts()){try{await PL.syncCloud(a,force)}catch(e){errs.push([a,e])}}
    await PL.load();onDone&&onDone(errs)},
  async blob(it){if(it.src==="local")return it.entry.blob;
    const a=mailAccounts().find(x=>x.id===it.acc);if(!a)throw new Error("Account removed");
    if(it.src==="m"){let url=it.full;if(!url){const j=await api(a,`https://graph.microsoft.com/v1.0/me/drive/items/${it.id}`);url=j["@microsoft.graph.downloadUrl"]}
      const r=await fetch(url);if(!r.ok){const j=await api(a,`https://graph.microsoft.com/v1.0/me/drive/items/${it.id}`);const r2=await fetch(j["@microsoft.graph.downloadUrl"]);return r2.blob()}return r.blob()}
    const tok=await tokenFor(a);const r=await fetch(`https://www.googleapis.com/drive/v3/files/${it.id}?alt=media`,{headers:{Authorization:"Bearer "+tok}});
    if(!r.ok)throw new Error("HTTP "+r.status);return r.blob()}
};
window.PL=PL;

const SRC_BADGE={m:["#0a6ad8","O"],g:["#1fa463","G"]};

APPS.photos={name:"Photos",icon:"photos",w:980,h:660,single:true,
  create(w,opts){
    const st={view:"library",album:null,q:"",size:S.photoSize||128,list:[]};
    w.body.innerHTML=`<div class="ph"><div class="sidebar" data-side></div><div class="main">
      <div class="ph-top"><h2 data-title>Library</h2><input type="range" min="80" max="260" step="4" value="${st.size}" data-zoom title="Size">
        <input class="field" placeholder="Search: 2024, March, video…" data-q><button class="btn" data-slide title="Slideshow">▶︎ Slideshow</button><button class="btn primary" data-imp>${SVG.imp||""}Import</button></div>
      <div class="ph-scroll" data-scroll></div></div></div>`;
    const side=$("[data-side]",w.body),scroll=$("[data-scroll]",w.body),root=$(".ph",w.body);
    const io=new IntersectionObserver(ents=>ents.forEach(en=>{if(!en.isIntersecting)return;const el=en.target;io.unobserve(el);loadThumb(el)}),{root:scroll,rootMargin:"400px"});
    const byKey=new Map();
    const loadThumb=async el=>{const it=byKey.get(el.dataset.k);if(!it)return;const img=$("img",el);
      let u=it.src==="local"?await Thumbs.get(it.entry):it.thumb;
      if(!u){el.insertAdjacentHTML("beforeend",`<span class="b" style="top:40%;left:0;right:0;text-align:center;bottom:auto">${it.video?"▶︎":esc((it.name.split(".").pop()||"").toUpperCase())}</span>`);return}
      img.onload=()=>img.classList.add("ok");img.onerror=()=>{img.remove()};img.src=u};
    const drawSide=()=>{const accs=PL.cloudAccounts();const n=k=>PL.items.filter(k).length;
      side.innerHTML=`<h5>Photos</h5>
        <div class="si" data-v="library">${SVG.pics||""}Library <span class="sub">${PL.items.length||""}</span></div>
        <div class="si" data-v="favs">♥︎&nbsp; Favourites <span class="sub">${PL.favs().length||""}</span></div>
        <div class="si" data-v="recent">${SVG.down||""}Recently Added</div>
        <div class="si" data-v="videos">▶︎&nbsp; Videos <span class="sub">${n(i=>i.video)||""}</span></div>
        <div class="si" data-v="places">⌖&nbsp; Places <span class="sub">${n(i=>i.lat!=null)||""}</span></div>
        <h5>Sources</h5>
        <div class="si" data-v="src:local">${SVG.ipad||""}On this iPad <span class="sub">${n(i=>i.src==="local")||""}</span></div>
        ${accs.map(a=>`<div class="si" data-v="src:${a.id}"><span class="src" style="position:static;display:inline-flex;width:16px;height:16px;border-radius:5px;font-size:9px;font-weight:800;color:#fff;align-items:center;justify-content:center;background:${SRC_BADGE[kindOf(a)][0]}">${SRC_BADGE[kindOf(a)][1]}</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${kindOf(a)==="m"?"OneDrive":"Google Drive"} · ${esc(a.email.split("@")[0])}</span></div>`).join("")}
        <div class="si" data-addsrc>${SVG.plus.replace("<svg",'<svg style="color:var(--accent)"')}Add OneDrive / Google…</div>
        <h5>Albums</h5>${PL.albums().map(al=>`<div class="si" data-v="album:${al.id}">${SVG.folder||""}<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(al.name)}</span> <span class="sub">${al.keys.length||""}</span></div>`).join("")}
        <div class="si" data-newalbum>${SVG.plus.replace("<svg",'<svg style="color:var(--accent)"')}New Album…</div>`;
      $$(".si[data-v]",side).forEach(s=>{s.classList.toggle("act",s.dataset.v===st.view);s.onclick=()=>{st.view=s.dataset.v;drawSide();draw()};
        if(s.dataset.v.startsWith("album:"))longPress(s,e=>{const al=PL.albums().find(x=>"album:"+x.id===s.dataset.v);UI.menu([
          {label:"Rename Album…",action:async()=>{const n=await UI.prompt("Rename Album",al.name);if(n){al.name=n;saveSettings();drawSide();draw()}}},
          {label:"Delete Album",danger:true,action:async()=>{if(await UI.confirm(`Delete “${esc(al.name)}”?`,"The photos stay in your library.","Delete",true)){S.photoAlbums=PL.albums().filter(x=>x!==al);saveSettings();st.view="library";drawSide();draw()}}}],e.clientX,e.clientY)})});
      $("[data-newalbum]",side).onclick=async()=>{const n=await UI.prompt("New Album","Untitled Album");if(n){const al={id:uid(),name:n,keys:[]};PL.albums().push(al);saveSettings();st.view="album:"+al.id;drawSide();draw()}};
      $("[data-addsrc]",side).onclick=()=>addSource()};
    const addSource=async()=>{const accs=mailAccounts().filter(a=>kindOf(a));
      if(!accs.length){if(await UI.confirm("Connect OneDrive or Google","Add your Outlook/Hotmail or Gmail account in Mail first, then come back. Photos uses the same sign-in.","Open Mail"))WM.open("mail");return}
      UI.menu(accs.map(a=>({label:`${kindOf(a)==="m"?"OneDrive":"Google Drive"} · ${a.email}${hasDrive(a)?" ✓":""}`,action:async()=>{if(hasDrive(a)){await PL.syncCloud(a,true);await PL.load();drawSide();draw();return}
        await DB.set("oauth-reopen-app",{app:"photos"});connectAccount(a)}})),...[$("[data-addsrc]",side).getBoundingClientRect()].map(r=>[r.left,r.bottom+4]).flat())};
    const filtered=()=>{let L=PL.items;const v=st.view;
      if(v==="favs"){const f=new Set(PL.favs());L=L.filter(i=>f.has(i.key))}
      else if(v==="recent"){const cut=Date.now()-30*864e5;L=L.filter(i=>(i.added||i.t)>cut).sort((a,b)=>(b.added||b.t)-(a.added||a.t))}
      else if(v==="videos")L=L.filter(i=>i.video);
      else if(v==="places")L=L.filter(i=>i.lat!=null);
      else if(v==="src:local")L=L.filter(i=>i.src==="local");
      else if(v.startsWith("src:"))L=L.filter(i=>i.acc===v.slice(4));
      else if(v.startsWith("album:")){const al=PL.albums().find(x=>"album:"+x.id===v);const ks=new Set(al?al.keys:[]);L=L.filter(i=>ks.has(i.key))}
      const q=st.q.trim().toLowerCase();
      if(q){const words=q.split(/\s+/);L=L.filter(i=>{const d=new Date(i.t);const hay=`${i.name} ${d.getFullYear()} ${d.toLocaleDateString([], {month:"long"})} ${d.toLocaleDateString([], {month:"short"})} ${d.toLocaleDateString([], {weekday:"long"})} ${i.video?"video videos":"photo photos"} ${i.cam||""} ${i.lat!=null?"place location gps":""}`.toLowerCase();return words.every(w=>hay.includes(w))})}
      return L};
    const titleOf=()=>{const v=st.view;if(v==="library")return "Library";if(v==="favs")return "Favourites";if(v==="recent")return "Recently Added";if(v==="videos")return "Videos";if(v==="places")return "Places";if(v==="src:local")return "On this iPad";
      if(v.startsWith("src:")){const a=mailAccounts().find(x=>x.id===v.slice(4));return a?(kindOf(a)==="m"?"OneDrive":"Google Drive")+" · "+a.email:"Cloud"}
      if(v.startsWith("album:")){const al=PL.albums().find(x=>"album:"+x.id===v);return al?al.name:"Album"}return ""};
    const draw=()=>{const L=st.list=filtered();$("[data-title]",w.body).textContent=titleOf();byKey.clear();L.forEach(i=>byKey.set(i.key,i));
      io.disconnect();
      if(!L.length){scroll.innerHTML=emptyState();wireEmpty();return}
      const favs=new Set(PL.favs());const groups=[];let cur=null;
      const placeKey=i=>`${i.lat.toFixed(1)},${i.lng.toFixed(1)}`;
      for(const i of L){const g=st.view==="places"?placeKey(i):monthKey(i.t);if(!cur||cur.g!==g){cur={g,label:st.view==="places"?`Near ${i.lat.toFixed(2)}, ${i.lng.toFixed(2)}`:monthName(i.t),items:[],first:i};groups.push(cur)}cur.items.push(i)}
      if(st.view==="places")groups.sort((a,b)=>b.items.length-a.items.length);
      scroll.style.setProperty("--ph",st.size+"px");
      scroll.innerHTML=groups.map(g=>`<div class="ph-month">${esc(g.label)}<small>${g.items.length} item${g.items.length>1?"s":""}</small>${st.view==="places"?` <a class="btn" style="font-size:11px;padding:2px 8px;margin-left:6px" href="https://maps.apple.com/?ll=${g.first.lat},${g.first.lng}&q=Photos" target="_blank" rel="noopener">Map ↗</a>`:""}</div>
        <div class="ph-grid">${g.items.map(i=>`<div class="ph-cell" data-k="${esc(i.key)}"><img alt="">${i.video?`<span class="b">▶︎</span>`:""}${favs.has(i.key)?`<span class="fav">♥︎</span>`:""}${i.src!=="local"?`<span class="src" style="background:${SRC_BADGE[i.src][0]}">${SRC_BADGE[i.src][1]}</span>`:""}</div>`).join("")}</div>`).join("");
      $$(".ph-cell",scroll).forEach(el=>{io.observe(el);el.onclick=()=>openViewer(L.findIndex(i=>i.key===el.dataset.k));
        longPress(el,e=>cellMenu(byKey.get(el.dataset.k),e.clientX,e.clientY))})};
    const emptyState=()=>{const v=st.view;
      if(st.q)return `<div class="ph-empty"><h3>No results</h3>Nothing matches “${esc(st.q)}”. Try a year (2024), a month (March) or “video”.</div>`;
      if(v==="favs")return `<div class="ph-empty"><h3>No favourites yet</h3>Open a photo and tap ♥︎ to add it here.</div>`;
      if(v.startsWith("album:"))return `<div class="ph-empty"><h3>This album is empty</h3>Long-press any photo (or tap ⋯ in the viewer) and choose <b>Add to Album</b>.</div>`;
      if(v==="places")return `<div class="ph-empty"><h3>No places yet</h3>Photos with location data appear here, grouped by where they were taken.</div>`;
      return `<div class="ph-empty"><div class="ic">${ICON.photos()}</div><h3>Bring in your photos</h3>
        Nimbus can't open the iPad's Photos library on its own, but you can bring photos in two ways:
        <div class="acts"><button class="btn primary" data-e="imp">Import from Photos…</button><button class="btn" data-e="src">Connect OneDrive / Google</button><button class="btn" data-e="folder">Link an iPad folder</button></div>
        <div class="ph-tip"><b>Keep everything in sync automatically:</b> in the OneDrive app, turn on <b>Settings › Camera Upload</b>. Your whole camera roll uploads to OneDrive, and Nimbus Photos shows it here as a timeline, with dates and places. (Turn off <i>Optimize iPad Storage</i> in Settings › Photos, or iCloud-only photos are skipped.)</div></div>`};
    const wireEmpty=()=>{$$("[data-e]",scroll).forEach(b=>b.onclick=()=>({imp:doImport,src:addSource,folder:()=>window.linkIpadFolder&&linkIpadFolder()})[b.dataset.e]())};
    const doImport=()=>{const inp=document.createElement("input");inp.type="file";inp.multiple=true;inp.accept="image/*,video/*";inp.style.display="none";document.body.appendChild(inp);
      inp.onchange=async()=>{const files=[...inp.files];inp.remove();if(!files.length)return;
        const kids=await DB.fs.children("pictures");let dest=kids.find(k=>k.type==="folder"&&k.name==="Photos Import");const destId=dest?dest.id:await FS.mkdir("pictures","Photos Import");
        UI.toast("Importing",`${files.length} item${files.length>1?"s":""}`,"photos");
        for(const f of files){const id=uid();await DB.fs.put({id,parent:destId,name:await FS.uniqueName(destId,f.name||("IMG_"+Date.now()+".jpg")),type:"file",mime:f.type||guessMime(f.name),size:f.size,mtime:Date.now(),blob:f})}
        FS.changed();UI.toast("Imported",`${files.length} item${files.length>1?"s":""} added to Photos`,"photos")};
      inp.click()};
    const cellMenu=(it,x,y)=>{if(!it)return;const fav=PL.favs().includes(it.key);UI.menu([
      {label:fav?"Remove from Favourites":"Add to Favourites",action:()=>toggleFav(it)},
      {label:"Add to Album…",action:()=>addToAlbum(it,x,y)},
      ...(st.view.startsWith("album:")?[{label:"Remove from Album",action:()=>{const al=PL.albums().find(a=>"album:"+a.id===st.view);al.keys=al.keys.filter(k=>k!==it.key);saveSettings();drawSide();draw()}}]:[]),
      {label:"Share…",action:()=>shareItem(it)},
      ...(it.src==="local"?[{label:"Show in Files",action:()=>WM.open("files",{folder:it.entry.parent})},"-",{label:"Delete",danger:true,action:()=>delItem(it)}]:[])],x,y)};
    const toggleFav=it=>{const f=PL.favs();const i=f.indexOf(it.key);if(i>=0)f.splice(i,1);else f.push(it.key);saveSettings();drawSide();if(!viewer)draw();return i<0};
    const addToAlbum=(it,x,y)=>{const als=PL.albums();UI.menu([...als.map(al=>({label:al.name+(al.keys.includes(it.key)?" ✓":""),action:()=>{if(!al.keys.includes(it.key))al.keys.push(it.key);saveSettings();drawSide();UI.toast("Added to album",al.name,"photos")}})),als.length?"-":null,
      {label:"New Album…",action:async()=>{const n=await UI.prompt("New Album","Untitled Album");if(n){PL.albums().push({id:uid(),name:n,keys:[it.key]});saveSettings();drawSide();UI.toast("Added to album",n,"photos")}}}].filter(Boolean),x||200,y||200)};
    const shareItem=async it=>{try{UI.toast("Preparing",it.name,"photos");const b=await PL.blob(it);await shareFile({name:it.name,mime:b.type||guessMime(it.name),blob:b})}catch(e){UI.toast("Couldn't share",String(e.message||e).slice(0,90),"photos")}};
    const delItem=async it=>{if(!(await UI.confirm(`Delete “${esc(it.name)}”?`,"It's removed from Nimbus. Your iPad Photos library isn't touched.","Delete",true)))return;await FS.remove(it.id);return true};
    /* -------- viewer -------- */
    let viewer=null;
    const openViewer=idx=>{if(idx<0)return;const L=st.list;let i=idx,url=null,slide=null,info=false,tok=0;
      viewer=html(`<div class="ph-view"><div class="bar"><button class="btn" data-x>‹ Back</button><div class="t" data-t></div>
        <button class="btn" data-fav>♥︎</button><button class="btn" data-info>ⓘ</button><button class="btn" data-sh>${SVG.share}</button><button class="btn" data-more>⋯</button></div>
        <div class="stage" data-stage></div></div>`);
      root.appendChild(viewer);const stage=$("[data-stage]",viewer);
      const close=()=>{clearInterval(slide);url&&URL.revokeObjectURL(url);viewer.remove();viewer=null;document.removeEventListener("keydown",key);draw()};
      const show=async()=>{const it=L[i];const my=++tok;url&&URL.revokeObjectURL(url);url=null;
        $("[data-t]",viewer).innerHTML=`<b>${esc(it.name)}</b><span>${esc(dayName(it.t))} · ${i+1} of ${L.length}</span>`;
        $("[data-fav]",viewer).classList.toggle("on",PL.favs().includes(it.key));
        stage.innerHTML=`${it.thumb||Thumbs.mem.get(it.id)?`<img src="${esc(it.thumb||Thumbs.mem.get(it.id))}" style="filter:blur(2px);opacity:.6">`:`<span class="spin">Loading…</span>`}<button class="nav l" data-p>‹</button><button class="nav r" data-n>›</button>${info?infoBox(it):""}`;
        $("[data-p]",stage).onclick=e=>{e.stopPropagation();go(-1)};$("[data-n]",stage).onclick=e=>{e.stopPropagation();go(1)};
        try{let src;if(it.src==="local"){url=URL.createObjectURL(it.entry.blob);src=url}
          else if(it.src==="m"&&it.full&&!it.video)src=it.full;
          else{const b=await PL.blob(it);if(my!==tok)return;url=URL.createObjectURL(b);src=url}
          if(my!==tok)return;
          const el=it.video?Object.assign(document.createElement("video"),{src,controls:true,playsInline:true,autoplay:true}):Object.assign(document.createElement("img"),{src});
          if(it.video)el.setAttribute("playsinline","");
          const old=$("img,video,.spin",stage);old?old.replaceWith(el):stage.prepend(el);
          el.onerror=()=>{if(my===tok)stage.prepend(Object.assign(document.createElement("div"),{className:"spin",textContent:"Couldn't show this item. Try Share to open it in another app."}))}}
        catch(e){if(my!==tok)return;const s=$(".spin,img",stage);const msg=e instanceof NeedAuth?"Sign in again to see the full photo.":"Couldn't load: "+String(e.message||e).slice(0,80);
          if(s)s.outerHTML=`<span class="spin">${esc(msg)}${e instanceof NeedAuth?` <button class="btn" data-re>Reconnect</button>`:""}</span>`;
          const re=$("[data-re]",stage);if(re)re.onclick=async()=>{await DB.set("oauth-reopen-app",{app:"photos"});connectAccount(e.acc||mailAccounts().find(a=>a.id===it.acc))}}};
      const infoBox=it=>`<div class="info"><b>${esc(it.name)}</b><br>${esc(dayName(it.t))}<br>${it.size?fmtSize(it.size)+"<br>":""}${it.cam?esc(it.cam)+"<br>":""}
        ${it.lat!=null?`Location: ${it.lat.toFixed(4)}, ${it.lng.toFixed(4)}<br><a href="https://maps.apple.com/?ll=${it.lat},${it.lng}&q=${encodeURIComponent(it.name)}" target="_blank" rel="noopener">Open in Maps ↗</a><br>`:"No location data<br>"}
        Source: ${it.src==="local"?"On this iPad (Nimbus)":it.src==="m"?"OneDrive":"Google Drive"}</div>`;
      const go=d=>{i=(i+d+L.length)%L.length;show()};
      const key=e=>{if(!viewer)return;if(e.key==="ArrowRight")go(1);else if(e.key==="ArrowLeft")go(-1);else if(e.key==="Escape")close()};
      document.addEventListener("keydown",key);
      let sx=null;stage.addEventListener("pointerdown",e=>{sx=e.clientX});stage.addEventListener("pointerup",e=>{if(sx==null)return;const dx=e.clientX-sx;sx=null;if(Math.abs(dx)>50)go(dx<0?1:-1)});
      $("[data-x]",viewer).onclick=close;
      $("[data-fav]",viewer).onclick=()=>{const on=toggleFav(L[i]);$("[data-fav]",viewer).classList.toggle("on",on)};
      $("[data-info]",viewer).onclick=()=>{info=!info;const b=$(".info",stage);if(b)b.remove();if(info)stage.insertAdjacentHTML("beforeend",infoBox(L[i]))};
      $("[data-sh]",viewer).onclick=()=>shareItem(L[i]);
      $("[data-more]",viewer).onclick=e=>{const r=e.target.getBoundingClientRect();const it=L[i];UI.menu([
        {label:slide?"Stop Slideshow":"Play Slideshow",action:()=>{if(slide){clearInterval(slide);slide=null}else slide=setInterval(()=>go(1),3500)}},
        {label:"Add to Album…",action:()=>addToAlbum(it,r.left,r.bottom+4)},
        ...(!it.video?[{label:"Use as Wallpaper",action:async()=>{try{const b=await PL.blob(it);await DB.set("wallpaper-img",b);S.wallpaper="custom";applyWallpaper();saveSettings();UI.toast("Wallpaper set",it.name,"photos")}catch(err){UI.toast("Couldn't set wallpaper",String(err.message||err),"photos")}}}]:[]),
        {label:"Save a Copy to Files",action:async()=>{try{const b=await PL.blob(it);await FS.addBlob("pictures",it.name,b);UI.toast("Saved to Pictures",it.name,"photos")}catch(err){UI.toast("Couldn't save",String(err.message||err),"photos")}}},
        ...(it.src==="local"?["-",{label:"Delete",danger:true,action:async()=>{if(await delItem(it)){L.splice(i,1);if(!L.length)close();else{i=i%L.length;show()}}}}]:[])],r.left-120,r.bottom+4)};
      show();
      return {play(){slide=setInterval(()=>go(1),3500)}}};
    $("[data-zoom]",w.body).oninput=e=>{st.size=+e.target.value;S.photoSize=st.size;scroll.style.setProperty("--ph",st.size+"px")};
    $("[data-zoom]",w.body).onchange=()=>saveSettings();
    let qT;$("[data-q]",w.body).oninput=e=>{clearTimeout(qT);qT=setTimeout(()=>{st.q=e.target.value;draw()},200)};
    $("[data-imp]",w.body).onclick=doImport;
    $("[data-slide]",w.body).onclick=()=>{if(!st.list.length)return;const v=openViewer(0);v&&v.play()};
    const reload=async()=>{await PL.load();drawSide();if(!viewer)draw()};
    let rT;const onFs=()=>{clearTimeout(rT);rT=setTimeout(reload,400)};FS.listeners.add(onFs);
    (async()=>{scroll.innerHTML=`<div class="ph-empty">Loading your photos…</div>`;await reload();
      if(PL.cloudAccounts().length)PL.refreshCloud(false,errs=>{drawSide();if(!viewer)draw();
        errs.forEach(([a,e])=>UI.toast(e instanceof NeedAuth?"Sign in again for photos":"Couldn't load cloud photos",`${a.email}${e instanceof NeedAuth?"":" · "+String(e.message||e).slice(0,60)}`,"photos"))})})();
    w.setTitle("Photos");
    return {close(){FS.listeners.delete(onFs);io.disconnect()},refresh(){PL.refreshCloud(true,()=>{drawSide();draw()})}}}
};

/* ------------------------------ YouTube ------------------------------ */
const YT={
  account(){const g=mailAccounts().filter(a=>kindOf(a)==="g");return g.find(a=>MT.connected(a)&&/youtube/.test((MT.tokens[a.id]||{}).scope||""))||null},
  googleAccounts(){return mailAccounts().filter(a=>kindOf(a)==="g")},
  canSearch(){return !!(YT.account()||S.ytKey)},
  async get(path,params){const qs=Object.entries(params).filter(([,v])=>v!=null&&v!=="").map(([k,v])=>k+"="+encodeURIComponent(v)).join("&");
    const url=`https://www.googleapis.com/youtube/v3/${path}?${qs}`;const a=YT.account();
    if(a){try{return await api(a,url)}catch(e){if(!(e instanceof NeedAuth)||!S.ytKey)throw e}}
    if(S.ytKey){const r=await fetch(url+"&key="+encodeURIComponent(S.ytKey));const j=await r.json();if(!r.ok)throw new Error((j.error&&j.error.message)||"HTTP "+r.status);return j}
    throw new Error("Connect a Google account (or add an API key) to browse YouTube.")},
  card(s,id,extra={}){const sn=s.snippet||s;return {id,title:sn.title,channel:sn.channelTitle||sn.videoOwnerChannelTitle||"",channelId:sn.channelId||sn.videoOwnerChannelId,
    published:sn.publishedAt,thumb:((sn.thumbnails||{}).high||(sn.thumbnails||{}).medium||(sn.thumbnails||{}).default||{}).url||`https://i.ytimg.com/vi/${id}/hqdefault.jpg`,desc:sn.description||"",...extra}},
  idFrom(u){const m=String(u).match(/(?:v=|youtu\.be\/|\/shorts\/|\/embed\/|\/live\/)([\w-]{11})/);return m?m[1]:(/^[\w-]{11}$/.test(u)?u:null)},
  remember(list,v,max=100){const L=S[list]||(S[list]=[]);const i=L.findIndex(x=>x.id===v.id);if(i>=0)L.splice(i,1);L.unshift({id:v.id,title:v.title,channel:v.channel,channelId:v.channelId,thumb:v.thumb,published:v.published,t:Date.now()});L.length=Math.min(L.length,max);saveSettings()},
  ago(t){if(!t)return "";const s=(Date.now()-Date.parse(t))/1000;const u=[[31536000,"year"],[2592000,"month"],[604800,"week"],[86400,"day"],[3600,"hour"],[60,"minute"]];for(const [n,l] of u)if(s>=n){const k=Math.floor(s/n);return `${k} ${l}${k>1?"s":""} ago`}return "just now"},
  openApp(id){const web=`https://www.youtube.com/watch?v=${id}`;const t=Date.now();location.href=`youtube://www.youtube.com/watch?v=${id}`;setTimeout(()=>{if(document.visibilityState==="visible"&&Date.now()-t<2500)window.open(web,"_blank","noopener")},1500)}
};
window.YT=YT;
const ytDur=d=>{const m=String(d||"").match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);if(!m)return "";const h=+m[1]||0,mi=+m[2]||0,s=+m[3]||0;return (h?h+":"+String(mi).padStart(2,"0"):mi)+":"+String(s).padStart(2,"0")};

APPS.youtube={name:"YouTube",icon:"youtube",w:1040,h:700,single:true,
  create(w,opts){
    const st={view:"home",hist:[],q:""};
    w.body.innerHTML=`<div class="yt"><div class="sidebar" data-side></div><div class="main">
      <div class="yt-top"><button class="btn icon" data-back>${SVG.back}</button><form data-f><input class="field" placeholder="Search YouTube or paste a link" data-q enterkeyhint="search"><button class="btn primary">Search</button></form><button class="btn" data-acct></button></div>
      <div class="yt-scroll" data-scroll></div></div></div>`;
    const side=$("[data-side]",w.body),scroll=$("[data-scroll]",w.body);
    const NAV=[["home","⌂","Home"],["subs","☰","Subscriptions"],["liked","♥︎","Liked videos"],["playlists","▤","Playlists"],["later","◷","Watch Later"],["history","↺","History"]];
    const drawSide=()=>{side.innerHTML=`<h5>YouTube</h5>${NAV.map(([k,i,l])=>`<div class="si ${st.view===k?"act":""}" data-v="${k}"><span style="width:16px;text-align:center;color:var(--accent)">${i}</span>${l}</div>`).join("")}`;
      $$("[data-v]",side).forEach(s=>s.onclick=()=>nav(s.dataset.v))};
    const drawAcct=()=>{const a=YT.account();const b=$("[data-acct]",w.body);b.textContent=a?a.email.split("@")[0]:"Sign in";b.onclick=e=>{const r=e.target.getBoundingClientRect();
      const g=YT.googleAccounts();UI.menu([...g.map(x=>({label:`${x.email}${YT.account()===x?" ✓":""}`,action:()=>allow(x)})),g.length?"-":null,
        {label:"Add a Google account in Mail…",action:()=>WM.open("mail")},{label:S.ytKey?"Change API key…":"Use an API key instead…",action:setKey}].filter(Boolean),r.left-120,r.bottom+4)}};
    const allow=async a=>{await DB.set("oauth-reopen-app",{app:"youtube"});connectAccount(a)};
    const setKey=async()=>{const r=await UI.dialog({title:"YouTube API key",text:"Optional. With a YouTube Data API key you can search without signing in. Create one in Google Cloud Console › APIs & Services › Credentials, with the YouTube Data API v3 enabled.",fields:[{ph:"AIza…",value:S.ytKey||""}],ok:"Save"});if(r){S.ytKey=r[0].trim();saveSettings();render()}};
    const nav=(v,arg,push=true)=>{if(push)st.hist.push({view:st.view,arg:st.arg});st.view=v;st.arg=arg;drawSide();render()};
    const grid=(list,title)=>`${title?`<h3>${esc(title)}</h3>`:""}<div class="yt-grid">${list.map((v,i)=>`<div class="yt-card" data-i="${i}"><div class="th"><img loading="lazy" src="${esc(v.thumb)}" alt="">${v.dur?`<i>${esc(v.dur)}</i>`:""}</div><b>${esc(v.title)}</b><span>${esc(v.channel)}${v.published?" · "+YT.ago(v.published):""}</span></div>`).join("")}</div>`;
    const wire=list=>$$(".yt-card",scroll).forEach(c=>{c.onclick=()=>play(list[+c.dataset.i]);
      longPress(c,e=>{const v=list[+c.dataset.i];UI.menu([{label:"Save to Watch Later",action:()=>{YT.remember("ytLater",v,500);UI.toast("Saved to Watch Later",v.title,"youtube")}},
        {label:"Open in YouTube app",action:()=>YT.openApp(v.id)},{label:"Copy link",action:()=>navigator.clipboard&&navigator.clipboard.writeText(`https://youtu.be/${v.id}`)}],e.clientX,e.clientY)})});
    const durations=async list=>{try{if(!list.length||!YT.canSearch())return;const j=await YT.get("videos",{part:"contentDetails",id:list.slice(0,50).map(v=>v.id).join(",")});
      const m=new Map((j.items||[]).map(x=>[x.id,ytDur(x.contentDetails.duration)]));list.forEach(v=>v.dur=m.get(v.id)||v.dur);
      $$(".yt-card",scroll).forEach(c=>{const v=list[+c.dataset.i];if(v&&v.dur&&!$("i",c))$(".th",c).insertAdjacentHTML("beforeend",`<i>${esc(v.dur)}</i>`)})}catch(e){}};
    const note=()=>{const g=YT.googleAccounts();if(YT.canSearch())return "";
      return `<div class="yt-note"><b>Watch YouTube inside Nimbus</b><br>
        ${g.length?`Allow YouTube access for your Google account to see your subscriptions, liked videos and playlists, and to search.`:`Add your Gmail account in Mail first (it uses the same Google sign-in), then allow YouTube access here.`}
        Until then, paste any YouTube link above and it plays here.<br>
        ${g.map(a=>`<button class="btn primary" data-allow="${a.id}">Allow YouTube for ${esc(a.email)}</button>`).join("")}${g.length?"":`<button class="btn primary" data-mail>Open Mail</button>`}<button class="btn" data-key>Use an API key</button></div>`};
    const wireNote=()=>{$$("[data-allow]",scroll).forEach(b=>b.onclick=()=>allow(mailAccounts().find(a=>a.id===b.dataset.allow)));const m=$("[data-mail]",scroll);if(m)m.onclick=()=>WM.open("mail");const k=$("[data-key]",scroll);if(k)k.onclick=setKey};
    const fail=e=>{const needs=e instanceof NeedAuth;scroll.innerHTML=`<div class="yt-note"><b>${needs?"Sign in again":"Couldn't load YouTube"}</b><br>${esc(needs?"Your Google session has expired (Google sign-ins last about an hour).":String(e.message||e))}
      ${/has not been used|disabled|accessNotConfigured|insufficient/i.test(String(e.message))?"<br>In Google Cloud Console, enable <b>YouTube Data API v3</b> for your Nimbus project and add the <code>youtube.readonly</code> scope.":""}<br>
      ${needs?`<button class="btn primary" data-re>Reconnect</button>`:""}<button class="btn" data-retry>Try again</button></div>`;
      const re=$("[data-re]",scroll);if(re)re.onclick=()=>allow(e.acc||YT.account()||YT.googleAccounts()[0]);$("[data-retry]",scroll).onclick=render};
    const loading=t=>scroll.innerHTML=`<div class="muted" style="padding:30px;text-align:center">${esc(t||"Loading…")}</div>`;
    const render=async()=>{drawAcct();const v=st.view;$("[data-back]",w.body).style.visibility=st.hist.length?"visible":"hidden";
      try{
        if(v==="play")return showPlayer(st.arg);
        if(v==="later"||v==="history"){const L=(v==="later"?S.ytLater:S.ytHistory)||[];
          scroll.innerHTML=L.length?grid(L,v==="later"?"Watch Later":"History")+`<p style="margin-top:18px"><button class="btn" data-clear>Clear ${v==="later"?"Watch Later":"History"}</button></p>`:`<div class="yt-note">${v==="later"?"Long-press a video and choose <b>Save to Watch Later</b>, or tap Watch Later under a video.":"Videos you watch in Nimbus show up here."}</div>`;
          wire(L);const c=$("[data-clear]",scroll);if(c)c.onclick=()=>{S[v==="later"?"ytLater":"ytHistory"]=[];saveSettings();render()};return}
        if(!YT.canSearch()){scroll.innerHTML=note()+((S.ytHistory||[]).length?grid(S.ytHistory.slice(0,12),"Recently watched"):"");wireNote();wire(S.ytHistory||[]);return}
        if(v==="search"){loading("Searching…");const j=await YT.get("search",{part:"snippet",type:"video",maxResults:30,q:st.arg});const L=(j.items||[]).map(x=>YT.card(x,x.id.videoId));scroll.innerHTML=grid(L,`Results for “${st.arg}”`);wire(L);durations(L);return}
        if(v==="channel"){loading();const up="UU"+String(st.arg.id).slice(2);const j=await YT.get("playlistItems",{part:"snippet",playlistId:up,maxResults:40});
          const L=(j.items||[]).map(x=>YT.card(x,x.snippet.resourceId.videoId,{channel:st.arg.title}));scroll.innerHTML=grid(L,st.arg.title);wire(L);durations(L);return}
        if(v==="playlist"){loading();const j=await YT.get("playlistItems",{part:"snippet",playlistId:st.arg.id,maxResults:50});
          const L=(j.items||[]).filter(x=>x.snippet.resourceId&&x.snippet.title!=="Private video"&&x.snippet.title!=="Deleted video").map(x=>YT.card(x,x.snippet.resourceId.videoId));scroll.innerHTML=grid(L,st.arg.title);wire(L);durations(L);return}
        const a=YT.account();
        if(v==="home"){loading();
          if(a){const subs=await YT.get("subscriptions",{part:"snippet",mine:"true",maxResults:50,order:"relevance"});const chans=(subs.items||[]).slice(0,16);
            const lists=await Promise.all(chans.map(c=>YT.get("playlistItems",{part:"snippet",playlistId:"UU"+c.snippet.resourceId.channelId.slice(2),maxResults:4}).catch(()=>({items:[]}))));
            let L=lists.flatMap(l=>(l.items||[]).map(x=>YT.card(x,x.snippet.resourceId.videoId)));
            L=L.filter(x=>x.title!=="Private video").sort((x,y)=>Date.parse(y.published)-Date.parse(x.published)).slice(0,48);
            if(!L.length){const p=await YT.get("videos",{part:"snippet,contentDetails",chart:"mostPopular",maxResults:30,regionCode:S.ytRegion||"US"});L=(p.items||[]).map(x=>YT.card(x,x.id,{dur:ytDur(x.contentDetails.duration)}))}
            scroll.innerHTML=grid(L,"Latest from your subscriptions");wire(L);durations(L)}
          else{const p=await YT.get("videos",{part:"snippet,contentDetails",chart:"mostPopular",maxResults:30,regionCode:S.ytRegion||"US"});const L=(p.items||[]).map(x=>YT.card(x,x.id,{dur:ytDur(x.contentDetails.duration)}));scroll.innerHTML=grid(L,"Popular");wire(L)}
          return}
        if(!a){scroll.innerHTML=note()||`<div class="yt-note">Subscriptions, likes and playlists need your Google account. <button class="btn primary" data-s>Sign in</button></div>`;wireNote();const s=$("[data-s]",scroll);if(s)s.onclick=()=>{const g=YT.googleAccounts()[0];g?allow(g):WM.open("mail")};return}
        if(v==="subs"){loading();const j=await YT.get("subscriptions",{part:"snippet",mine:"true",maxResults:50,order:"alphabetical"});const C=j.items||[];
          scroll.innerHTML=`<h3>Subscriptions</h3><div class="yt-grid" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:4px">${C.map((c,i)=>`<div class="yt-chan" data-c="${i}"><img src="${esc((c.snippet.thumbnails.default||{}).url||"")}" alt=""><b style="font-size:13.5px">${esc(c.snippet.title)}</b></div>`).join("")}</div>`;
          $$("[data-c]",scroll).forEach(el=>el.onclick=()=>{const c=C[+el.dataset.c];nav("channel",{id:c.snippet.resourceId.channelId,title:c.snippet.title})});return}
        if(v==="liked"){loading();const j=await YT.get("videos",{part:"snippet,contentDetails",myRating:"like",maxResults:50});const L=(j.items||[]).map(x=>YT.card(x,x.id,{dur:ytDur(x.contentDetails.duration)}));scroll.innerHTML=grid(L,"Liked videos");wire(L);return}
        if(v==="playlists"){loading();const j=await YT.get("playlists",{part:"snippet,contentDetails",mine:"true",maxResults:50});const P=j.items||[];
          scroll.innerHTML=P.length?`<h3>Playlists</h3><div class="yt-grid">${P.map((p,i)=>`<div class="yt-card" data-p="${i}"><div class="th"><img src="${esc(((p.snippet.thumbnails||{}).medium||{}).url||"")}" alt=""><i>${p.contentDetails.itemCount} videos</i></div><b>${esc(p.snippet.title)}</b></div>`).join("")}</div>`:`<div class="yt-note">You don't have any playlists yet.</div>`;
          $$("[data-p]",scroll).forEach(el=>el.onclick=()=>{const p=P[+el.dataset.p];nav("playlist",{id:p.id,title:p.snippet.title})});return}
      }catch(e){console.warn(e);fail(e)}};
    const play=v=>nav("play",v);
    const showPlayer=async v=>{YT.remember("ytHistory",v);
      const fs=S.allowFullscreen?"fullscreen; ":"";
      scroll.innerHTML=`<div class="yt-player"><div class="frame"><iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(v.id)}?autoplay=1&playsinline=1&rel=0&modestbranding=1" allow="${fs}autoplay; encrypted-media; picture-in-picture; clipboard-write" ${S.allowFullscreen?"allowfullscreen":""} referrerpolicy="strict-origin-when-cross-origin" title="${esc(v.title||"Video")}"></iframe></div>
        <h2>${esc(v.title||"Video")}</h2><div class="meta"><span>${esc(v.channel||"")}${v.published?" · "+YT.ago(v.published):""}</span><span style="flex:1"></span>
        ${v.channelId&&YT.canSearch()?`<button class="btn" data-ch>More from ${esc(v.channel||"channel")}</button>`:""}<button class="btn" data-wl>◷ Watch Later</button><button class="btn" data-sh>${SVG.share} Share</button><button class="btn" data-app>Open in YouTube app ↗</button></div>
        <div class="desc" data-desc>${esc(v.desc||"")}</div>
        <p class="muted" style="font-size:12px;margin-top:10px">If the video says it can't play here, the creator has turned off playback outside YouTube. Tap <b>Open in YouTube app</b>.</p></div>`;
      const d=$("[data-desc]",scroll);if(!v.desc)d.style.display="none";d.onclick=()=>d.classList.toggle("open");
      $("[data-wl]",scroll).onclick=()=>{YT.remember("ytLater",v,500);UI.toast("Saved to Watch Later",v.title||"","youtube")};
      $("[data-app]",scroll).onclick=()=>YT.openApp(v.id);
      $("[data-sh]",scroll).onclick=async()=>{const u=`https://youtu.be/${v.id}`;try{if(navigator.share){await navigator.share({title:v.title,url:u});return}}catch(e){if(e.name==="AbortError")return}navigator.clipboard&&navigator.clipboard.writeText(u);UI.toast("Link copied",u,"youtube")};
      const ch=$("[data-ch]",scroll);if(ch)ch.onclick=()=>nav("channel",{id:v.channelId,title:v.channel});
      if(!v.title&&YT.canSearch()){try{const j=await YT.get("videos",{part:"snippet",id:v.id});const x=j.items&&j.items[0];if(x&&st.view==="play"&&st.arg===v){Object.assign(v,YT.card(x,x.id));YT.remember("ytHistory",v);showPlayer(v)}}catch(e){}}};
    const route=o=>{if(!o)return;if(o.video)play(typeof o.video==="string"?{id:o.video}:o.video);else if(o.q)nav("search",o.q);else if(o.view)nav(o.view)};
    $("[data-f]",w.body).onsubmit=e=>{e.preventDefault();const q=$("[data-q]",w.body).value.trim();if(!q)return;const id=YT.idFrom(q);
      if(id&&/youtu|^[\w-]{11}$/.test(q))play({id});
      else if(/[?&]list=([\w-]+)/.test(q))nav("playlist",{id:q.match(/[?&]list=([\w-]+)/)[1],title:"Playlist"});
      else if(!YT.canSearch()){UI.toast("Search needs YouTube access","Allow YouTube for your Google account, or paste a video link.","youtube");render()}
      else nav("search",q)};
    $("[data-back]",w.body).onclick=()=>{const p=st.hist.pop();if(!p)return;st.view=p.view;st.arg=p.arg;drawSide();render()};
    drawSide();render();if(opts)setTimeout(()=>route(opts),0);
    return {reopen:o=>route(o)}},
  reopen(w,opts){if(w.hooks&&w.hooks.reopen)w.hooks.reopen(opts)}
};

/* Browser: youtube.com pages refuse to load inside other apps, so hand them to the YouTube app */
const _makeWebView42=makeWebView;
makeWebView=function(view,o){const wv=_makeWebView42(view,o);const load0=wv.load;
  wv.load=(url,force)=>{const m=String(url||"").match(/^https?:\/\/(?:(?:www|m|music)\.)?(youtube\.com|youtu\.be)(\/[^#]*)?/i);
    if(m&&!/\/embed\//.test(url)&&!force){let route={view:"home"};const id=YT.idFrom(url);const q=url.match(/[?&]search_query=([^&]+)/);
      if(id)route={video:id};else if(q)route={q:decodeURIComponent(q[1].replace(/\+/g," "))};else{const h=url.match(/youtube\.com\/(@[\w.-]+)/);if(h)route={q:h[1]}}
      view.querySelectorAll("iframe,.br-blocked,.br-hint,.br-progress").forEach(e=>e.remove());
      const card=html(`<div class="br-blocked">${ICON.youtube()}<h3>YouTube plays in the Nimbus YouTube app</h3><p>youtube.com doesn't allow itself to load inside other apps, which is why the page stayed blank. The Nimbus YouTube app plays videos right here, with your subscriptions once you allow access.</p>
        <div style="display:flex;gap:8px"><button class="btn primary" data-yt>Open YouTube</button><a class="btn" href="${esc(url)}" target="_blank" rel="noopener" style="text-decoration:none">Open in Safari ↗</a></div></div>`);
      $("[data-yt]",card).onclick=()=>WM.open("youtube",route);view.appendChild(card);
      WM.open("youtube",route);return}
    return load0(url,force)};
  return wv};

/* Dock, Launchpad, Spotlight */
if(typeof BASE_DOCK!=="undefined"){const at=BASE_DOCK.indexOf("messages");if(!BASE_DOCK.includes("photos"))BASE_DOCK.splice(at<0?3:at,0,"photos");if(!BASE_DOCK.includes("youtube"))BASE_DOCK.splice(BASE_DOCK.indexOf("photos")+1,0,"youtube")}
