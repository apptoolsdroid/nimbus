/* Nimbus Desktop — extra apps & features: Documents, Sheets, Code, Launchpad, Downloads stack,
   lock screen, permanent Linux drive + shared folder. Loaded after the core script. */
"use strict";

/* ================= styles ================= */
document.head.appendChild(html(`<style>
/* documents */
.doc-wrap{flex:1;overflow:auto;background:rgba(120,120,128,.18);padding:28px 0;-webkit-overflow-scrolling:touch}
.doc-page{width:min(816px,calc(100% - 40px));min-height:1056px;margin:0 auto;background:#fff;color:#1d1d1f;box-shadow:0 4px 24px rgba(0,0,0,.18);padding:72px 80px;outline:none;font:16px/1.55 "Calibri","Helvetica Neue",Arial,sans-serif;-webkit-user-select:text;user-select:text}
.doc-page h1{font-size:28px;margin:.4em 0}.doc-page h2{font-size:22px;margin:.5em 0}.doc-page h3{font-size:18px;margin:.5em 0}
.doc-page p{margin:0 0 .6em}.doc-page blockquote{border-left:4px solid #c7c7d1;margin:.6em 0;padding:.2em 1em;color:#555}
.doc-page table{border-collapse:collapse;width:100%;margin:.6em 0}.doc-page td,.doc-page th{border:1px solid #bbb;padding:6px 8px;min-width:40px}
.doc-page img{max-width:100%}.doc-page a{color:#0a66d8}
.rt{display:flex;align-items:center;gap:4px;padding:6px 10px;border-bottom:1px solid var(--hair);flex-wrap:wrap;flex:none}
.rt .btn{padding:5px 8px;min-width:30px;justify-content:center;font-size:13px}
.rt select{border:0;background:var(--field);border-radius:7px;padding:5px 6px;font-size:12.5px;color:var(--text);font-family:inherit}
.rt .sep2{width:1px;height:22px;background:var(--hair);margin:0 3px}
.rt input[type=color]{width:28px;height:26px;border:0;padding:0;background:none;border-radius:6px}
.statusbar{display:flex;gap:14px;padding:4px 12px;font-size:11.5px;color:var(--text3);border-top:1px solid var(--hair);flex:none}
/* sheets */
.sh-bar{display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid var(--hair);flex:none}
.sh-bar .ref{width:64px;text-align:center;font-weight:600;font-size:12.5px;background:var(--field);border-radius:6px;padding:5px 0}
.sh-bar .fx{color:var(--text3);font-style:italic;font-family:Georgia,serif}
.sh-grid{flex:1;overflow:auto;position:relative;background:var(--win-bg);-webkit-overflow-scrolling:touch}
.sh-grid table{border-collapse:collapse;table-layout:fixed;font-size:13px}
.sh-grid th{position:sticky;top:0;background:var(--side-bg);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);color:var(--text2);font-weight:500;font-size:11.5px;height:24px;border:1px solid var(--hair);z-index:2}
.sh-grid th.rh{position:sticky;left:0;z-index:3;width:46px}
.sh-grid td.rh{position:sticky;left:0;background:var(--side-bg);color:var(--text2);font-size:11.5px;text-align:center;border:1px solid var(--hair);z-index:1}
.sh-grid td{border:1px solid var(--hair);height:26px;padding:0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:cell}
.sh-grid td.num{text-align:right}.sh-grid td.err{color:#ff3b30}
.sh-grid td.sel{outline:2px solid var(--accent);outline-offset:-2px;background:color-mix(in srgb,var(--accent) 10%,transparent)}
.sh-grid td.insel{background:color-mix(in srgb,var(--accent) 14%,transparent)}
.sh-grid th.hl{background:color-mix(in srgb,var(--accent) 25%,var(--side-bg));color:var(--text)}
.sh-edit{position:absolute;z-index:5;border:2px solid var(--accent);background:var(--win-bg);color:var(--text);font-size:13px;padding:0 5px;outline:none;box-shadow:0 2px 10px rgba(0,0,0,.2)}
.sh-tabs{display:flex;gap:2px;padding:4px 8px;border-top:1px solid var(--hair);flex:none;align-items:center;overflow-x:auto}
.sh-tabs .tab{padding:4px 12px;border-radius:6px;font-size:12px;cursor:default;white-space:nowrap}
.sh-tabs .tab.act{background:var(--field);font-weight:600}
/* code */
.code{flex:1;display:flex;min-width:0;background:#1e1e1e;color:#ccc}
:root[data-theme=light] .code{background:#fff;color:#333}
.code .act-bar{width:46px;flex:none;background:#2c2c2c;display:flex;flex-direction:column;align-items:center;padding-top:6px;gap:4px}
:root[data-theme=light] .code .act-bar{background:#f0f0f3}
.code .act-bar button{width:38px;height:38px;border:0;background:none;color:#8a8a8a;border-radius:8px;display:flex;align-items:center;justify-content:center}
.code .act-bar button.on,.code .act-bar button:hover{color:#fff;background:rgba(255,255,255,.08)}
:root[data-theme=light] .code .act-bar button.on{color:#111;background:rgba(0,0,0,.06)}
.code .act-bar svg{width:22px;height:22px}
.code .explorer{width:210px;flex:none;background:#252526;overflow:auto;font-size:13px;border-right:1px solid rgba(128,128,128,.2)}
:root[data-theme=light] .code .explorer{background:#f7f7f9}
.code .explorer h6{margin:0;padding:10px 12px 6px;font-size:11px;letter-spacing:.06em;color:#9a9a9a;display:flex;justify-content:space-between;align-items:center}
.code .explorer h6 span{display:flex;gap:2px}.code .explorer h6 button{border:0;background:none;color:inherit;padding:2px 4px;border-radius:4px}
.code .explorer h6 button:hover{background:rgba(128,128,128,.25)}
.code .tn{display:flex;align-items:center;gap:6px;padding:3px 8px;cursor:default;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.code .tn:hover{background:rgba(128,128,128,.15)}.code .tn.act{background:rgba(10,132,255,.28)}
.code .tn i{font-style:normal;width:14px;text-align:center;opacity:.7;font-size:10px;flex:none}
.code .tn b{font-weight:400;font-size:10.5px;width:18px;text-align:center;border-radius:3px;flex:none}
.code .center{flex:1;display:flex;flex-direction:column;min-width:0}
.code .tabs{display:flex;background:#252526;overflow-x:auto;flex:none;min-height:35px}
:root[data-theme=light] .code .tabs{background:#f0f0f3}
.code .tabs .t{display:flex;align-items:center;gap:8px;padding:0 10px 0 14px;height:35px;font-size:12.5px;border-right:1px solid rgba(0,0,0,.25);cursor:default;white-space:nowrap;color:#999}
.code .tabs .t.act{background:#1e1e1e;color:#fff}
:root[data-theme=light] .code .tabs .t.act{background:#fff;color:#111}
.code .tabs .t u{text-decoration:none;opacity:.6;padding:0 3px;border-radius:4px}.code .tabs .t u:hover{background:rgba(128,128,128,.3);opacity:1}
.code .runbar{display:flex;gap:6px;align-items:center;padding:5px 8px;background:#252526;flex:none;border-bottom:1px solid rgba(0,0,0,.3)}
:root[data-theme=light] .code .runbar{background:#f7f7f9;border-color:rgba(0,0,0,.08)}
.code .runbar .btn{font-size:12px;padding:4px 10px;background:rgba(128,128,128,.2);color:inherit}
.code .runbar .btn.go{background:#2ea043;color:#fff}
.code .editor-host{flex:1;min-height:0;position:relative}
.code .panel{height:34%;min-height:90px;flex:none;border-top:1px solid rgba(128,128,128,.3);display:flex;flex-direction:column;background:#1e1e1e}
:root[data-theme=light] .code .panel{background:#fff}
.code .panel .ph{display:flex;gap:14px;padding:6px 12px;font-size:11px;letter-spacing:.05em;color:#9a9a9a;align-items:center;flex:none}
.code .panel .ph span.on{color:inherit;border-bottom:1px solid currentColor;color:#fff}
:root[data-theme=light] .code .panel .ph span.on{color:#111}
.code .panel pre{flex:1;margin:0;overflow:auto;padding:4px 12px 10px;font:12.5px/1.45 var(--mono);white-space:pre-wrap;word-break:break-word;-webkit-user-select:text;user-select:text}
.code .panel pre .e{color:#f48771}.code .panel pre .s{color:#73c991}
.code .panel iframe{flex:1;border:0;background:#fff}
.code .stbar{display:flex;gap:16px;padding:0 10px;height:22px;align-items:center;background:#0a6ccf;color:#fff;font-size:11.5px;flex:none}
.code .welcome{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#888;text-align:center;padding:20px}
.code .welcome b{font-size:20px;color:inherit}
/* launchpad */
#launchpad{position:fixed;inset:0;z-index:8800;display:none;flex-direction:column;align-items:center;padding:calc(60px + var(--safe-top)) 40px 120px;
  background:rgba(20,20,30,.35);backdrop-filter:blur(40px) saturate(160%);-webkit-backdrop-filter:blur(40px) saturate(160%);animation:lpin .2s ease}
#launchpad.show{display:flex}
@keyframes lpin{from{opacity:0;transform:scale(1.04)}}
#launchpad input{width:240px;border:0;border-radius:9px;padding:7px 12px;background:rgba(255,255,255,.2);color:#fff;outline:none;font-size:14px;text-align:center}
#launchpad input::placeholder{color:rgba(255,255,255,.7)}
#launchpad .lp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:34px 20px;width:100%;max-width:980px;margin-top:44px}
#launchpad .lp{display:flex;flex-direction:column;align-items:center;gap:8px;color:#fff;font-size:13px;text-shadow:0 1px 3px rgba(0,0,0,.5);cursor:pointer}
#launchpad .lp .ic{width:84px;height:84px;transition:transform .12s}
#launchpad .lp:active .ic{transform:scale(.92)}
/* downloads stack */
.stack{position:fixed;z-index:9300;width:340px;max-height:60vh;overflow:auto;border-radius:20px;padding:12px;background:var(--glass-strong);color:var(--text);box-shadow:var(--shadow);
  backdrop-filter:blur(40px) saturate(180%);-webkit-backdrop-filter:blur(40px) saturate(180%);border:1px solid var(--glass-border)}
.stack h4{margin:2px 4px 10px;font-size:13px;display:flex;justify-content:space-between}
.stack .sgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
/* lock */
#lock{position:fixed;inset:0;z-index:99990;display:none;flex-direction:column;align-items:center;color:#fff;padding-top:14vh;text-shadow:0 2px 12px rgba(0,0,0,.35);touch-action:none}
#lock.show{display:flex}
#lock .bg{position:absolute;inset:-40px;filter:blur(28px) brightness(.85);z-index:-1}
#lock .d{font-size:22px;font-weight:600;opacity:.9}
#lock .t{font-size:110px;font-weight:700;letter-spacing:-2px;line-height:1.05}
#lock .hint{position:absolute;bottom:calc(40px + var(--safe-bottom));font-size:14px;opacity:.8;animation:pulse 2s infinite}
@keyframes pulse{50%{opacity:.4}}
#snap{position:fixed;z-index:4;border-radius:16px;background:rgba(255,255,255,.18);border:2px solid rgba(255,255,255,.5);pointer-events:none;display:none;transition:all .12s}
</style>`));

/* ================= extra icons ================= */
Object.assign(ICON,{
  docs:()=>squircle("d","#5aa9ff","#2156d8",`<rect x="17" y="11" width="30" height="42" rx="4" fill="#fff"/><path d="M22 21h20M22 27h20M22 33h20M22 39h13" stroke="#2f6fe8" stroke-width="2.6" stroke-linecap="round"/>`),
  sheets:()=>squircle("x","#4ade80","#16a34a",`<rect x="13" y="14" width="38" height="36" rx="4" fill="#fff"/><path d="M13 24h38M13 33h38M13 42h38M26 14v36M38 14v36" stroke="#16a34a" stroke-width="2"/><rect x="13" y="14" width="38" height="10" rx="4" fill="#bbf7d0"/>`),
  code:()=>squircle("v","#3b82f6","#1e3a8a",`<path d="m24 22-10 10 10 10M40 22l10 10-10 10" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="m35 18-6 28" stroke="#93c5fd" stroke-width="3.5" stroke-linecap="round"/>`),
  launchpad:()=>squircle("g","#8b8fa3","#454959",`${[0,1,2].map(r=>[0,1,2].map(c=>`<rect x="${15+c*12}" y="${15+r*12}" width="9" height="9" rx="2.5" fill="${["#ff6b6b","#ffd43b","#69db7c","#4dabf7","#fff","#da77f2","#ffa94d","#38d9a9","#748ffc"][r*3+c]}"/>`).join("")).join("")}`),
  downloads:()=>`<svg class="ic" viewBox="0 0 64 64"><path d="M6 16a5 5 0 0 1 5-5h14l5 5h23a5 5 0 0 1 5 5v4H6z" fill="#3d8bfd"/><rect x="6" y="20" width="52" height="34" rx="5" fill="#6aaeff"/><circle cx="32" cy="37" r="11" fill="#fff" opacity=".95"/><path d="M32 31v11M27 38l5 5 5-5" fill="none" stroke="#3d8bfd" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  docfile:()=>`<svg class="ic" viewBox="0 0 64 64"><path d="M15 6h24l12 12v38a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z" fill="#fff" stroke="#c9c9d2"/><rect x="12" y="34" width="30" height="14" rx="3" fill="#2f6fe8"/><text x="27" y="45" font-size="10" font-weight="800" text-anchor="middle" fill="#fff" font-family="-apple-system,sans-serif">DOC</text></svg>`,
  xlsfile:()=>`<svg class="ic" viewBox="0 0 64 64"><path d="M15 6h24l12 12v38a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z" fill="#fff" stroke="#c9c9d2"/><rect x="12" y="34" width="30" height="14" rx="3" fill="#16a34a"/><text x="27" y="45" font-size="10" font-weight="800" text-anchor="middle" fill="#fff" font-family="-apple-system,sans-serif">XLS</text></svg>`,
  codefile:(ext)=>`<svg class="ic" viewBox="0 0 64 64"><path d="M15 6h24l12 12v38a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z" fill="#1e293b" stroke="#334155"/><path d="m25 28-6 6 6 6M38 28l6 6-6 6" fill="none" stroke="#60a5fa" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><text x="31.5" y="54" font-size="8" font-weight="700" text-anchor="middle" fill="#94a3b8" font-family="-apple-system,sans-serif">${esc((ext||"").toUpperCase().slice(0,4))}</text></svg>`
});
const CODE_EXT=/\.(py|js|mjs|ts|html?|css|json|md|sh|c|h|cpp|java|rb|go|rs|php|sql|xml|ya?ml|toml|ini|swift|kt)$/i;
const isDocx=e=>/\.docx$/i.test(e.name), isSheet=e=>/\.(xlsx|xls|csv|ods)$/i.test(e.name), isCode=e=>CODE_EXT.test(e.name);
const _fileIcon=fileIcon;
fileIcon=function(e){if(e.type!=="folder"){if(isDocx(e))return ICON.docfile();if(isSheet(e))return ICON.xlsfile();if(isCode(e))return ICON.codefile(e.name.split(".").pop())}return _fileIcon(e)};
const _openEntry=openEntry;
openEntry=async function(e){if(e.type!=="folder"){if(isDocx(e))return WM.open("docs",{id:e.id});if(isSheet(e))return WM.open("sheets",{id:e.id});if(isCode(e))return WM.open("code",{id:e.id})}return _openEntry(e)};

/* ================= script loader ================= */
const _loaded={};
function loadJS(src){return _loaded[src]||(_loaded[src]=new Promise((res,rej)=>{const s=document.createElement("script");s.src=src;s.onload=res;s.onerror=()=>{delete _loaded[src];rej(new Error("Couldn't load "+src))};document.head.appendChild(s)}))}
async function saveBlobAs(defName,blob,folder="documents"){const n=await UI.prompt("Save to "+(ROOTS.find(r=>r.id===folder)?.name||"Files")+" as",defName);if(!n)return null;const id=await FS.addBlob(folder,n,blob);return DB.fs.get(id)}

/* ================= FAT16 shared drive ================= */
const FAT={
  SIZE:64*1048576,
  build(files){
    const SEC=512,SPC=4,RES=4,NF=2,ROOT=512,total=FAT.SIZE/SEC,rootSec=ROOT*32/SEC;
    const fatSz=Math.ceil(((total-RES-rootSec)/SPC+2)*2/SEC);
    const dataStart=RES+NF*fatSz+rootSec,clusters=Math.floor((total-dataStart)/SPC);
    const buf=new ArrayBuffer(FAT.SIZE),u=new Uint8Array(buf),dv=new DataView(buf);
    u.set([0xEB,0x3C,0x90]);u.set([..."NIMBUS  "].map(c=>c.charCodeAt(0)),3);
    dv.setUint16(11,SEC,true);u[13]=SPC;dv.setUint16(14,RES,true);u[16]=NF;dv.setUint16(17,ROOT,true);dv.setUint16(19,0,true);u[21]=0xF8;
    dv.setUint16(22,fatSz,true);dv.setUint16(24,63,true);dv.setUint16(26,255,true);dv.setUint32(28,0,true);dv.setUint32(32,total,true);
    u[36]=0x80;u[38]=0x29;dv.setUint32(39,(Math.random()*0xffffffff)>>>0,true);u.set([..."SHARED     "].map(c=>c.charCodeAt(0)),43);u.set([..."FAT16   "].map(c=>c.charCodeAt(0)),54);
    u[510]=0x55;u[511]=0xAA;
    const fatOff=RES*SEC,setFat=(c,v)=>{for(let f=0;f<NF;f++)dv.setUint16(fatOff+f*fatSz*SEC+c*2,v,true)};
    setFat(0,0xFFF8);setFat(1,0xFFFF);
    const rootOff=(RES+NF*fatSz)*SEC;let ent=0;
    const wEnt=bytes=>{u.set(bytes,rootOff+ent*32);ent++};
    const label=new Uint8Array(32);label.set([..."SHARED     "].map(c=>c.charCodeAt(0)));label[11]=0x08;wEnt(label);
    let next=2;const used=new Set();const skipped=[];
    const dosDT=t=>{const d=new Date(t);return {time:(d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1),date:((Math.max(1980,d.getFullYear())-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate()}};
    for(const f of files){
      const need=Math.max(1,Math.ceil(f.data.length/(SPC*SEC)));
      const lfnCount=Math.ceil((f.name.length+1)/13);
      if(next+need>clusters+2||ent+lfnCount+1>ROOT){skipped.push(f.name);continue}
      // short name
      const dot=f.name.lastIndexOf(".");let base=(dot>0?f.name.slice(0,dot):f.name).toUpperCase().replace(/[^A-Z0-9]/g,""),ext=(dot>0?f.name.slice(dot+1):"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,3);
      if(!base)base="FILE";let sn,i=1;do{sn=(base.slice(0,6)+"~"+i).padEnd(8," ")+ext.padEnd(3," ");i++}while(used.has(sn));used.add(sn);
      const snb=[...sn].map(c=>c.charCodeAt(0));let sum=0;for(const b of snb)sum=(((sum&1)<<7)+(sum>>1)+b)&0xFF;
      const chars=[...f.name].map(c=>c.charCodeAt(0)&0xFFFF);chars.push(0);while(chars.length%13)chars.push(0xFFFF);
      for(let k=lfnCount;k>=1;k--){const e=new Uint8Array(32),ed=new DataView(e.buffer);e[0]=k|(k===lfnCount?0x40:0);e[11]=0x0F;e[13]=sum;
        const part=chars.slice((k-1)*13,k*13);const pos=[1,3,5,7,9,14,16,18,20,22,24,28,30];part.forEach((ch,j)=>ed.setUint16(pos[j],ch,true));wEnt(e)}
      const e=new Uint8Array(32),ed=new DataView(e.buffer);e.set(snb);e[11]=0x20;const {time,date}=dosDT(f.mtime||Date.now());
      ed.setUint16(14,time,true);ed.setUint16(16,date,true);ed.setUint16(18,date,true);ed.setUint16(22,time,true);ed.setUint16(24,date,true);
      const first=f.data.length?next:0;ed.setUint16(26,first,true);ed.setUint32(28,f.data.length,true);wEnt(e);
      if(f.data.length){for(let c=0;c<need;c++){setFat(next+c,c===need-1?0xFFFF:next+c+1)}
        u.set(f.data,(dataStart+(next-2)*SPC)*SEC);next+=need}
    }
    return {buffer:buf,skipped}},
  read(buf){
    const u=new Uint8Array(buf),dv=new DataView(buf);
    const SEC=dv.getUint16(11,true),SPC=u[13],RES=dv.getUint16(14,true),NF=u[16],ROOT=dv.getUint16(17,true),fatSz=dv.getUint16(22,true);
    if(SEC!==512||!SPC||!fatSz)return null;
    const fatOff=RES*SEC,rootOff=(RES+NF*fatSz)*SEC,dataStart=RES+NF*fatSz+ROOT*32/SEC,clsz=SPC*SEC;
    const out=[];let lfn=[];
    for(let i=0;i<ROOT;i++){const o=rootOff+i*32,b0=u[o];if(b0===0)break;if(b0===0xE5){lfn=[];continue}
      const attr=u[o+11];
      if(attr===0x0F){const pos=[1,3,5,7,9,14,16,18,20,22,24,28,30];let s="";for(const p of pos){const ch=dv.getUint16(o+p,true);if(ch===0||ch===0xFFFF)break;s+=String.fromCharCode(ch)}
        const seq=b0&0x1F;lfn[seq-1]=s;continue}
      if(attr&0x18){lfn=[];continue} // volume label or directory
      let name=lfn.length?lfn.join(""):(()=>{const b=String.fromCharCode(...u.slice(o,o+8)).trim(),x=String.fromCharCode(...u.slice(o+8,o+11)).trim();return (x?b+"."+x:b).toLowerCase()})();lfn=[];
      const size=dv.getUint32(o+28,true);let cl=dv.getUint16(o+26,true);const data=new Uint8Array(size);let off=0,guard=0;
      while(off<size&&cl>=2&&cl<0xFFF8&&guard++<70000){const n=Math.min(clsz,size-off);data.set(u.subarray((dataStart+(cl-2)*SPC)*SEC,(dataStart+(cl-2)*SPC)*SEC+n),off);off+=n;cl=dv.getUint16(fatOff+cl*2,true)}
      const t=dv.getUint16(o+22,true),d=dv.getUint16(o+24,true);
      out.push({name,data,mtime:new Date(1980+(d>>9),((d>>5)&15)-1,d&31,t>>11,(t>>5)&63,(t&31)*2).getTime()})}
    return out}
};

/* ================= Linux: permanent drive + shared folder ================= */
Object.assign(LX,{
  hddBuf:null,shBuf:null,
  async getHdd(){
    const saved=await DB.get("linux-hdd");if(saved)return await saved.arrayBuffer();
    await loadJS("hdd.js");
    const bin=Uint8Array.from(atob(window.NIMBUS_HDD),c=>c.charCodeAt(0));
    const ds=new Blob([bin]).stream().pipeThrough(new DecompressionStream("gzip"));
    return await new Response(ds).arrayBuffer()},
  async buildShared(){
    const kids=(await DB.fs.children("linuxshared")).filter(k=>k.type==="file");
    const files=[];for(const k of kids)files.push({name:k.name,data:new Uint8Array(await k.blob.arrayBuffer()),mtime:k.mtime});
    const r=FAT.build(files);if(r.skipped.length)UI.toast("Some files not shared",r.skipped.slice(0,3).join(", ")+(r.skipped.length>3?"…":"")+" (shared drive is 64 MB)","linux");
    return r.buffer},
  async syncShared(){
    if(!LX.shBuf)return 0;const files=FAT.read(LX.shBuf);if(!files)return 0;
    const kids=(await DB.fs.children("linuxshared")).filter(k=>k.type==="file");let changes=0;
    const byName=new Map(kids.map(k=>[k.name,k]));
    for(const f of files){const ex=byName.get(f.name);
      if(ex){byName.delete(f.name);const cur=new Uint8Array(await ex.blob.arrayBuffer());let same=cur.length===f.data.length;if(same){for(let i=0;i<cur.length;i+=1){if(cur[i]!==f.data[i]){same=false;break}}}
        if(!same){ex.blob=new Blob([f.data],{type:guessMime(f.name)});ex.size=f.data.length;ex.mtime=Date.now();await DB.fs.put(ex);changes++}}
      else{await DB.fs.put({id:uid(),parent:"linuxshared",name:f.name,type:"file",mime:guessMime(f.name),size:f.data.length,mtime:f.mtime||Date.now(),blob:new Blob([f.data],{type:guessMime(f.name)})});changes++}}
    for(const k of byName.values()){await DB.fs.del(k.id);changes++}
    if(changes)FS.changed();return changes},
  async persist(){
    if(Date.now()-(LX._persistedAt||0)<4000)return;LX._persistedAt=Date.now();
    if(LX.hddBuf){try{await DB.set("linux-hdd",new Blob([LX.hddBuf]))}catch(e){UI.toast("Couldn't save Linux drive",e.message,"linux")}}
    try{const n=await LX.syncShared();if(n)UI.toast("Shared folder updated",`${n} change${n>1?"s":""} from Linux`,"linux")}catch(e){console.warn(e)}}
});
LX.start=async function(screen,{restore=false}={}){
  const iso=await LX.getIso();if(!iso)throw new Error("No Linux disk loaded yet.");
  await LX.loadScript();
  LX.hddBuf=await LX.getHdd();LX.shBuf=await LX.buildShared();
  const opts={wasm_path:"v86.wasm",memory_size:S.linuxMem*1048576,vga_memory_size:8*1048576,screen_container:screen,
    bios:LX.bios("seabios"),vga_bios:LX.bios("vgabios"),cdrom:{buffer:await iso.arrayBuffer()},hda:{buffer:LX.hddBuf},hdb:{buffer:LX.shBuf},
    boot_order:0x213,autostart:true,disable_mouse:true};
  if(S.relay&&!SANDBOXED)opts.net_device={type:"ne2k",relay_url:S.relay};
  if(restore){const st=await DB.get("linux-state");if(st)opts.initial_state={buffer:await st.arrayBuffer()}}
  LX.emu=new V86(opts);LX.running=true;Widgets.render();return LX.emu};
const _lxSave=LX.saveState;
LX.saveState=async function(){const n=await _lxSave();await LX.persist();return n};
const _lxStop=LX.stop;
LX.stop=async function(){if(LX.emu){try{LX.emu.stop()}catch(e){}await LX.persist()}await _lxStop();LX.hddBuf=null;LX.shBuf=null};

/* ================= Documents (.docx) ================= */
APPS.docs={name:"Documents",icon:"docs",w:900,h:640,
  create(w,opts){
    let entry=null,dirty=false;
    w.body.innerHTML=`<div class="main">
      <div class="toolbar"><button class="btn" data-a="new">${SVG.plus}New</button><button class="btn" data-a="open">Open…</button><button class="btn" data-a="save">${SVG.save}Save</button><button class="btn" data-a="saveas">Save As…</button>
        <button class="btn" data-a="export">${SVG.share}Export</button><span class="muted" style="margin-left:auto;font-size:12px" data-fmt>Word document (.docx)</span></div>
      <div class="rt">
        <select data-block><option value="P">Normal</option><option value="H1">Heading 1</option><option value="H2">Heading 2</option><option value="H3">Heading 3</option><option value="BLOCKQUOTE">Quote</option></select>
        <select data-font><option value="">Font</option>${["Calibri","Arial","Helvetica","Georgia","Times New Roman","Courier New","Verdana"].map(f=>`<option>${f}</option>`).join("")}</select>
        <select data-size><option value="">Size</option>${[["1","10"],["2","13"],["3","16"],["4","18"],["5","24"],["6","32"],["7","48"]].map(([v,l])=>`<option value="${v}">${l}</option>`).join("")}</select>
        <span class="sep2"></span>
        <button class="btn" data-c="bold"><b>B</b></button><button class="btn" data-c="italic"><i>I</i></button><button class="btn" data-c="underline"><u>U</u></button><button class="btn" data-c="strikeThrough"><s>S</s></button>
        <input type="color" data-color title="Text colour" value="#1d1d1f"><input type="color" data-hl title="Highlight" value="#ffe066">
        <span class="sep2"></span>
        <button class="btn" data-c="justifyLeft">⟸</button><button class="btn" data-c="justifyCenter">≡</button><button class="btn" data-c="justifyRight">⟹</button>
        <button class="btn" data-c="insertUnorderedList">• List</button><button class="btn" data-c="insertOrderedList">1. List</button><button class="btn" data-c="outdent">⇤</button><button class="btn" data-c="indent">⇥</button>
        <span class="sep2"></span>
        <button class="btn" data-x="table">Table</button><button class="btn" data-x="image">Image</button><button class="btn" data-x="link">Link</button><button class="btn" data-c="insertHorizontalRule">—</button>
        <button class="btn" data-c="undo">↶</button><button class="btn" data-c="redo">↷</button></div>
      <div class="doc-wrap"><div class="doc-page" contenteditable="true" spellcheck="true" data-page><h1>Untitled document</h1><p>Start writing here…</p></div></div>
      <div class="statusbar"><span data-wc></span><span data-st></span></div></div>`;
    const page=$("[data-page]",w.body),st=$("[data-st]",w.body);
    const title=()=>w.setTitle((entry?entry.name:"Untitled.docx")+(dirty?" — Edited":""));
    const wc=()=>{const t=page.innerText.trim();$("[data-wc]",w.body).textContent=`${t?t.split(/\s+/).length:0} words · ${t.length} characters`};
    const mark=()=>{if(!dirty){dirty=true;title()}wc()};
    page.addEventListener("input",mark);
    let savedRange=null;page.addEventListener("blur",()=>{const s=getSelection();if(s.rangeCount)savedRange=s.getRangeAt(0)});
    const restore=()=>{page.focus();if(savedRange){const s=getSelection();s.removeAllRanges();s.addRange(savedRange)}};
    const cmd=(c,v=null)=>{restore();try{document.execCommand("styleWithCSS",false,c==="hiliteColor"||c==="foreColor")}catch(e){}document.execCommand(c,false,v);mark()};
    $$("[data-c]",w.body).forEach(b=>{b.addEventListener("pointerdown",e=>e.preventDefault());b.onclick=()=>cmd(b.dataset.c)});
    $("[data-block]",w.body).onchange=e=>{cmd("formatBlock","<"+e.target.value+">");e.target.value="P"};
    $("[data-font]",w.body).onchange=e=>{if(e.target.value)cmd("fontName",e.target.value);e.target.value=""};
    $("[data-size]",w.body).onchange=e=>{if(e.target.value)cmd("fontSize",e.target.value);e.target.value=""};
    $("[data-color]",w.body).oninput=e=>cmd("foreColor",e.target.value);
    $("[data-hl]",w.body).oninput=e=>cmd("hiliteColor",e.target.value);
    $("[data-x=table]",w.body).onclick=async()=>{const r=await UI.dialog({title:"Insert Table",fields:[{value:"3",ph:"Rows",type:"number"},{value:"3",ph:"Columns",type:"number"}],ok:"Insert"});if(!r)return;
      const R=Math.min(50,+r[0]||3),C=Math.min(12,+r[1]||3);cmd("insertHTML",`<table>${[...Array(R)].map((_,i)=>`<tr>${[...Array(C)].map(()=>i===0?"<th>&nbsp;</th>":"<td>&nbsp;</td>").join("")}</tr>`).join("")}</table><p><br></p>`)};
    $("[data-x=image]",w.body).onclick=()=>pickFiles(f=>{if(!f[0])return;const rd=new FileReader();rd.onload=()=>cmd("insertImage",rd.result);rd.readAsDataURL(f[0])},"image/*");
    $("[data-x=link]",w.body).onclick=async()=>{const u=await UI.prompt("Link address","https://");if(u)cmd("createLink",u)};
    const libs=()=>Promise.all([loadJS("lib/docx.iife.js").then(()=>loadJS("lib/docx-math.iife.js")).then(()=>loadJS("lib/docx-html.iife.js"))]);
    const toDocx=async()=>{await libs();const d=new docx.Document({creator:"Nimbus",styles:{default:{document:{run:{font:"Calibri",size:24}}}},sections:[{children:[...docxHtml.htmlToContent(page.innerHTML)]}]});return await docx.Packer.toBlob(d)};
    const load=async id=>{entry=await DB.fs.get(id);if(!entry)return;st.textContent="Opening…";
      try{if(isDocx(entry)){await loadJS("lib/mammoth.browser.min.js");const r=await mammoth.convertToHtml({arrayBuffer:await entry.blob.arrayBuffer()});page.innerHTML=r.value||"<p></p>"}
        else if(/\.html?$/i.test(entry.name))page.innerHTML=await entry.blob.text();
        else page.innerHTML=(await entry.blob.text()).split(/\n/).map(l=>`<p>${esc(l)||"<br>"}</p>`).join("");
        st.textContent="";}catch(e){st.textContent="Couldn't open: "+e.message}
      dirty=false;title();wc()};
    const save=async()=>{if(!entry||!isDocx(entry))return saveAs();st.textContent="Saving…";try{const b=await toDocx();entry.blob=b;entry.size=b.size;entry.mtime=Date.now();entry.mime=b.type;await DB.fs.put(entry);FS.changed();dirty=false;title();st.textContent="Saved";UI.toast("Saved",entry.name,"docs")}catch(e){st.textContent="Save failed: "+e.message}};
    const saveAs=async()=>{try{const b=await toDocx();const firstLine=(page.innerText.split("\n").find(l=>l.trim())||"Untitled").slice(0,40).replace(/[\\/:*?"<>|]/g,"");const e=await saveBlobAs(firstLine+".docx",b);if(e){entry=e;dirty=false;title();UI.toast("Saved",`Documents › ${e.name}`,"docs")}}catch(e){st.textContent="Save failed: "+e.message}};
    $("[data-a=new]",w.body).onclick=()=>WM.open("docs");
    $("[data-a=save]",w.body).onclick=save;$("[data-a=saveas]",w.body).onclick=saveAs;
    $("[data-a=open]",w.body).onclick=async e=>{const r=e.target.getBoundingClientRect();const files=(await DB.fs.all()).filter(x=>x.type==="file"&&(isDocx(x)||/\.(txt|md|html?)$/i.test(x.name)));
      UI.menu([{label:"Import from iPad…",action:()=>pickFiles(async f=>{if(!f[0])return;const id=await FS.addBlob("documents",f[0].name,f[0]);load(id)})},"-",...(files.length?files.slice(0,20).map(f=>({label:f.name,action:()=>load(f.id)})):[{label:"No documents yet",disabled:true}])],r.left,r.bottom+4)};
    $("[data-a=export]",w.body).onclick=e=>{const r=e.target.getBoundingClientRect();const base=(entry?entry.name.replace(/\.[^.]+$/,""):"Untitled");
      UI.menu([{label:"Word document (.docx)",action:async()=>shareFile({blob:await toDocx(),name:base+".docx",mime:"application/vnd.openxmlformats-officedocument.wordprocessingml.document"})},
        {label:"Web page (.html)",action:()=>shareFile({blob:new Blob([`<!DOCTYPE html><meta charset="utf-8"><title>${esc(base)}</title><body style="font-family:Calibri,Arial,sans-serif;max-width:760px;margin:40px auto">${page.innerHTML}</body>`],{type:"text/html"}),name:base+".html",mime:"text/html"})},
        {label:"Plain text (.txt)",action:()=>shareFile({blob:new Blob([page.innerText],{type:"text/plain"}),name:base+".txt",mime:"text/plain"})},
        {label:"Open in Collabora / other app…",action:async()=>shareFile({blob:await toDocx(),name:base+".docx",mime:"application/vnd.openxmlformats-officedocument.wordprocessingml.document"})}],r.left,r.bottom+4)};
    page.addEventListener("keydown",e=>{if((e.metaKey||e.ctrlKey)&&e.key==="s"){e.preventDefault();save()}});
    if(opts.id)load(opts.id);else{title();wc()}
    return {async beforeClose(){if(!dirty)return true;const r=await UI.dialog({title:"Save changes?",text:"Your changes will be lost if you don't save them.",ok:"Save",cancel:"Don't Save"});if(r)await save();return true}}}
};

/* ================= Sheets (.xlsx) ================= */
const colName=n=>{let s="";n++;while(n>0){const m=(n-1)%26;s=String.fromCharCode(65+m)+s;n=Math.floor((n-1)/26)}return s};
const colIdx=s=>{let n=0;for(const c of s.toUpperCase())n=n*26+(c.charCodeAt(0)-64);return n-1};
const parseRef=r=>{const m=/^\$?([A-Za-z]{1,3})\$?(\d+)$/.exec(r);return m?{c:colIdx(m[1]),r:+m[2]-1}:null};
const refName=(c,r)=>colName(c)+(r+1);
const Formula={
  tokenize(s){const t=[];let i=0;while(i<s.length){const ch=s[i];
      if(/\s/.test(ch)){i++;continue}
      if(ch==='"'){let j=i+1,v="";while(j<s.length&&!(s[j]==='"'&&s[j+1]!=='"')){if(s[j]==='"'){v+='"';j+=2}else v+=s[j++]}t.push({t:"str",v});i=j+1;continue}
      const num=/^\d+(\.\d+)?([eE][+-]?\d+)?|^\.\d+/.exec(s.slice(i));if(num){t.push({t:"num",v:parseFloat(num[0])});i+=num[0].length;continue}
      const rng=/^\$?[A-Za-z]{1,3}\$?\d+:\$?[A-Za-z]{1,3}\$?\d+/.exec(s.slice(i));if(rng){t.push({t:"range",v:rng[0]});i+=rng[0].length;continue}
      const id=/^[A-Za-z_][A-Za-z0-9_.]*/.exec(s.slice(i));if(id){const w=id[0];i+=w.length;
        if(s[i]==="(")t.push({t:"fn",v:w.toUpperCase()});else if(parseRef(w))t.push({t:"ref",v:w});else if(/^(TRUE|FALSE)$/i.test(w))t.push({t:"bool",v:w.toUpperCase()==="TRUE"});else t.push({t:"name",v:w});continue}
      const op=/^(<=|>=|<>|[-+*/^&=<>(),%:;])/.exec(s.slice(i));if(op){t.push({t:"op",v:op[0]===";"?",":op[0]});i+=op[0].length;continue}
      throw new Error("#ERROR!")}return t},
  parse(src){const t=Formula.tokenize(src);let p=0;const peek=()=>t[p],eat=v=>{if(t[p]&&t[p].v===v){p++;return true}return false};
    const cmp=()=>{let l=cat();while(peek()&&["=","<>","<",">","<=",">="].includes(peek().v)&&peek().t==="op"){const o=t[p++].v;l={k:"bin",o,l,r:cat()}}return l};
    const cat=()=>{let l=add();while(peek()&&peek().v==="&"){p++;l={k:"bin",o:"&",l,r:add()}}return l};
    const add=()=>{let l=mul();while(peek()&&peek().t==="op"&&(peek().v==="+"||peek().v==="-")){const o=t[p++].v;l={k:"bin",o,l,r:mul()}}return l};
    const mul=()=>{let l=pow();while(peek()&&peek().t==="op"&&(peek().v==="*"||peek().v==="/")){const o=t[p++].v;l={k:"bin",o,l,r:pow()}}return l};
    const pow=()=>{let l=un();while(peek()&&peek().v==="^"){p++;l={k:"bin",o:"^",l,r:un()}}return l};
    const un=()=>{if(peek()&&peek().t==="op"&&peek().v==="-"){p++;return {k:"neg",e:un()}}if(peek()&&peek().t==="op"&&peek().v==="+"){p++;return un()}let e=prim();if(peek()&&peek().v==="%"){p++;e={k:"bin",o:"/",l:e,r:{k:"num",v:100}}}return e};
    const prim=()=>{const k=t[p++];if(!k)throw new Error("#ERROR!");
      if(k.t==="num")return {k:"num",v:k.v};if(k.t==="str")return {k:"str",v:k.v};if(k.t==="bool")return {k:"bool",v:k.v};
      if(k.t==="ref")return {k:"ref",v:k.v};if(k.t==="range")return {k:"range",v:k.v};
      if(k.t==="fn"){p++;const args=[];if(!eat(")")){do{args.push(cmp())}while(eat(","));if(!eat(")"))throw new Error("#ERROR!")}return {k:"fn",n:k.v,args}}
      if(k.v==="("){const e=cmp();if(!eat(")"))throw new Error("#ERROR!");return e}
      if(k.t==="name")throw new Error("#NAME?");throw new Error("#ERROR!")};
    const e=cmp();if(p<t.length)throw new Error("#ERROR!");return e}
};
class SheetModel{
  constructor(){this.sheets=[{name:"Sheet1",cells:{},fmt:{}}];this.cur=0}
  get s(){return this.sheets[this.cur]}
  raw(ref,sh=this.s){return sh.cells[ref]??""}
  set(ref,v){if(v===""||v==null)delete this.s.cells[ref];else this.s.cells[ref]=String(v)}
  recalc(){this.cache={};this.stack=new Set()}
  val(ref,sh=this.s){const key=this.sheets.indexOf(sh)+"!"+ref;if(this.cache&&key in this.cache)return this.cache[key];
    if(this.stack.has(key))return {err:"#CYCLE!"};this.stack.add(key);
    let raw=this.raw(ref,sh),v;
    if(typeof raw==="string"&&raw.startsWith("=")){try{v=this.ev(Formula.parse(raw.slice(1)),sh)}catch(e){v={err:e.message.startsWith("#")?e.message:"#ERROR!"}}if(Array.isArray(v))v=v[0]}
    else if(raw!==""&&!isNaN(raw)&&/^\s*-?[\d.]+(e[+-]?\d+)?\s*$/i.test(raw))v=parseFloat(raw);
    else if(/^(true|false)$/i.test(raw))v=/true/i.test(raw);
    else v=raw;
    this.stack.delete(key);(this.cache=this.cache||{})[key]=v;return v}
  rng(r,sh){const [a,b]=r.split(":").map(parseRef);const out=[];for(let y=Math.min(a.r,b.r);y<=Math.max(a.r,b.r);y++)for(let x=Math.min(a.c,b.c);x<=Math.max(a.c,b.c);x++)out.push(this.val(refName(x,y),sh));return out}
  ev(n,sh){const E=x=>this.ev(x,sh);
    const num=v=>{if(v&&v.err)throw new Error(v.err);if(typeof v==="boolean")return v?1:0;if(v===""||v==null)return 0;const f=+v;if(isNaN(f))throw new Error("#VALUE!");return f};
    const flat=args=>args.flatMap(a=>a.k==="range"?this.rng(a.v,sh):[E(a)]);
    const nums=args=>flat(args).filter(v=>typeof v==="number");
    const crit=(c)=>{const m=/^(<=|>=|<>|<|>|=)?(.*)$/.exec(String(c));const op=m[1]||"=",rv=m[2],rn=parseFloat(rv),isN=rv!==""&&!isNaN(rn);
      return v=>{const a=isN?(typeof v==="number"?v:parseFloat(v)):String(v).toLowerCase(),b=isN?rn:rv.toLowerCase();
        return op==="="?a==b:op==="<>"?a!=b:op==="<"?a<b:op===">"?a>b:op==="<="?a<=b:a>=b}};
    switch(n.k){
      case "num":case "str":case "bool":return n.v;
      case "ref":{const v=this.val(n.v.replace(/\$/g,"").toUpperCase(),sh);if(v&&v.err)throw new Error(v.err);return v}
      case "range":return this.rng(n.v.replace(/\$/g,"").toUpperCase(),sh);
      case "neg":return -num(E(n.e));
      case "bin":{const l=E(n.l),r=E(n.r);if(l&&l.err)throw new Error(l.err);if(r&&r.err)throw new Error(r.err);
        switch(n.o){case "+":return num(l)+num(r);case "-":return num(l)-num(r);case "*":return num(l)*num(r);case "/":{if(num(r)===0)throw new Error("#DIV/0!");return num(l)/num(r)}
          case "^":return Math.pow(num(l),num(r));case "&":return String(l??"")+String(r??"");
          case "=":return l==r;case "<>":return l!=r;case "<":return l<r;case ">":return l>r;case "<=":return l<=r;case ">=":return l>=r}}
      case "fn":{const a=n.args,F=n.n;
        switch(F){
          case "SUM":return nums(a).reduce((x,y)=>x+y,0);
          case "AVERAGE":{const v=nums(a);if(!v.length)throw new Error("#DIV/0!");return v.reduce((x,y)=>x+y,0)/v.length}
          case "MIN":{const v=nums(a);return v.length?Math.min(...v):0}case "MAX":{const v=nums(a);return v.length?Math.max(...v):0}
          case "COUNT":return nums(a).length;case "COUNTA":return flat(a).filter(v=>v!==""&&v!=null).length;
          case "PRODUCT":return nums(a).reduce((x,y)=>x*y,1);
          case "MEDIAN":{const v=nums(a).sort((x,y)=>x-y);if(!v.length)return 0;const m=v.length>>1;return v.length%2?v[m]:(v[m-1]+v[m])/2}
          case "IF":return E(a[0])?(a[1]?E(a[1]):true):(a[2]?E(a[2]):false);
          case "IFERROR":try{const v=E(a[0]);if(v&&v.err)return E(a[1]);return v}catch(e){return E(a[1])}
          case "AND":return flat(a).every(Boolean);case "OR":return flat(a).some(Boolean);case "NOT":return !E(a[0]);
          case "ROUND":{const d=a[1]?num(E(a[1])):0,f=Math.pow(10,d);return Math.round(num(E(a[0]))*f)/f}
          case "ROUNDUP":{const d=a[1]?num(E(a[1])):0,f=Math.pow(10,d);return Math.ceil(num(E(a[0]))*f)/f}
          case "ROUNDDOWN":{const d=a[1]?num(E(a[1])):0,f=Math.pow(10,d);return Math.floor(num(E(a[0]))*f)/f}
          case "INT":return Math.floor(num(E(a[0])));case "ABS":return Math.abs(num(E(a[0])));case "SQRT":return Math.sqrt(num(E(a[0])));
          case "POWER":return Math.pow(num(E(a[0])),num(E(a[1])));case "MOD":return num(E(a[0]))%num(E(a[1]));case "PI":return Math.PI;
          case "CONCAT":case "CONCATENATE":return flat(a).map(v=>v??"").join("");
          case "LEN":return String(E(a[0])??"").length;case "UPPER":return String(E(a[0])).toUpperCase();case "LOWER":return String(E(a[0])).toLowerCase();
          case "TRIM":return String(E(a[0])).trim().replace(/\s+/g," ");
          case "LEFT":return String(E(a[0])).slice(0,a[1]?num(E(a[1])):1);case "RIGHT":{const s=String(E(a[0]));const k=a[1]?num(E(a[1])):1;return s.slice(Math.max(0,s.length-k))}
          case "MID":return String(E(a[0])).substr(num(E(a[1]))-1,num(E(a[2])));
          case "TODAY":{const d=new Date();return d.toLocaleDateString()}case "NOW":return new Date().toLocaleString();
          case "SUMIF":{const r=this.rng(a[0].v,sh),c=crit(E(a[1])),s=a[2]?this.rng(a[2].v,sh):r;return r.reduce((t,v,i)=>t+(c(v)&&typeof s[i]==="number"?s[i]:0),0)}
          case "COUNTIF":{const r=this.rng(a[0].v,sh),c=crit(E(a[1]));return r.filter(c).length}
          case "AVERAGEIF":{const r=this.rng(a[0].v,sh),c=crit(E(a[1])),s=a[2]?this.rng(a[2].v,sh):r;const v=r.map((x,i)=>c(x)?s[i]:null).filter(x=>typeof x==="number");if(!v.length)throw new Error("#DIV/0!");return v.reduce((x,y)=>x+y,0)/v.length}
          case "VLOOKUP":{const key=E(a[0]),[s0,s1]=a[1].v.replace(/\$/g,"").split(":").map(parseRef),col=num(E(a[2]))-1,exact=a[3]?!E(a[3]):false;
            const r0=Math.min(s0.r,s1.r),r1=Math.max(s0.r,s1.r),c0=Math.min(s0.c,s1.c);let hit=-1;
            for(let y=r0;y<=r1;y++){const v=this.val(refName(c0,y),sh);if(v==key||String(v).toLowerCase()===String(key).toLowerCase()){hit=y;break}if(!exact&&typeof v==="number"&&typeof key==="number"&&v<=key)hit=y}
            if(hit<0)throw new Error("#N/A");return this.val(refName(c0+col,hit),sh)}
          default:throw new Error("#NAME?")}}
    }}
}
APPS.sheets={name:"Sheets",icon:"sheets",w:960,h:620,
  create(w,opts){
    const M=new SheetModel();let entry=null,dirty=false,sel={c:0,r:0},anchor=null,ROWS=100,COLS=26,editing=null;
    w.body.innerHTML=`<div class="main">
      <div class="toolbar"><button class="btn" data-a="new">${SVG.plus}New</button><button class="btn" data-a="open">Open…</button><button class="btn" data-a="save">${SVG.save}Save</button><button class="btn" data-a="saveas">Save As…</button><button class="btn" data-a="export">${SVG.share}Export</button>
        <span class="sep2" style="width:1px;height:22px;background:var(--hair)"></span>
        <button class="btn" data-f="bold"><b>B</b></button><button class="btn" data-f="left">⟸</button><button class="btn" data-f="center">≡</button><button class="btn" data-f="right">⟹</button>
        <select class="btn" data-num style="padding:5px"><option value="">General</option><option value="0">0</option><option value="2">0.00</option><option value="pct">%</option><option value="cur">$</option></select>
        <button class="btn" data-a="sum" title="AutoSum">Σ</button><button class="btn" data-a="addrow">+ Row</button><button class="btn" data-a="clear">Clear</button></div>
      <div class="sh-bar"><div class="ref" data-ref>A1</div><span class="fx">fx</span><input class="field" data-fbar style="padding:5px 8px;font-family:var(--mono);font-size:12.5px" autocapitalize="off" autocorrect="off" spellcheck="false"></div>
      <div class="sh-grid" data-grid tabindex="0"></div>
      <div class="sh-tabs" data-tabs></div><div class="statusbar"><span data-stat></span><span data-st style="margin-left:auto"></span></div></div>`;
    const grid=$("[data-grid]",w.body),fbar=$("[data-fbar]",w.body);
    const title=()=>w.setTitle((entry?entry.name:"Untitled.xlsx")+(dirty?" — Edited":""));
    const mark=()=>{if(!dirty){dirty=true;title()}};
    const fmtVal=(v,ref)=>{if(v&&v.err)return v.err;const f=M.s.fmt[ref]||{};if(typeof v==="number"){
        if(f.num==="pct")return (v*100).toFixed(f.dp??0)+"%";if(f.num==="cur")return v.toLocaleString(undefined,{style:"currency",currency:"USD"});
        if(f.num!=null&&f.num!=="")return v.toFixed(+f.num);return Number.isInteger(v)?String(v):String(+v.toPrecision(10))}
      if(typeof v==="boolean")return v?"TRUE":"FALSE";return v??""};
    const render=()=>{M.recalc();const maxR=Math.max(ROWS,...Object.keys(M.s.cells).map(k=>parseRef(k)?.r+2||0));ROWS=maxR;
      let h=`<table><colgroup><col style="width:46px">${[...Array(COLS)].map(()=>`<col style="width:104px">`).join("")}</colgroup><tr><th class="rh"></th>${[...Array(COLS)].map((_,c)=>`<th data-col="${c}">${colName(c)}</th>`).join("")}</tr>`;
      for(let r=0;r<ROWS;r++){h+=`<tr><td class="rh" data-row="${r}">${r+1}</td>`;for(let c=0;c<COLS;c++){const ref=refName(c,r),raw=M.raw(ref);
          if(raw===""){h+=`<td data-c="${c}" data-r="${r}"></td>`;continue}
          const v=M.val(ref),f=M.s.fmt[ref]||{};const cls=[typeof v==="number"?"num":"",v&&v.err?"err":""].join(" ");
          h+=`<td data-c="${c}" data-r="${r}" class="${cls}" style="${f.bold?"font-weight:700;":""}${f.align?`text-align:${f.align};`:""}">${esc(fmtVal(v,ref))}</td>`}h+="</tr>"}
      grid.innerHTML=h+"</table>";paintSel();stats()};
    const cellEl=(c,r)=>grid.querySelector(`td[data-c="${c}"][data-r="${r}"]`);
    const selRange=()=>{const a=anchor||sel;return {c0:Math.min(a.c,sel.c),c1:Math.max(a.c,sel.c),r0:Math.min(a.r,sel.r),r1:Math.max(a.r,sel.r)}};
    const paintSel=()=>{$$("td.sel,td.insel,th.hl",grid).forEach(x=>x.classList.remove("sel","insel","hl"));const R=selRange();
      for(let r=R.r0;r<=R.r1;r++)for(let c=R.c0;c<=R.c1;c++){const e=cellEl(c,r);e&&e.classList.add("insel")}
      const e=cellEl(sel.c,sel.r);if(e){e.classList.remove("insel");e.classList.add("sel")}
      $(`th[data-col="${sel.c}"]`,grid)?.classList.add("hl");$(`td[data-row="${sel.r}"]`,grid)?.classList.add("hl");
      $("[data-ref]",w.body).textContent=refName(sel.c,sel.r);if(document.activeElement!==fbar)fbar.value=M.raw(refName(sel.c,sel.r))};
    const stats=()=>{const R=selRange();const v=[];for(let r=R.r0;r<=R.r1;r++)for(let c=R.c0;c<=R.c1;c++){const x=M.val(refName(c,r));if(typeof x==="number")v.push(x)}
      $("[data-stat]",w.body).textContent=v.length>1?`Sum: ${+v.reduce((a,b)=>a+b,0).toFixed(6)}   Average: ${+(v.reduce((a,b)=>a+b,0)/v.length).toFixed(6)}   Count: ${v.length}`:""};
    const select=(c,r,extend=false)=>{if(extend){anchor=anchor||{...sel}}else anchor=null;sel={c:Math.max(0,Math.min(COLS-1,c)),r:Math.max(0,r)};if(sel.r>=ROWS-1){ROWS+=20;render()}else{paintSel();stats()}
      const e=cellEl(sel.c,sel.r);e&&e.scrollIntoView({block:"nearest",inline:"nearest"})};
    const commit=(ref,v)=>{M.set(ref,v);mark();render()};
    const startEdit=(initial)=>{endEdit(false);const e=cellEl(sel.c,sel.r);if(!e)return;const gr=grid.getBoundingClientRect(),er=e.getBoundingClientRect();
      const inp=html(`<input class="sh-edit" autocapitalize="off" autocorrect="off" spellcheck="false">`);inp.style.left=(er.left-gr.left+grid.scrollLeft)+"px";inp.style.top=(er.top-gr.top+grid.scrollTop)+"px";
      inp.style.width=Math.max(er.width,140)+"px";inp.style.height=er.height+"px";inp.value=initial!=null?initial:M.raw(refName(sel.c,sel.r));grid.appendChild(inp);inp.focus();
      editing={inp,ref:refName(sel.c,sel.r)};
      inp.oninput=()=>fbar.value=inp.value;
      inp.onkeydown=ev=>{if(ev.key==="Enter"){ev.preventDefault();endEdit(true);select(sel.c,sel.r+(ev.shiftKey?-1:1));grid.focus()}
        else if(ev.key==="Tab"){ev.preventDefault();endEdit(true);select(sel.c+(ev.shiftKey?-1:1),sel.r);grid.focus()}
        else if(ev.key==="Escape"){endEdit(false);grid.focus()}};
      inp.onblur=()=>setTimeout(()=>{if(editing&&editing.inp===inp)endEdit(true)},120)};
    const endEdit=save=>{if(!editing)return;const {inp,ref}=editing;editing=null;const v=inp.value;inp.remove();if(save&&v!==M.raw(ref))commit(ref,v)};
    grid.addEventListener("pointerdown",e=>{const td=e.target.closest("td[data-c]");if(!td)return;const c=+td.dataset.c,r=+td.dataset.r;
      if(editing&&editing.inp.value.startsWith("=")&&!(c===sel.c&&r===sel.r)){e.preventDefault();const i=editing.inp;i.value+=refName(c,r);fbar.value=i.value;setTimeout(()=>i.focus(),0);return}
      endEdit(true);select(c,r,e.shiftKey);grid.focus()});
    grid.addEventListener("dblclick",e=>{if(e.target.closest("td[data-c]"))startEdit()});
    let lastTap=0;grid.addEventListener("pointerup",e=>{if(e.pointerType!=="touch")return;const td=e.target.closest("td[data-c]");if(!td)return;const now=Date.now();if(now-lastTap<350)startEdit();lastTap=now});
    grid.addEventListener("keydown",e=>{if(editing)return;const k=e.key;
      if(k==="ArrowDown"||k==="Enter"){e.preventDefault();select(sel.c,sel.r+1,e.shiftKey&&k!=="Enter")}else if(k==="ArrowUp"){e.preventDefault();select(sel.c,sel.r-1,e.shiftKey)}
      else if(k==="ArrowLeft"){e.preventDefault();select(sel.c-1,sel.r,e.shiftKey)}else if(k==="ArrowRight"||k==="Tab"){e.preventDefault();select(sel.c+(k==="Tab"&&e.shiftKey?-1:1),sel.r,e.shiftKey&&k!=="Tab")}
      else if(k==="Backspace"||k==="Delete"){e.preventDefault();const R=selRange();for(let r=R.r0;r<=R.r1;r++)for(let c=R.c0;c<=R.c1;c++)M.set(refName(c,r),"");mark();render()}
      else if(k==="F2"){e.preventDefault();startEdit()}
      else if((e.metaKey||e.ctrlKey)&&k==="c"){const R=selRange();const rows=[];for(let r=R.r0;r<=R.r1;r++){const row=[];for(let c=R.c0;c<=R.c1;c++)row.push(fmtVal(M.val(refName(c,r)),refName(c,r)));rows.push(row.join("\t"))}
        try{navigator.clipboard.writeText(rows.join("\n"))}catch(_){} }
      else if((e.metaKey||e.ctrlKey)&&k==="s"){e.preventDefault();save()}
      else if(k.length===1&&!e.metaKey&&!e.ctrlKey){e.preventDefault();startEdit(k)}});
    grid.addEventListener("paste",e=>{const t=e.clipboardData?.getData("text");if(!t||editing)return;e.preventDefault();t.replace(/\r/g,"").split("\n").forEach((line,dy)=>{if(line==="")return;line.split("\t").forEach((v,dx)=>M.set(refName(sel.c+dx,sel.r+dy),v))});mark();render()});
    fbar.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();commit(refName(sel.c,sel.r),fbar.value);select(sel.c,sel.r+1);grid.focus()}if(e.key==="Escape"){fbar.value=M.raw(refName(sel.c,sel.r));grid.focus()}});
    const fmtSel=fn=>{const R=selRange();for(let r=R.r0;r<=R.r1;r++)for(let c=R.c0;c<=R.c1;c++){const ref=refName(c,r);M.s.fmt[ref]=M.s.fmt[ref]||{};fn(M.s.fmt[ref])}mark();render()};
    $("[data-f=bold]",w.body).onclick=()=>{const b=!(M.s.fmt[refName(sel.c,sel.r)]||{}).bold;fmtSel(f=>f.bold=b)};
    ["left","center","right"].forEach(a=>$(`[data-f=${a}]`,w.body).onclick=()=>fmtSel(f=>f.align=a));
    $("[data-num]",w.body).onchange=e=>{const v=e.target.value;fmtSel(f=>{f.num=v});e.target.value=""};
    $("[data-a=sum]",w.body).onclick=()=>{let r=sel.r-1;while(r>=0&&typeof M.val(refName(sel.c,r))==="number")r--;
      const from=r+1;if(from<sel.r)commit(refName(sel.c,sel.r),`=SUM(${refName(sel.c,from)}:${refName(sel.c,sel.r-1)})`);else startEdit("=SUM(")};
    $("[data-a=addrow]",w.body).onclick=()=>{const cells={},fmt={};for(const [k,v] of Object.entries(M.s.cells)){const p=parseRef(k);cells[p.r>sel.r?refName(p.c,p.r+1):k]=v}
      for(const [k,v] of Object.entries(M.s.fmt)){const p=parseRef(k);fmt[p.r>sel.r?refName(p.c,p.r+1):k]=v}M.s.cells=cells;M.s.fmt=fmt;mark();render()};
    $("[data-a=clear]",w.body).onclick=()=>{const R=selRange();for(let r=R.r0;r<=R.r1;r++)for(let c=R.c0;c<=R.c1;c++){M.set(refName(c,r),"");delete M.s.fmt[refName(c,r)]}mark();render()};
    const drawTabs=()=>{const t=$("[data-tabs]",w.body);t.innerHTML=M.sheets.map((s,i)=>`<div class="tab ${i===M.cur?"act":""}" data-i="${i}">${esc(s.name)}</div>`).join("")+`<button class="btn icon" data-addsheet style="padding:3px 6px">${SVG.plus}</button>`;
      $$(".tab",t).forEach(el=>{el.onclick=()=>{endEdit(true);M.cur=+el.dataset.i;sel={c:0,r:0};anchor=null;render();drawTabs()};
        longPress(el,e=>UI.menu([{label:"Rename…",action:async()=>{const n=await UI.prompt("Sheet name",M.sheets[el.dataset.i].name);if(n){M.sheets[el.dataset.i].name=n;mark();drawTabs()}}},
          {label:"Delete",disabled:M.sheets.length<2,action:()=>{M.sheets.splice(+el.dataset.i,1);M.cur=0;mark();render();drawTabs()}}],e.clientX,e.clientY))});
      $("[data-addsheet]",t).onclick=()=>{M.sheets.push({name:"Sheet"+(M.sheets.length+1),cells:{},fmt:{}});M.cur=M.sheets.length-1;mark();render();drawTabs()}};
    /* file I/O */
    const toWorkbook=async()=>{await loadJS("lib/xlsx.full.min.js");const wb=XLSX.utils.book_new();
      for(const sh of M.sheets){const ws={};let maxC=0,maxR=0;const prev=M.cur;M.cur=M.sheets.indexOf(sh);M.recalc();
        for(const [ref,raw] of Object.entries(sh.cells)){const p=parseRef(ref);maxC=Math.max(maxC,p.c);maxR=Math.max(maxR,p.r);const v=M.val(ref,sh);
          const cell=raw.startsWith("=")?{f:raw.slice(1)}:{};if(typeof v==="number"){cell.t="n";cell.v=v}else if(typeof v==="boolean"){cell.t="b";cell.v=v}else if(v&&v.err){cell.t="e";cell.v=0;cell.w=v.err}else{cell.t="s";cell.v=String(v)}
          const f=sh.fmt[ref];if(f&&f.num==="pct")cell.z="0%";else if(f&&f.num==="cur")cell.z='"$"#,##0.00';else if(f&&f.num)cell.z=f.num==="0"?"0":"0.00";ws[ref]=cell}
        M.cur=prev;ws["!ref"]=`A1:${refName(maxC,maxR)}`;XLSX.utils.book_append_sheet(wb,ws,sh.name.slice(0,31))}
      return wb};
    const toXlsx=async()=>{const wb=await toWorkbook();const out=XLSX.write(wb,{bookType:"xlsx",type:"array"});return new Blob([out],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})};
    const toCsv=async()=>{const wb=await toWorkbook();return new Blob([XLSX.utils.sheet_to_csv(wb.Sheets[wb.SheetNames[M.cur]])],{type:"text/csv"})};
    const load=async id=>{entry=await DB.fs.get(id);if(!entry)return;$("[data-st]",w.body).textContent="Opening…";
      try{await loadJS("lib/xlsx.full.min.js");const wb=/\.csv$/i.test(entry.name)?XLSX.read(await entry.blob.text(),{type:"string"}):XLSX.read(await entry.blob.arrayBuffer(),{type:"array",cellFormula:true});
        M.sheets=wb.SheetNames.map(n=>{const ws=wb.Sheets[n],cells={};for(const k of Object.keys(ws)){if(k[0]==="!")continue;const c=ws[k];cells[k]=c.f?"="+c.f:c.v==null?"":String(c.v)}return {name:n,cells,fmt:{}}});
        if(!M.sheets.length)M.sheets=[{name:"Sheet1",cells:{},fmt:{}}];M.cur=0;$("[data-st]",w.body).textContent=""}catch(e){$("[data-st]",w.body).textContent="Couldn't open: "+e.message}
      dirty=false;title();render();drawTabs()};
    const save=async()=>{if(!entry||!/\.(xlsx|csv)$/i.test(entry.name))return saveAs();try{const b=/\.csv$/i.test(entry.name)?await toCsv():await toXlsx();entry.blob=b;entry.size=b.size;entry.mtime=Date.now();await DB.fs.put(entry);FS.changed();dirty=false;title();UI.toast("Saved",entry.name,"sheets")}catch(e){UI.toast("Save failed",e.message,"sheets")}};
    const saveAs=async()=>{try{const e=await saveBlobAs("Spreadsheet.xlsx",await toXlsx());if(e){entry=e;dirty=false;title();UI.toast("Saved",`Documents › ${e.name}`,"sheets")}}catch(err){UI.toast("Save failed",err.message,"sheets")}};
    $("[data-a=new]",w.body).onclick=()=>WM.open("sheets");$("[data-a=save]",w.body).onclick=save;$("[data-a=saveas]",w.body).onclick=saveAs;
    $("[data-a=open]",w.body).onclick=async e=>{const r=e.target.getBoundingClientRect();const files=(await DB.fs.all()).filter(x=>x.type==="file"&&isSheet(x));
      UI.menu([{label:"Import from iPad…",action:()=>pickFiles(async f=>{if(!f[0])return;const id=await FS.addBlob("documents",f[0].name,f[0]);load(id)})},"-",...(files.length?files.slice(0,20).map(f=>({label:f.name,action:()=>load(f.id)})):[{label:"No spreadsheets yet",disabled:true}])],r.left,r.bottom+4)};
    $("[data-a=export]",w.body).onclick=e=>{const r=e.target.getBoundingClientRect();const base=entry?entry.name.replace(/\.[^.]+$/,""):"Spreadsheet";
      UI.menu([{label:"Excel workbook (.xlsx)",action:async()=>shareFile({blob:await toXlsx(),name:base+".xlsx",mime:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})},
        {label:"CSV (this sheet)",action:async()=>shareFile({blob:await toCsv(),name:base+".csv",mime:"text/csv"})}],r.left,r.bottom+4)};
    if(opts.id)load(opts.id);else{
      Object.assign(M.s.cells,{A1:"Item",B1:"Qty",C1:"Price",D1:"Total",A2:"Coffee",B2:"2",C2:"3.5",D2:"=B2*C2",A3:"Bagel",B3:"3",C3:"2.25",D3:"=B3*C3",A4:"Juice",B4:"1",C4:"4",D4:"=B4*C4",C5:"Total",D5:"=SUM(D2:D4)"});
      ["A1","B1","C1","D1","C5","D5"].forEach(r=>M.s.fmt[r]={bold:true});["C2","C3","C4","D2","D3","D4","D5"].forEach(r=>M.s.fmt[r]={...(M.s.fmt[r]||{}),num:"cur"});
      title();render();drawTabs()}
    setTimeout(()=>grid.focus(),100);
    return {async beforeClose(){endEdit(true);if(!dirty)return true;const r=await UI.dialog({title:"Save changes?",text:"Your changes will be lost if you don't save them.",ok:"Save",cancel:"Don't Save"});if(r)await save();return true}}}
};

/* ================= Code (Monaco) ================= */
const CodeEnv={monaco:null,py:null,
  async monacoReady(){if(CodeEnv.monaco)return CodeEnv.monaco;
    await loadJS("lib/monaco/vs/loader.js");
    return CodeEnv.monaco=await new Promise((res,rej)=>{window.require.config({paths:{vs:"lib/monaco/vs"}});window.require(["vs/editor/editor.main"],()=>res(window.monaco),rej)})},
  async python(out){if(CodeEnv.py)return CodeEnv.py;out("Starting Python (first run takes a few seconds)…\n","s");
    await loadJS("lib/pyodide/pyodide.js");
    const base=new URL("lib/pyodide/",location.href).href;CodeEnv.py=await loadPyodide({indexURL:base,stdLibURL:base+"python_stdlib.wasm"});return CodeEnv.py}
};
const LANG={py:"python",js:"javascript",mjs:"javascript",ts:"typescript",html:"html",htm:"html",css:"css",json:"json",md:"markdown",sh:"shell",c:"c",h:"c",cpp:"cpp",java:"java",rb:"ruby",go:"go",rs:"rust",php:"php",sql:"sql",xml:"xml",yml:"yaml",yaml:"yaml",swift:"swift",kt:"kotlin",txt:"plaintext",ini:"ini",toml:"ini"};
const extOf=n=>(n.split(".").pop()||"").toLowerCase();
const BADGE={py:["PY","#3572A5"],js:["JS","#d6b500"],html:["<>","#e34c26"],css:["#","#563d7c"],json:["{}","#999"],md:["M↓","#4a90d9"],sh:["$","#89e051"],ts:["TS","#3178c6"]};
APPS.code={name:"Code",icon:"code",w:1040,h:680,single:true,
  create(w,opts){
    const st={root:"projects",open:[],cur:null,ed:null,models:new Map(),expanded:new Set(["projects"]),panel:"output"};
    w.body.innerHTML=`<div class="code">
      <div class="act-bar"><button class="on" data-v="explorer" title="Explorer">${SVG.docs}</button><button data-v="run" title="Run">${SVG.term}</button><button data-v="vscode" title="Open vscode.dev">${ICON.logo()}</button></div>
      <div class="explorer"><h6>EXPLORER <span><button data-x="newfile" title="New file">${SVG.plus.replace("<svg",'<svg width="14" height="14"')}</button><button data-x="newfolder" title="New folder">${SVG.folderPlus.replace("<svg",'<svg width="14" height="14"')}</button><button data-x="import" title="Import">${SVG.imp.replace("<svg",'<svg width="14" height="14"')}</button></span></h6><div data-tree></div></div>
      <div class="center"><div class="tabs" data-tabs></div>
        <div class="runbar"><button class="btn go" data-r="run">▶ Run</button><button class="btn" data-r="save">Save</button><button class="btn" data-r="term">Terminal (Linux)</button><span style="flex:1"></span><a class="btn" href="https://vscode.dev" target="_blank" rel="noopener" style="text-decoration:none">Open vscode.dev ↗</a></div>
        <div class="editor-host" data-host><div class="welcome"><b>Code</b><div>Open a file from the Explorer, or create a new one.<br>Run Python, JavaScript and HTML right here.</div></div></div>
        <div class="panel"><div class="ph"><span class="on" data-p="output">OUTPUT</span><span data-p="preview">PREVIEW</span><span data-p="input">INPUT (stdin)</span><span style="flex:1"></span><span data-p="clear" style="cursor:pointer">CLEAR</span></div>
          <pre data-out></pre><iframe data-prev sandbox="allow-scripts allow-modals" style="display:none"></iframe><textarea data-stdin class="editor mono" style="display:none;font-size:12.5px;padding:8px 12px" placeholder="Lines typed here are fed to input() in Python, one per call."></textarea></div>
        <div class="stbar"><span data-lang>Plain Text</span><span data-pos></span><span style="margin-left:auto" data-msg>Nimbus Code</span></div></div></div>`;
    const out=$("[data-out]",w.body),prev=$("[data-prev]",w.body),stdin=$("[data-stdin]",w.body),host=$("[data-host]",w.body);
    const print=(t,cls)=>{const s=document.createElement("span");if(cls)s.className=cls;s.textContent=t;out.appendChild(s);out.scrollTop=out.scrollHeight};
    const showPanel=p=>{st.panel=p;$$(".ph span[data-p]",w.body).forEach(s=>s.classList.toggle("on",s.dataset.p===p));out.style.display=p==="output"?"":"none";prev.style.display=p==="preview"?"":"none";stdin.style.display=p==="input"?"":"none"};
    $$(".ph span[data-p]",w.body).forEach(s=>s.onclick=()=>{if(s.dataset.p==="clear"){out.textContent="";return}showPanel(s.dataset.p)});
    /* tree */
    const drawTree=async()=>{const tree=$("[data-tree]",w.body);const rows=[];
      const walk=async(id,depth)=>{const kids=(await DB.fs.children(id)).sort((a,b)=>a.type!==b.type?(a.type==="folder"?-1:1):a.name.localeCompare(b.name));
        for(const k of kids){const open=st.expanded.has(k.id);const b=BADGE[extOf(k.name)];
          rows.push(`<div class="tn ${st.cur===k.id?"act":""}" data-id="${k.id}" data-type="${k.type}" style="padding-left:${8+depth*14}px"><i>${k.type==="folder"?(open?"▾":"▸"):""}</i>${k.type==="folder"?"📁":b?`<b style="color:${b[1]}">${b[0]}</b>`:"<b>·</b>"} ${esc(k.name)}</div>`);
          if(k.type==="folder"&&open)await walk(k.id,depth+1)}};
      for(const r of [{id:"projects",name:"Projects"},...ROOTS]){const open=st.expanded.has(r.id);rows.push(`<div class="tn" data-id="${r.id}" data-type="folder" style="font-weight:600;padding-left:6px"><i>${open?"▾":"▸"}</i>${esc(r.name.toUpperCase())}</div>`);if(open)await walk(r.id,1)}
      tree.innerHTML=rows.join("");
      $$(".tn",tree).forEach(el=>{el.onclick=()=>{if(el.dataset.type==="folder"){st.expanded.has(el.dataset.id)?st.expanded.delete(el.dataset.id):st.expanded.add(el.dataset.id);st.root=el.dataset.id;drawTree()}else openFile(el.dataset.id)};
        if(el.dataset.type!=="folder")longPress(el,e=>fileMenu(el.dataset.id,e.clientX,e.clientY,()=>closeTab(el.dataset.id)))})};
    /* tabs */
    const drawTabs=()=>{const t=$("[data-tabs]",w.body);t.innerHTML=st.open.map(o=>`<div class="t ${o.id===st.cur?"act":""}" data-id="${o.id}">${o.dirty?"● ":""}${esc(o.name)}<u data-close>×</u></div>`).join("");
      $$(".t",t).forEach(el=>{el.onclick=e=>{if(e.target.closest("[data-close]"))closeTab(el.dataset.id);else activate(el.dataset.id)}})};
    const ensureEditor=async()=>{if(st.ed)return st.ed;const m=await CodeEnv.monacoReady();host.innerHTML="";
      st.ed=m.editor.create(host,{automaticLayout:true,fontSize:14,minimap:{enabled:host.clientWidth>700},theme:document.documentElement.dataset.theme==="dark"?"vs-dark":"vs",tabSize:4,scrollBeyondLastLine:false,wordWrap:"on",fontFamily:"ui-monospace, SF Mono, Menlo, monospace"});
      st.ed.onDidChangeCursorPosition(e=>$("[data-pos]",w.body).textContent=`Ln ${e.position.lineNumber}, Col ${e.position.column}`);
      st.ed.addCommand(m.KeyMod.CtrlCmd|m.KeyCode.KeyS,()=>save());
      st.ed.addCommand(m.KeyMod.CtrlCmd|m.KeyCode.Enter,()=>run());
      return st.ed};
    const openFile=async id=>{const e=await DB.fs.get(id);if(!e)return;
      if(!st.open.find(o=>o.id===id)){let ed;try{ed=await ensureEditor()}catch(err){host.innerHTML=`<div class="welcome">Editor failed to load: ${esc(err.message||err)}</div>`;return}
        const m=CodeEnv.monaco;const lang=LANG[extOf(e.name)]||"plaintext";const model=m.editor.createModel(await e.blob.text(),lang);
        const o={id,name:e.name,model,dirty:false,lang};model.onDidChangeContent(()=>{if(!o.dirty){o.dirty=true;drawTabs()}});st.open.push(o)}
      activate(id)};
    const activate=async id=>{const o=st.open.find(x=>x.id===id);if(!o)return;st.cur=id;const ed=await ensureEditor();ed.setModel(o.model);ed.focus();
      $("[data-lang]",w.body).textContent=o.lang[0].toUpperCase()+o.lang.slice(1);w.setTitle(o.name+" — Code");drawTabs();drawTree()};
    const closeTab=async id=>{const i=st.open.findIndex(o=>o.id===id);if(i<0)return;const o=st.open[i];
      if(o.dirty){const r=await UI.dialog({title:`Save ${o.name}?`,text:"Your changes will be lost if you don't save them.",ok:"Save",cancel:"Don't Save"});if(r)await save(o)}
      o.model.dispose();st.open.splice(i,1);if(st.cur===id){st.cur=null;const n=st.open[Math.max(0,i-1)];if(n)activate(n.id);else{st.ed&&st.ed.setModel(null);w.setTitle("Code")}}drawTabs();drawTree()};
    const save=async(o=st.open.find(x=>x.id===st.cur))=>{if(!o)return;await FS.save(o.id,o.model.getValue());o.dirty=false;drawTabs();$("[data-msg]",w.body).textContent="Saved "+o.name;setTimeout(()=>$("[data-msg]",w.body).textContent="Nimbus Code",2000)};
    /* runners */
    let jsWorker=null;
    const run=async()=>{const o=st.open.find(x=>x.id===st.cur);if(!o){print("Open a file to run it.\n","e");return}
      if(o.dirty)await save(o);const ext=extOf(o.name),code=o.model.getValue();
      if(ext==="py"){showPanel("output");print(`$ python ${o.name}\n`,"s");
        try{const py=await CodeEnv.python(print);const lines=stdin.value.split("\n");let li=0;
          py.setStdout({batched:s=>print(s+"\n")});py.setStderr({batched:s=>print(s+"\n","e")});
          py.setStdin({stdin:()=>li<lines.length?lines[li++]:null});
          await py.runPythonAsync(code);print("\n[done]\n","s")}catch(err){print(String(err.message||err)+"\n","e")}}
      else if(ext==="js"||ext==="mjs"){showPanel("output");print(`$ node ${o.name}\n`,"s");if(jsWorker)jsWorker.terminate();
        const src=`const _f=(...a)=>a.map(x=>{try{return typeof x==="object"?JSON.stringify(x,null,2):String(x)}catch(e){return String(x)}}).join(" ");
          console.log=(...a)=>postMessage({t:"o",v:_f(...a)});console.info=console.log;console.warn=(...a)=>postMessage({t:"e",v:_f(...a)});console.error=console.warn;
          self.onmessage=async e=>{try{await (async()=>{${"\n"}${code.replace(/<\/script>/g,"<\\/script>")}${"\n"}})();postMessage({t:"d"})}catch(err){postMessage({t:"e",v:String(err&&err.stack||err)});postMessage({t:"d"})}}`;
        jsWorker=new Worker(URL.createObjectURL(new Blob([src],{type:"text/javascript"})));
        jsWorker.onmessage=e=>{const m=e.data;if(m.t==="o")print(m.v+"\n");else if(m.t==="e")print(m.v+"\n","e");else{print("[done]\n","s");jsWorker.terminate();jsWorker=null}};
        jsWorker.onerror=e=>{print((e.message||"Error")+"\n","e");e.preventDefault()};jsWorker.postMessage(0)}
      else if(ext==="html"||ext==="htm"){let doc=code;const e=await DB.fs.get(o.id);const sibs=await DB.fs.children(e.parent);
        for(const s of sibs){if(s.type!=="file")continue;const nm=s.name.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
          if(/\.css$/i.test(s.name))doc=doc.replace(new RegExp(`<link[^>]*href=["']${nm}["'][^>]*>`,"i"),`<style>${await s.blob.text()}</style>`);
          if(/\.js$/i.test(s.name))doc=doc.replace(new RegExp(`<script([^>]*)src=["']${nm}["']([^>]*)>\\s*</script>`,"i"),`<script$1$2>${(await s.blob.text()).replace(/<\/script>/g,"<\\/script>")}</script>`)}
        prev.srcdoc=doc;showPanel("preview")}
      else if(ext==="sh"){showPanel("output");print("Shell scripts run in Linux: copy this file to the Linux Shared folder, then in Linux run:\n  sh /mnt/sdb/"+o.name+"\n","s");
        const ok=await UI.confirm("Copy to Linux Shared?",`Put ${o.name} in the Linux Shared folder so Linux can run it next time it starts.`,"Copy");if(ok){await FS.addBlob("linuxshared",o.name,new Blob([code],{type:"text/x-sh"}));UI.toast("Copied","Linux Shared › "+o.name,"code")}}
      else{showPanel("output");print(`No runner for .${ext} files. Nimbus Code runs Python, JavaScript and HTML.\n`,"e")}};
    $("[data-r=run]",w.body).onclick=run;$("[data-r=save]",w.body).onclick=()=>save();$("[data-r=term]",w.body).onclick=()=>WM.open("linux");
    const newIn=async(kind)=>{const parent=st.root||"projects";const n=await UI.prompt(kind==="folder"?"New folder name":"New file name",kind==="folder"?"src":"main.py");if(!n)return;
      if(kind==="folder"){const id=await FS.mkdir(parent,n);st.expanded.add(parent);st.expanded.add(id)}else{const id=await FS.writeText(parent,await FS.uniqueName(parent,n),"");st.expanded.add(parent);openFile(id)}drawTree()};
    $("[data-x=newfile]",w.body).onclick=()=>newIn("file");$("[data-x=newfolder]",w.body).onclick=()=>newIn("folder");
    $("[data-x=import]",w.body).onclick=()=>pickFiles(async f=>{for(const x of f)await FS.addBlob(st.root||"projects",x.name,x);drawTree()});
    $$(".act-bar button",w.body).forEach(b=>b.onclick=()=>{if(b.dataset.v==="vscode"){openLink("https://vscode.dev");return}if(b.dataset.v==="run"){run();return}
      const ex=$(".explorer",w.body);ex.style.display=ex.style.display==="none"?"":"none";b.classList.toggle("on",ex.style.display!=="none")});
    FS.listeners.add(drawTree);drawTree();
    const themeObs=new MutationObserver(()=>{CodeEnv.monaco&&CodeEnv.monaco.editor.setTheme(document.documentElement.dataset.theme==="dark"?"vs-dark":"vs")});
    themeObs.observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
    (async()=>{if(opts.id)openFile(opts.id);else{const kids=await DB.fs.children("projects");const f=kids.find(k=>k.name==="hello.py");if(f)openFile(f.id)}})();
    return {focus(){st.ed&&st.ed.layout()},resize(){st.ed&&st.ed.layout()},reopenFile(o){if(o&&o.id)openFile(o.id)},
      async beforeClose(){for(const o of st.open.filter(x=>x.dirty)){const r=await UI.dialog({title:`Save ${o.name}?`,text:"Your changes will be lost if you don't save them.",ok:"Save",cancel:"Don't Save"});if(r)await save(o)}return true},
      close(){FS.listeners.delete(drawTree);themeObs.disconnect();if(jsWorker)jsWorker.terminate();st.open.forEach(o=>o.model.dispose());st.ed&&st.ed.dispose()}}},
  reopen(w,o){w.hooks.reopenFile&&w.hooks.reopenFile(o)}
};

/* ================= Launchpad ================= */
document.body.appendChild(html(`<div id="launchpad"><input placeholder="Search" data-lpq autocapitalize="off"><div class="lp-grid" data-lpg></div></div>`));
APPS.launchpad={name:"Launchpad",icon:"launchpad",hidden:true,launch(){Launchpad.open();return false},create(){}};
const Launchpad={
  open(){const lp=$("#launchpad");lp.classList.add("show");const q=$("[data-lpq]",lp);q.value="";Launchpad.draw("")},
  close(){$("#launchpad").classList.remove("show")},
  draw(q){const g=$("[data-lpg]");const list=Object.entries(APPS).filter(([id,a])=>!a.hidden&&a.name.toLowerCase().includes(q.toLowerCase()));
    g.innerHTML=list.map(([id,a])=>`<div class="lp" data-app="${id}">${ICON[a.icon]()}<span>${esc(a.name)}</span></div>`).join("");
    $$(".lp",g).forEach(el=>el.onclick=e=>{e.stopPropagation();Launchpad.close();Dock.launch(el.dataset.app)})}
};
$("[data-lpq]").oninput=e=>Launchpad.draw(e.target.value);
$("#launchpad").addEventListener("click",e=>{if(e.target.id==="launchpad"||e.target.classList.contains("lp-grid"))Launchpad.close()});
$("[data-lpq]").addEventListener("keydown",e=>{if(e.key==="Escape")Launchpad.close();if(e.key==="Enter"){const f=$("#launchpad .lp");f&&f.click()}});

/* ================= Downloads stack (Dock) ================= */
const Stack={async toggle(anchor){const ex=$(".stack");if(ex){ex.remove();return}
  const kids=(await DB.fs.children("downloads")).sort((a,b)=>b.mtime-a.mtime).slice(0,12);
  const el=html(`<div class="stack"><h4>Downloads <a href="#" data-open style="color:var(--accent);text-decoration:none;font-weight:400">Open in Files</a></h4>
    ${kids.length?`<div class="sgrid">${kids.map(k=>`<div class="fi" data-id="${k.id}">${fileIcon(k)}<span>${esc(k.name)}</span></div>`).join("")}</div>`:`<div class="empty" style="padding:20px">No downloads yet.<br><a href="#" data-imp style="color:var(--accent)">Import from the iPad…</a></div>`}</div>`);
  document.body.appendChild(el);const r=anchor.getBoundingClientRect();el.style.left=Math.min(innerWidth-350,Math.max(8,r.left+r.width/2-170))+"px";el.style.bottom=(innerHeight-r.top+14)+"px";
  $("[data-open]",el).onclick=e=>{e.preventDefault();el.remove();WM.open("files",{folder:"downloads"})};
  const imp=$("[data-imp]",el);if(imp)imp.onclick=e=>{e.preventDefault();el.remove();pickFiles(async f=>{for(const x of f)await FS.addBlob("downloads",x.name,x);UI.toast("Imported",`${f.length} file(s) in Downloads`,"downloads")})};
  $$("[data-id]",el).forEach(t=>t.onclick=async()=>{el.remove();const en=await DB.fs.get(t.dataset.id);en&&openEntry(en)})}};
document.addEventListener("pointerdown",e=>{if(!e.target.closest(".stack")&&!e.target.closest("[data-stack]"))$(".stack")?.remove()},true);

/* ================= Lock screen ================= */
document.body.appendChild(html(`<div id="lock"><div class="bg"></div><div class="d" data-ld></div><div class="t" data-lt></div><div class="hint">Swipe up or tap to unlock</div></div>`));
const Lock={
  show(){const l=$("#lock"),bg=$(".bg",l),wall=$("#wall");bg.className="bg "+wall.className;bg.style.backgroundImage=wall.style.backgroundImage;bg.style.backgroundSize="cover";Lock.tick();l.classList.add("show");if(LX.running)LX.setKb(false)},
  hide(){const l=$("#lock");l.style.transition="transform .35s ease, opacity .35s";l.style.transform="translateY(-40px)";l.style.opacity=0;setTimeout(()=>{l.classList.remove("show");l.style.transform="";l.style.opacity="";l.style.transition=""},350)},
  tick(){const d=new Date();$("[data-lt]").textContent=d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}).replace(/\s?[AP]M/i,"");$("[data-ld]").textContent=d.toLocaleDateString([], {weekday:"long",month:"long",day:"numeric"})}
};
$("#lock").addEventListener("click",()=>Lock.hide());
setInterval(()=>{if($("#lock").classList.contains("show"))Lock.tick()},5000);

/* ================= window snapping ================= */
document.body.appendChild(html(`<div id="snap"></div>`));
const Snap={zone:null,
  check(x,y){const area=$("#windows").getBoundingClientRect();let z=null;if(x<=area.left+6)z="left";else if(x>=area.right-6)z="right";else if(y<=area.top+2)z="max";
    Snap.zone=z;const s=$("#snap");if(!z){s.style.display="none";return}
    const h=area.height-S.dockSize-24;const r=z==="left"?{l:area.left+6,t:area.top+6,w:area.width/2-9,h:h-12}:z==="right"?{l:area.left+area.width/2+3,t:area.top+6,w:area.width/2-9,h:h-12}:{l:area.left+6,t:area.top+6,w:area.width-12,h:h-12};
    Object.assign(s.style,{display:"block",left:r.l+"px",top:r.t+"px",width:r.w+"px",height:r.h+"px"})},
  apply(w){const z=Snap.zone;$("#snap").style.display="none";Snap.zone=null;if(!z)return;
    if(z==="max"){w.el.classList.add("max");setTimeout(()=>w.hooks.resize&&w.hooks.resize(),50);return}
    const area=$("#windows").getBoundingClientRect(),h=area.height-S.dockSize-24;
    Object.assign(w.el.style,{left:(z==="left"?0:area.width/2)+"px",top:"0px",width:area.width/2+"px",height:h+"px"});setTimeout(()=>w.hooks.resize&&w.hooks.resize(),50)}
};
/* hook into title-bar dragging */
const _bind=WM.bindChrome;
WM.bindChrome=function(w){_bind(w);const tb=$(".titlebar",w.el);let dragging=false;
  tb.addEventListener("pointerdown",e=>{if(!e.target.closest(".lights,.tb-tools")&&!w.el.classList.contains("max"))dragging=true});
  tb.addEventListener("pointermove",e=>{if(dragging&&e.buttons)Snap.check(e.clientX,e.clientY)});
  const end=()=>{if(dragging){dragging=false;Snap.apply(w)}};tb.addEventListener("pointerup",end);tb.addEventListener("pointercancel",()=>{dragging=false;$("#snap").style.display="none"})};

/* ================= menu / dock / seed integration ================= */
DOCK_APPS.splice(0,DOCK_APPS.length,"files","launchpad","web","messages","mail","docs","sheets","code","linux","notes","settings");
const _dockRender=Dock.render;
Dock.render=function(){_dockRender();const d=$("#dock");const el=html(`<div class="dk" data-stack><div class="tip">Downloads</div>${ICON.downloads()}</div>`);el.onclick=()=>Stack.toggle(el);d.appendChild(el)};
const _openMenu=Menubar.openMenu;
Menubar.openMenu=function(m,el){if(m==="logo"&&!el.classList.contains("open")){el.classList.add("open");const r=el.getBoundingClientRect();
    UI.menu([{label:"About Nimbus",action:()=>about()},"-",{label:"Settings…",key:"⌘,",action:()=>WM.open("settings")},{label:"Launchpad",action:()=>Launchpad.open()},{label:"Show Desktop",action:()=>WM.showDesktop()},"-",{label:"Lock Screen",key:"⌃⌘Q",action:()=>Lock.show()},{label:"Reload Desktop",action:()=>location.reload()}],r.left,r.bottom+4);return}
  return _openMenu(m,el)};
document.addEventListener("keydown",e=>{if(e.metaKey&&e.ctrlKey&&(e.key==="q"||e.key==="Q")){e.preventDefault();Lock.show()}if(e.key==="F4"){e.preventDefault();$("#launchpad").classList.contains("show")?Launchpad.close():Launchpad.open()}},true);
ROOTS.push({id:"linuxshared",name:"Linux Shared",icon:"term"});
const _seed=FS.seed;
FS.seed=async function(){await _seed();
  if(!(await DB.fs.get("linuxshared"))){await DB.fs.put({id:"linuxshared",parent:"root",name:"Linux Shared",type:"folder",mtime:Date.now()});
    await FS.writeText("linuxshared","README.txt","Files in this folder appear inside Linux as the second drive (sdb).\nIn Tiny Core: open the Mount tool and tap sdb, or run:  mount /mnt/sdb\nChanges you make in Linux come back here when you stop Linux (or use Linux › More › Sync shared folder).\n")}
  if(!(await DB.fs.get("projects"))){await DB.fs.put({id:"projects",parent:"root",name:"Projects",type:"folder",mtime:Date.now()});
    await FS.writeText("projects","hello.py",`# Welcome to Nimbus Code!  Press Run (or Cmd+Enter).
import math, random

name = input() or "friend"   # type a name in the INPUT tab
print(f"Hello, {name}! 👋")

squares = [n * n for n in range(1, 11)]
print("Squares:", squares)
print("Average:", sum(squares) / len(squares))
print("Random pick:", random.choice(["Linux", "Python", "iPad", "Nimbus"]))
print("Pi to 10 places:", round(math.pi, 10))
`);
    await FS.writeText("projects","index.html",`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Hello from Nimbus 🚀</h1>
  <p>Edit index.html, style.css and app.js, then press Run to preview.</p>
  <button id="btn">Click me</button>
  <p id="out"></p>
  <script src="app.js"></script>
</body>
</html>
`);
    await FS.writeText("projects","style.css",`body { font-family: -apple-system, sans-serif; padding: 24px; background: linear-gradient(160deg, #eef2ff, #fdf2f8); }
h1 { color: #4f46e5; }
button { font-size: 16px; padding: 8px 18px; border-radius: 10px; border: 0; background: #4f46e5; color: #fff; }
`);
    await FS.writeText("projects","app.js",`let clicks = 0;
document.getElementById("btn").onclick = () => {
  clicks++;
  document.getElementById("out").textContent = "Clicked " + clicks + " time(s)";
};
console.log("app.js loaded");
`)}
};

/* ---- Linux window additions: shared folder buttons & drive info ---- */
const _lxCreate=APPS.linux.create;
APPS.linux.create=function(w,opts){const hooks=_lxCreate(w,opts);
  const bar=$(".lx-bar",w.body);const btn=html(`<button class="btn" title="Shared folder">${SVG.folderPlus}Shared</button>`);btn.onclick=()=>WM.open("files",{folder:"linuxshared"});bar.insertBefore(btn,$("[data-a=more]",bar));
  const more=$("[data-a=more]",w.body);const orig=more.onclick;
  more.onclick=e=>{const r=e.target.getBoundingClientRect();UI.menu([
    {label:"Sync shared folder now",disabled:!LX.running,action:async()=>{const n=await LX.syncShared();UI.toast("Shared folder",n?`${n} change(s) copied from Linux`:"No changes (run sync in Linux first)","linux")}},
    {label:"Save Linux drive now",disabled:!LX.running,action:async()=>{await DB.set("linux-hdd",new Blob([LX.hddBuf]));UI.toast("Linux drive saved","256 MB","linux")}},"-",
    {label:"Other options…",action:()=>orig.call(more,e)}],r.left,r.bottom+4)};
  /* extra help in setup panel */
  const obs=new MutationObserver(()=>{const s=$(".lx-setup",w.body);if(s&&!s.dataset.ext){s.dataset.ext=1;s.insertAdjacentHTML("beforeend",`<h4 style="margin:18px 0 4px">Drives</h4><ul>
    <li><b>Permanent drive (sda1, 256 MB):</b> Tiny Core finds it automatically. Apps you install with the <i>Apps</i> tool and your backups are kept between sessions. Choose <b>Backup</b> when you exit Tiny Core to keep your home folder.</li>
    <li><b>Shared drive (sdb):</b> everything in <b>Files › Linux Shared</b>. Mount it with the <i>Mount</i> tool or <code>mount /mnt/sdb</code>. Changes come back to Nimbus when you stop Linux.</li></ul>`)}});
  obs.observe(w.body,{childList:true,subtree:true});
  const _close=hooks.close;hooks.close=()=>{obs.disconnect();_close&&_close()};return hooks};

/* ---- Settings: drive management ---- */
const _setCreate=APPS.settings.create;
APPS.settings.create=function(w,opts){const hooks=_setCreate(w,opts);
  const obs=new MutationObserver(async()=>{const P=$("[data-pane]",w.body);if(!P||P.dataset.ext||!$("[data-relay]",P))return;P.dataset.ext=1;const hdd=await DB.get("linux-hdd");
    P.insertAdjacentHTML("beforeend",`<h3 style="margin:0;font-size:14px">Drives</h3><div class="set-group">
      <div class="set-row"><div><label>Permanent drive</label><small>${hdd?"256 MB · saved on this iPad":"Fresh — created the first time Linux starts"}</small></div><button class="btn" data-rmhdd ${hdd?"":"disabled"} style="color:#ff3b30">Erase…</button></div>
      <div class="set-row"><div><label>Shared folder</label><small>Files › Linux Shared ↔ Linux drive sdb (64 MB)</small></div><button class="btn" data-opensh>Open</button></div></div>`);
    $("[data-opensh]",P).onclick=()=>WM.open("files",{folder:"linuxshared"});
    $("[data-rmhdd]",P).onclick=async()=>{if(LX.running)return UI.toast("Linux is running","Stop it first","linux");if(await UI.confirm("Erase the Linux drive?","Installed apps and backups inside Linux will be deleted.","Erase",true)){await DB.del("linux-hdd");await DB.del("linux-state");UI.toast("Linux drive erased","A fresh one is made next start","linux");P.dataset.ext="";P.innerHTML="";w.hooks.reopenPane&&w.hooks.reopenPane({pane:"linux"})}}});
  obs.observe(w.body,{childList:true,subtree:true});const _c=hooks.close;hooks.close=()=>{obs.disconnect();_c&&_c()};return hooks};

/* ---- Files: "Open with" for office docs ---- */
const _fileMenu=fileMenu;
fileMenu=async function(id,x,y,after){const e=await DB.fs.get(id);if(e&&e.type==="file"&&(isText(e)||isCode(e))&&!isDocx(e)){
    UI.menu([{label:"Open",action:()=>openEntry(e)},{label:"Open in Code",action:()=>WM.open("code",{id})},{label:"Open in TextEdit",action:()=>WM.open("editor",{id})},
      {label:"Rename…",action:async()=>{const n=await UI.prompt("Rename",e.name);if(n)FS.rename(id,n)}},{label:"Copy to Linux Shared",action:async()=>{await FS.addBlob("linuxshared",e.name,e.blob);UI.toast("Copied","Linux Shared › "+e.name,"linux")}},
      {label:"Share / Export…",action:()=>shareFile(e)},"-",{label:"Delete",action:async()=>{if(await UI.confirm(`Delete “${e.name}”?`,"This can't be undone.","Delete",true)){await FS.remove(id);after&&after()}}}],x,y);return}
  return _fileMenu(id,x,y,after)};

/* ================= boot ================= */
/* boot is started by nimbus-apps.js */
