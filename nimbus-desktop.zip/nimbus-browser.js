/* Nimbus Desktop — Browser (Safari-style, tabbed, pages open inside Nimbus) and web apps in their own windows. */
"use strict";

document.head.appendChild(html(`<style>
.br{flex:1;display:flex;flex-direction:column;min-width:0;min-height:0}
.br-tabs{display:flex;gap:4px;padding:6px 8px 0;overflow-x:auto;flex:none;align-items:flex-end}
.br-tab{display:flex;align-items:center;gap:6px;max-width:220px;min-width:90px;padding:6px 8px 6px 10px;border-radius:9px 9px 0 0;font-size:12px;color:var(--text2);cursor:default;background:transparent;white-space:nowrap}
.br-tab.act{background:var(--field);color:var(--text);font-weight:600}
.br-tab span{overflow:hidden;text-overflow:ellipsis;flex:1}
.br-tab img,.br-tab i.fv{width:14px;height:14px;border-radius:3px;flex:none;font-style:normal;font-size:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700}
.br-tab u{text-decoration:none;opacity:.5;padding:0 3px;border-radius:4px}.br-tab u:hover{opacity:1;background:var(--hover)}
.br-bar{display:flex;align-items:center;gap:6px;padding:6px 10px;background:var(--field);flex:none}
.br-bar .btn{background:none;padding:5px 7px}.br-bar .btn:hover{background:var(--hover)}
.br-bar .btn:disabled{opacity:.35}
.br-url{flex:1;display:flex;align-items:center;gap:6px;background:var(--win-bg);border-radius:9px;padding:0 10px;min-width:0}
.br-url input{flex:1;border:0;background:none;outline:none;padding:7px 0;font-size:13.5px;text-align:center;min-width:0}
.br-url input:focus{text-align:left}
.br-view{flex:1;position:relative;min-height:0;background:#fff}
.br-view iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:#fff}
.br-view .start{position:absolute;inset:0;overflow:auto;background:var(--win-bg);color:var(--text)}
.br-hint{position:absolute;left:50%;bottom:14px;transform:translateX(-50%);background:var(--glass-strong);color:var(--text);border-radius:12px;padding:8px 10px 8px 14px;font-size:12.5px;display:flex;gap:10px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.25);z-index:2;white-space:nowrap;
  backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border:1px solid var(--glass-border)}
.br-hint .btn{padding:5px 10px;font-size:12px}
.br-blocked{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:var(--win-bg);color:var(--text);text-align:center;padding:30px}
.br-blocked .ic{width:72px;height:72px}
.br-blocked h3{margin:0;font-size:18px}.br-blocked p{margin:0;color:var(--text2);max-width:440px;line-height:1.5;font-size:13px}
.br-progress{position:absolute;left:0;top:0;height:2px;background:var(--accent);z-index:3;transition:width .4s,opacity .3s}
.wa-bar{display:flex;align-items:center;gap:6px;padding:4px 8px;flex:none;font-size:12px;color:var(--text3);border-bottom:1px solid var(--hair)}
.wa-bar .btn{padding:3px 8px;font-size:12px;background:none}.wa-bar .btn:hover{background:var(--hover)}
</style>`));

/* ---------- which sites refuse to be shown inside other apps ---------- */
const FRAME_BLOCKED=["google.","youtube.com/watch","youtube.com/@","youtube.com/results","gmail.com","microsoft.com","office.com","office365.com","live.com","outlook.","microsoftonline.com","sharepoint.com","onedrive.","bing.com",
  "github.com","gitlab.com","facebook.com","instagram.com","whatsapp.com","x.com","twitter.com","linkedin.com","amazon.","apple.com","icloud.com","yahoo.","aol.com","netflix.com","reddit.com","paypal.","stripe.com",
  "chatgpt.com","openai.com","claude.ai","anthropic.com","notion.so","canva.com","dropbox.com","tiktok.com","pinterest.","ebay.","stackoverflow.com","discord.com","slack.com","zoom.us","spotify.com","proton.me","zoho.com",
  "bankofamerica","chase.com","wellsfargo","hsbc","barclays","hdfcbank","icicibank","sbi.co.in","etsy.com","booking.com","airbnb.","uber.com","twitch.tv","medium.com","quora.com","imdb.com","wikipedia.org/wiki/Special"];
function hostOf(u){try{return new URL(u).hostname.replace(/^www\./,"")}catch(e){return u}}
function frameBlocked(url){const u=url.toLowerCase().replace(/^https?:\/\/(www\.)?/,"");return FRAME_BLOCKED.some(b=>u.includes(b)&&(b.includes("/")?u.includes(b):(u.split("/")[0].includes(b))))}
/* rewrite a few well-known pages to their embeddable form */
function embeddable(url){
  let m=url.match(/youtube\.com\/watch\?.*v=([\w-]{6,})/)||url.match(/youtu\.be\/([\w-]{6,})/);if(m)return `https://www.youtube-nocookie.com/embed/${m[1]}?autoplay=1`;
  m=url.match(/open\.spotify\.com\/(track|album|playlist|episode|show)\/(\w+)/);if(m)return `https://open.spotify.com/embed/${m[1]}/${m[2]}`;
  m=url.match(/(?:www\.)?figma\.com\/(file|design|proto)\//);if(m)return `https://www.figma.com/embed?embed_host=nimbus&url=${encodeURIComponent(url)}`;
  m=url.match(/maps\.google\.[^/]+\/.*[?&]q=([^&]+)/);if(m)return `https://maps.google.com/maps?q=${m[1]}&output=embed`;
  return url}
function normalizeUrl(q){q=q.trim();if(!q)return null;if(/^https?:\/\//i.test(q))return q;if(/^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/.test(q))return "https://"+q;return "https://duckduckgo.com/?q="+encodeURIComponent(q)}
const favColor=h=>{let x=0;for(const c of h)x=(x*31+c.charCodeAt(0))>>>0;return ["#ff6b6b","#f59f00","#40c057","#15aabf","#4c6ef5","#7950f2","#e64980","#495057"][x%8]};
const favIcon=u=>{const h=hostOf(u);return `<i class="fv" style="background:${favColor(h)}">${esc((h[0]||"?").toUpperCase())}</i>`};

/* ---------- web view (iframe + fallbacks) ---------- */
function makeWebView(view,{onState}={}){
  const st={url:null,frame:null,hintT:null};
  const clear=()=>{view.querySelectorAll("iframe,.br-blocked,.br-hint,.br-progress").forEach(e=>e.remove())};
  const blockedCard=url=>{const el=html(`<div class="br-blocked">${ICON.web()}<h3>${esc(hostOf(url))} opens in Safari</h3>
      <p>This website doesn't allow itself to be shown inside other apps (most sign-in, banking, Google and Microsoft sites work this way, to protect your account). Open it in Safari — your saved passwords and Face ID work there.</p>
      <div style="display:flex;gap:8px"><a class="btn primary" href="${esc(url)}" target="_blank" rel="noopener" style="text-decoration:none">Open in Safari ↗</a><button class="btn" data-try>Try inside Nimbus anyway</button></div></div>`);
    $("[data-try]",el).onclick=()=>load(url,true);return el};
  const load=(url,force=false)=>{clear();st.url=url;onState&&onState();
    if(SANDBOXED){view.appendChild(html(`<div class="br-blocked">${ICON.web()}<h3>Browsing inside Nimbus needs the installed version</h3><p>This preview page isn't allowed to show other websites. In the version you added to your Home Screen, pages open right here.</p><a class="btn primary" href="${esc(url)}" target="_blank" rel="noopener" style="text-decoration:none">Open in Safari ↗</a></div>`));return}
    if(!force&&frameBlocked(url)){view.appendChild(blockedCard(url));return}
    const src=embeddable(url);
    const prog=html(`<div class="br-progress" style="width:15%"></div>`);view.appendChild(prog);setTimeout(()=>prog.style.width="65%",60);
    const f=document.createElement("iframe");f.src=src;f.allow="autoplay; fullscreen; clipboard-write; encrypted-media; picture-in-picture; web-share";
    f.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-presentation allow-pointer-lock");
    f.referrerPolicy="strict-origin-when-cross-origin";
    f.onload=()=>{prog.style.width="100%";setTimeout(()=>prog.style.opacity=0,300);setTimeout(()=>prog.remove(),700)};
    view.appendChild(f);st.frame=f;
    clearTimeout(st.hintT);st.hintT=setTimeout(()=>{if(st.url!==url||!view.contains(f))return;const h=html(`<div class="br-hint">Page blank or not working? <a class="btn primary" href="${esc(url)}" target="_blank" rel="noopener" style="text-decoration:none">Open in Safari ↗</a><button class="btn" data-x>✕</button></div>`);
      $("[data-x]",h).onclick=()=>h.remove();view.appendChild(h);setTimeout(()=>h.isConnected&&(h.style.transition="opacity .5s",h.style.opacity=0,setTimeout(()=>h.remove(),500)),9000)},2500)};
  return {load,get url(){return st.url},reload(){st.url&&load(st.url,!!st.frame)},clear}}

/* ---------- Browser app ---------- */
const BR_FAVS=[["Wikipedia","https://en.m.wikipedia.org/","#636466","W"],["YouTube","https://m.youtube.com/","#ff0033","▶"],["Photopea","https://www.photopea.com/","#18a497","P"],["Graphite","https://editor.graphite.rs/","#4b5563","G"],
  ["Excalidraw","https://excalidraw.com/","#6965db","E"],["tldraw","https://www.tldraw.com/","#1d1d1d","t"],["DuckDuckGo","https://duckduckgo.com/","#de5833","D"],["Hacker News","https://news.ycombinator.com/","#ff6600","Y"],
  ["Weather","https://wttr.in/","#2f80ed","☀"],["OpenStreetMap","https://www.openstreetmap.org/","#7ebc6f","⌖"],["Gmail","https://mail.google.com/","#ea4335","M"],["Google","https://www.google.com/","#4285f4","G"]];
APPS.web={name:"Browser",icon:"web",w:1080,h:720,
  create(w,opts){
    const tabs=[];let cur=null;
    w.body.innerHTML=`<div class="br"><div class="br-tabs" data-tabs></div>
      <div class="br-bar"><button class="btn icon" data-a="back" title="Back">${SVG.back}</button><button class="btn icon" data-a="fwd" title="Forward">${SVG.back.replace("m15 5-7 7 7 7","m9 5 7 7-7 7")}</button>
        <button class="btn icon" data-a="reload" title="Reload"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg></button>
        <div class="br-url">${SVG.search.replace("<svg",'<svg width="14" height="14" style="opacity:.45;flex:none"')}<input data-url placeholder="Search or enter website" enterkeyhint="go" autocapitalize="off" autocorrect="off" spellcheck="false"></div>
        <button class="btn icon" data-a="dock" title="Add to Dock as an app">${SVG.plus}</button><button class="btn icon" data-a="share" title="Open in Safari">${SVG.share}</button><button class="btn icon" data-a="newtab" title="New tab">${SVG.grid.replace("<svg",'<svg width="15" height="15"')}</button></div>
      <div class="br-view" data-view></div></div>`;
    const view=$("[data-view]",w.body),url=$("[data-url]",w.body);
    const drawTabs=()=>{const t=$("[data-tabs]",w.body);t.innerHTML=tabs.map(x=>`<div class="br-tab ${x===cur?"act":""}" data-id="${x.id}">${x.url?favIcon(x.url):`<i class="fv" style="background:var(--accent)">★</i>`}<span>${esc(x.url?hostOf(x.url):"Start Page")}</span><u data-close>✕</u></div>`).join("")+`<button class="btn icon" data-plus style="padding:4px 8px;background:none">${SVG.plus.replace("<svg",'<svg width="14" height="14"')}</button>`;
      $$(".br-tab",t).forEach(el=>el.onclick=e=>{const x=tabs.find(y=>y.id===el.dataset.id);if(e.target.closest("[data-close]"))closeTab(x);else show(x)});$("[data-plus]",t).onclick=()=>newTab()};
    const updBar=()=>{if(!cur)return;url.value=cur.url||"";$("[data-a=back]",w.body).disabled=cur.idx<=0&&!cur.url;$("[data-a=fwd]",w.body).disabled=cur.idx>=cur.hist.length-1;w.setTitle(cur.url?hostOf(cur.url):"Start Page");drawTabs()};
    const startPage=async x=>{const recent=(await DB.get("web-recent",[])).slice(0,8);
      x.pane.innerHTML=`<div class="start"><div class="web-start"><h2>Favourites</h2><div class="favs">${BR_FAVS.map(f=>`<a class="fav" data-go="${f[1]}"><i style="background:${f[2]}">${f[3]}</i>${f[0]}</a>`).join("")}</div>
        ${recent.length?`<div style="width:100%;max-width:640px"><h3 style="font-size:14px;margin:6px 0">Recently visited</h3>${recent.map(u=>`<div style="padding:5px 0;display:flex;gap:8px;align-items:center">${favIcon(u)}<a data-go="${esc(u)}" style="color:var(--accent);cursor:pointer">${esc(u.replace(/^https?:\/\//,"").slice(0,70))}</a></div>`).join("")}</div>`:""}
        <p class="muted" style="max-width:560px;text-align:center;font-size:12px;line-height:1.5">Pages open right here in Nimbus. Some sites — Google, Microsoft, banks and most sign-in pages — refuse to be shown inside other apps; those open in Safari with one tap, where your passwords and Face ID work.</p></div></div>`;
      $$("[data-go]",x.pane).forEach(a=>a.onclick=e=>{e.preventDefault();navigate(x,a.dataset.go)})};
    const newTab=(u)=>{const pane=html(`<div style="position:absolute;inset:0"></div>`);view.appendChild(pane);
      const x={id:uid(),url:null,hist:[],idx:-1,pane};x.wv=makeWebView(pane,{onState:()=>{}});tabs.push(x);show(x);if(u)navigate(x,u);else{startPage(x);setTimeout(()=>url.focus(),60)}return x};
    const show=x=>{cur=x;tabs.forEach(t=>t.pane.style.display=t===x?"":"none");updBar()};
    const closeTab=x=>{const i=tabs.indexOf(x);x.pane.remove();tabs.splice(i,1);if(!tabs.length){WM.close(w);return}if(cur===x)show(tabs[Math.max(0,i-1)]);else drawTabs()};
    const navigate=async(x,u,push=true)=>{if(!u)return;x.url=u;if(push){x.hist=x.hist.slice(0,x.idx+1);x.hist.push(u);x.idx=x.hist.length-1}
      x.pane.innerHTML="";x.wv=makeWebView(x.pane);x.wv.load(u);updBar();
      const r=(await DB.get("web-recent",[])).filter(v=>v!==u);r.unshift(u);DB.set("web-recent",r.slice(0,30))};
    url.onkeydown=e=>{if(e.key==="Enter"){const u=normalizeUrl(url.value);if(u){navigate(cur,u);url.blur()}}};
    $$("[data-a]",w.body).forEach(b=>b.onclick=async()=>{const a=b.dataset.a;
      if(a==="back"){if(cur.idx>0){cur.idx--;navigate(cur,cur.hist[cur.idx],false)}else if(cur.url){cur.url=null;cur.idx=-1;cur.pane.innerHTML="";startPage(cur);updBar()}}
      if(a==="fwd"&&cur.idx<cur.hist.length-1){cur.idx++;navigate(cur,cur.hist[cur.idx],false)}
      if(a==="reload"&&cur.url)navigate(cur,cur.url,false);
      if(a==="share"&&cur.url)openLink(cur.url);
      if(a==="newtab")newTab();
      if(a==="dock"){if(!cur.url)return UI.toast("Open a page first","Then tap + to add it to your Dock");
        const r=await UI.dialog({title:"Add to Dock",text:`${esc(hostOf(cur.url))} becomes an app with its own icon and window.`,fields:[{value:hostOf(cur.url).split(".")[0].replace(/^\w/,c=>c.toUpperCase()),ph:"App name"}],ok:"Add"});
        if(r&&r[0].trim()){addWebApp(r[0].trim(),cur.url,frameBlocked(cur.url)?"safari":"nimbus")}}});
    newTab(opts&&opts.url);
    const kh=e=>{if(WM.active!==w)return;if((e.metaKey||e.ctrlKey)&&e.key==="t"){e.preventDefault();newTab()}if((e.metaKey||e.ctrlKey)&&e.key==="l"){e.preventDefault();url.focus();url.select()}if((e.metaKey||e.ctrlKey)&&e.key==="r"){e.preventDefault();cur.url&&navigate(cur,cur.url,false)}};
    document.addEventListener("keydown",kh);
    return {close(){document.removeEventListener("keydown",kh)},openUrl(u){newTab(u)}}},
  reopen(w,o){if(o&&o.url&&w.hooks.openUrl)w.hooks.openUrl(o.url)}
};
/* links from Spotlight / elsewhere: open web pages in the Browser instead of leaving Nimbus */
function openInBrowser(u){if(frameBlocked(u)||SANDBOXED){openLink(u);return}const w=WM.wins.find(x=>x.app==="web");if(w){WM.restore(w);w.hooks.openUrl(u)}else WM.open("web",{url:u})}

/* ---------- web apps: open in their own Nimbus window when the site allows it ---------- */
function webAppWindow(a){return function(w){
  w.body.innerHTML=`<div class="br"><div class="wa-bar">${favIcon(a.url)}<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" data-host>${esc(hostOf(a.url))}</span>
    <button class="btn" data-a="home">Home</button><button class="btn" data-a="reload">Reload</button><a class="btn" href="${esc(a.url)}" target="_blank" rel="noopener" style="text-decoration:none">Open in Safari ↗</a></div><div class="br-view" data-view></div></div>`;
  const wv=makeWebView($("[data-view]",w.body));wv.load(a.url);
  $("[data-a=home]",w.body).onclick=()=>wv.load(a.url,true);$("[data-a=reload]",w.body).onclick=()=>wv.reload();w.setTitle(a.name);return {}}}
const _registerWebApp=registerWebApp;
registerWebApp=function(a){_registerWebApp(a);const app=APPS[a.id];const mode=()=>(S.webModes||{})[a.id]||a.openIn||(frameBlocked(a.url)?"safari":"nimbus");
  app.w=1100;app.h=740;app.mode=mode;app.create=webAppWindow(a);
  app.launch=()=>{if(mode()==="nimbus"&&!SANDBOXED)return true;openLink(a.url);UI.toast(`Opening ${a.name}`,"In Safari",a.icon);return false}};
WEBAPPS_BUILTIN.forEach(a=>registerWebApp(a));
function addWebApp(name,url,mode){const id="web_"+uid();const colors=["#5e5ce6","#ff375f","#ff9f0a","#30d158","#0a84ff","#bf5af2","#64d2ff","#ff6b6b"];
  const a={id,name,url,color:colors[(S.webapps||[]).length%colors.length],openIn:mode};S.webapps=[...(S.webapps||[]),a];S.pinned=[...(S.pinned||[]),id];
  saveSettings();registerWebApp({...a,icon:"u_"+id,user:true});rebuildDock();UI.toast("Added to Dock",`${name} opens ${mode==="nimbus"?"inside Nimbus":"in Safari"}`);return a}
addWebAppDialog=async function(){
  const r=await UI.dialog({title:"Add a Web App",text:"It gets its own icon in Launchpad and the Dock. Sites that allow it open inside Nimbus; others open in Safari.",fields:[{ph:"Name (e.g. Photopea)"},{ph:"Website (e.g. photopea.com)",type:"url"}],ok:"Add"});
  if(!r||!r[0].trim()||!r[1].trim())return false;const u=normalizeUrl(r[1]);addWebApp(r[0].trim(),u,frameBlocked(u)?"safari":"nimbus");return true};
/* per-app "open in" switch (Launchpad / Dock long-press) */
function setWebMode(id,m){S.webModes={...(S.webModes||{}),[id]:m};saveSettings();UI.toast(APPS[id].name,m==="nimbus"?"Will open inside Nimbus":"Will open in Safari")}
let MENU_CTX=null;
document.addEventListener("pointerdown",e=>{const el=e.target.closest("#dock .dk[data-app],#launchpad .lp[data-app]");MENU_CTX=el?{id:el.dataset.app,t:Date.now()}:null},true);
const _uiMenu=UI.menu;
UI.menu=function(items,x,y,cls){const c=MENU_CTX;const a=c&&Date.now()-c.t<2000?APPS[c.id]:null;
  if(a&&a.webapp&&a.mode&&!items.some(i=>i&&i.webmode)){const id=c.id;items=[...items,"-",{webmode:true,label:a.mode()==="nimbus"?"Open in Safari instead":"Open inside Nimbus",action:()=>setWebMode(id,a.mode()==="nimbus"?"safari":"nimbus")}]}
  return _uiMenu.call(UI,items,x,y,cls)};
/* Spotlight web search → Browser */
const _spSearch2=Spotlight.search;
Spotlight.search=async function(q){await _spSearch2.call(Spotlight,q);const last=Spotlight.items[Spotlight.items.length-1];
  if(last&&/^Search the web/.test(last.label)){const u="https://duckduckgo.com/?q="+encodeURIComponent(q.trim());last.sub="Opens in Browser";last.go=()=>openInBrowser(u);Spotlight.draw()}};
