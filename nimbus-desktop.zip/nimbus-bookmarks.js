/* Nimbus Desktop — Browser bookmarks, Favourites bar, history, share menu (Install as App), and
   "stay in Nimbus": outside websites open in a Safari window beside Nimbus instead of a full-screen pop-up.
   Loaded last; starts the desktop. */
"use strict";

document.head.appendChild(html(`<style>
.br-favbar{display:flex;gap:2px;padding:3px 8px 5px;background:var(--field);overflow-x:auto;flex:none;align-items:center;border-bottom:1px solid var(--hair)}
.br-favbar:empty{display:none}
.br-chip{display:flex;align-items:center;gap:6px;padding:4px 9px;border-radius:7px;font-size:12px;white-space:nowrap;cursor:default;max-width:170px;color:var(--text)}
.br-chip:hover{background:var(--hover)}
.br-chip span{overflow:hidden;text-overflow:ellipsis}
.br-chip .ic,.br-chip .fav-ic{width:16px;height:16px;flex:none}
.br-star{border:0;background:none;color:var(--text3);font-size:15px;padding:0 2px;cursor:pointer;line-height:1}
.br-star.on{color:#ff9f0a}
.bm-panel{position:absolute;top:0;right:0;bottom:0;width:min(340px,90%);z-index:15;background:var(--glass-strong);border-left:1px solid var(--hair);box-shadow:-10px 0 30px rgba(0,0,0,.15);display:flex;flex-direction:column;
  backdrop-filter:blur(30px);-webkit-backdrop-filter:blur(30px);animation:bmin .2s ease}
@keyframes bmin{from{transform:translateX(30px);opacity:0}}
.bm-panel .seg{margin:10px 12px 6px}
.bm-panel .bl{flex:1;overflow:auto;padding:0 8px 12px}
.bm-panel .bi{display:flex;gap:10px;align-items:center;padding:7px 8px;border-radius:9px;cursor:default}
.bm-panel .bi:hover{background:var(--hover)}
.bm-panel .bi .ic,.bm-panel .bi .fav-ic{width:24px;height:24px;flex:none}
.bm-panel .bi b{font-size:13px;font-weight:500;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bm-panel .bi small{font-size:11.5px;color:var(--text3);display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bm-panel h6{margin:12px 8px 4px;font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.05em}
</style>`));

/* ================= "stay in Nimbus": open outside sites in a Safari window ================= */
const isStandalone=()=>{try{return matchMedia("(display-mode: standalone)").matches||matchMedia("(display-mode: fullscreen)").matches||!!navigator.standalone}catch(e){return false}};
const extMode=()=>S.extOpen||"safari";
const _openLink2=openLink;
openLink=function(url){
  if(/^https?:/i.test(url)&&isStandalone()&&extMode()==="safari"){
    let left=false;const mark=()=>{left=true};window.addEventListener("blur",mark,{once:true});document.addEventListener("visibilitychange",mark,{once:true});
    const a=document.createElement("a");a.href="x-safari-"+url;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>{window.removeEventListener("blur",mark);if(!left&&document.visibilityState==="visible")_openLink2(url)},1600);return}
  _openLink2(url)};
document.addEventListener("click",e=>{const a=e.target.closest&&e.target.closest("a[href]");if(!a||e.defaultPrevented)return;const h=a.getAttribute("href")||"";
  if(/^https?:/i.test(h)&&a.target==="_blank"&&isStandalone()&&extMode()==="safari"){e.preventDefault();openLink(a.href)}},true);
/* nothing inside Nimbus may take over the whole screen unless allowed */
document.addEventListener("fullscreenchange",()=>{if(document.fullscreenElement&&document.fullscreenElement.tagName==="IFRAME"&&!S.allowFullscreen){try{document.exitFullscreen()}catch(e){}}});

/* ================= bookmarks data ================= */
const BM={
  list(){if(!S.bookmarks){S.bookmarks=[["Wikipedia","https://en.m.wikipedia.org/"],["YouTube","https://m.youtube.com/"],["Photopea","https://www.photopea.com/"],["Excalidraw","https://excalidraw.com/"],
      ["Gmail","https://mail.google.com/"],["Google","https://www.google.com/"],["DuckDuckGo","https://duckduckgo.com/"],["Hacker News","https://news.ycombinator.com/"]].map(([t,u])=>({id:uid(),title:t,url:u,bar:true}));saveSettings()}return S.bookmarks},
  bar(){return BM.list().filter(b=>b.bar)},
  find(u){const n=x=>(x||"").replace(/\/+$/,"").replace(/^https?:\/\/(www\.)?/,"");return BM.list().find(b=>n(b.url)===n(u))},
  add(title,url,bar){const b={id:uid(),title,url,bar:!!bar};BM.list().push(b);BM.save();return b},
  remove(b){S.bookmarks=BM.list().filter(x=>x!==b);BM.save()},
  save(){saveSettings();BM.syncStart();BM.listeners.forEach(f=>{try{f()}catch(e){}})},
  listeners:new Set(),
  syncStart(){BR_FAVS.splice(0,BR_FAVS.length,...BM.bar().map(b=>[b.title,b.url,favColor(hostOf(b.url)),(b.title[0]||"?").toUpperCase()]))}
};
const bmIcon=b=>faviconIcon("bm"+b.id,b.title,b.url)();
async function bookmarkDialog(url,b){const isNew=!b;
  let barVal=!b||b.bar;const pr=UI.dialog({title:isNew?"Add Bookmark":"Edit Bookmark",text:esc(hostOf(url)),fields:[{value:b?b.title:hostOf(url).split(".").slice(-2,-1)[0]?.replace(/^\w/,c=>c.toUpperCase())||hostOf(url),ph:"Name"},{value:b?b.url:url,ph:"Address",type:"url"}],ok:isNew?"Add":"Save",
    extra:`<label style="display:flex;gap:8px;align-items:center;font-size:13px;justify-content:center"><input type="checkbox" id="bm-bar" ${!b||b.bar?"checked":""}> Show in Favourites bar</label>`});
  const cb=$("#bm-bar");if(cb)cb.onchange=()=>{barVal=cb.checked};const r=await pr;
  if(!r)return null;const bar=barVal;
  if(isNew)return BM.add(r[0].trim()||hostOf(url),normalizeUrl(r[1])||url,bar!==false);
  b.title=r[0].trim()||b.title;b.url=normalizeUrl(r[1])||b.url;BM.save();return b}

/* ================= Browser additions ================= */
const _webCreate2=APPS.web.create;
APPS.web.create=function(w,opts){const hooks=_webCreate2(w,opts);
  const urlIn=$("[data-url]",w.body),bar=$(".br-bar",w.body);
  const go=(u,newTab)=>{if(newTab)return hooks.openUrl(u);urlIn.value=u;urlIn.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:true}))};
  const curUrl=()=>{const v=urlIn.value.trim();return /^https?:\/\//.test(v)?v:""};
  /* star inside the address field */
  const star=html(`<button class="br-star" title="Bookmark this page">☆</button>`);$(".br-url",w.body).appendChild(star);
  const updStar=()=>{const u=curUrl();const b=u&&BM.find(u);star.textContent=b?"★":"☆";star.classList.toggle("on",!!b);star.style.visibility=u?"visible":"hidden"};
  star.onclick=async()=>{const u=curUrl();if(!u)return;const b=BM.find(u);if(b){const r=star.getBoundingClientRect();UI.menu([{label:"Edit Bookmark…",action:()=>bookmarkDialog(u,b)},{label:b.bar?"Remove from Favourites Bar":"Add to Favourites Bar",action:()=>{b.bar=!b.bar;BM.save()}},{label:"Remove Bookmark",action:()=>BM.remove(b)}],r.left-150,r.bottom+4)}
    else{await bookmarkDialog(u)}updStar()};
  /* favourites bar */
  const fb=html(`<div class="br-favbar"></div>`);bar.after(fb);
  const drawBar=()=>{fb.style.display=S.showFavBar===false?"none":"";fb.innerHTML="";BM.bar().forEach(b=>{const c=html(`<div class="br-chip" title="${esc(b.url)}">${bmIcon(b)}<span>${esc(b.title)}</span></div>`);
      c.onclick=()=>go(b.url);longPress(c,e=>UI.menu([{label:"Open",action:()=>go(b.url)},{label:"Open in New Tab",action:()=>go(b.url,true)},{label:"Open in Safari",action:()=>openLink(b.url)},"-",
        {label:"Install as App…",action:()=>installSheet(w.el,b.url)},{label:"Edit…",action:()=>bookmarkDialog(b.url,b)},{label:"Remove from Bar",action:()=>{b.bar=false;BM.save()}},{label:"Delete Bookmark",action:()=>BM.remove(b)}],e.clientX,e.clientY));fb.appendChild(c)});updStar()};
  /* bookmarks / history panel */
  const bmBtn=html(`<button class="btn icon" title="Bookmarks & History"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linejoin="round"><path d="M4 5a2 2 0 0 1 2-2h5v18H6a2 2 0 0 1-2-2zM11 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/><path d="M14 7h3M14 11h3"/></svg></button>`);
  const share=$("[data-a=share]",w.body);share.before(bmBtn);
  let panel=null;
  const openPanel=async(tab="bookmarks",q="")=>{panel&&panel.remove();panel=html(`<div class="bm-panel"><div style="display:flex;gap:8px;align-items:center;padding:10px 12px 0"><input class="field" data-q placeholder="Search" value="${esc(q)}" style="padding:6px 10px"><button class="btn icon" data-x>✕</button></div>
      <div class="seg"><button class="${tab==="bookmarks"?"on":""}" data-t="bookmarks">Bookmarks</button><button class="${tab==="history"?"on":""}" data-t="history">History</button></div><div class="bl" data-l></div></div>`);
    $(".br-view",w.body).parentElement.style.position="relative";$(".br",w.body).appendChild(panel);
    const L=$("[data-l]",panel),qi=$("[data-q]",panel);
    const render=async()=>{const qq=qi.value.trim().toLowerCase();const match=x=>!qq||(x.title+" "+x.url).toLowerCase().includes(qq);
      if(tab==="bookmarks"){const bar=BM.list().filter(b=>b.bar&&match(b)),other=BM.list().filter(b=>!b.bar&&match(b));
        L.innerHTML=`<h6>Favourites Bar</h6>${bar.map(b=>row(b)).join("")||`<div class="muted" style="font-size:12px;padding:4px 8px">None</div>`}<h6>Other Bookmarks</h6>${other.map(b=>row(b)).join("")||`<div class="muted" style="font-size:12px;padding:4px 8px">Tap ☆ in the address bar to bookmark a page.</div>`}`;
        $$(".bi",L).forEach(el=>{const b=BM.list().find(x=>x.id===el.dataset.id);el.onclick=()=>{go(b.url);panel.remove()};
          longPress(el,e=>UI.menu([{label:"Open in New Tab",action:()=>go(b.url,true)},{label:"Open in Safari",action:()=>openLink(b.url)},{label:"Install as App…",action:()=>installSheet(w.el,b.url)},"-",{label:"Edit…",action:()=>bookmarkDialog(b.url,b).then(render)},
            {label:b.bar?"Remove from Favourites Bar":"Add to Favourites Bar",action:()=>{b.bar=!b.bar;BM.save();render()}},{label:"Delete",action:()=>{BM.remove(b);render()}}],e.clientX,e.clientY))})}
      else{const h=(await DB.get("web-recent",[])).filter(u=>!qq||u.toLowerCase().includes(qq));
        L.innerHTML=h.map(u=>`<div class="bi" data-u="${esc(u)}">${faviconIcon("h"+hostOf(u).replace(/\W/g,""),hostOf(u),u)()}<div style="min-width:0"><b>${esc(hostOf(u))}</b><small>${esc(u.replace(/^https?:\/\//,""))}</small></div></div>`).join("")||`<div class="muted" style="font-size:12px;padding:8px">No history yet.</div>`;
        if(h.length)L.insertAdjacentHTML("beforeend",`<button class="btn" data-clearh style="margin:10px 8px">Clear History</button>`);
        $$(".bi",L).forEach(el=>{el.onclick=()=>{go(el.dataset.u);panel.remove()};longPress(el,e=>UI.menu([{label:"Open in New Tab",action:()=>go(el.dataset.u,true)},{label:"Add Bookmark…",action:()=>bookmarkDialog(el.dataset.u)},{label:"Install as App…",action:()=>installSheet(w.el,el.dataset.u)}],e.clientX,e.clientY))});
        const ch=$("[data-clearh]",L);ch&&(ch.onclick=async()=>{await DB.set("web-recent",[]);render()})}};
    const row=b=>`<div class="bi" data-id="${b.id}">${bmIcon(b)}<div style="min-width:0"><b>${esc(b.title)}</b><small>${esc(b.url.replace(/^https?:\/\//,""))}</small></div></div>`;
    qi.oninput=render;$("[data-x]",panel).onclick=()=>panel.remove();$$("[data-t]",panel).forEach(t=>t.onclick=()=>openPanel(t.dataset.t,qi.value));render()};
  bmBtn.onclick=()=>{if(panel&&panel.isConnected)panel.remove();else openPanel()};
  /* share menu */
  const shareNew=share.cloneNode(true);share.replaceWith(shareNew);shareNew.title="Share & more";
  shareNew.onclick=()=>{const u=curUrl();const r=shareNew.getBoundingClientRect();const b=u&&BM.find(u);UI.menu([
    {label:"Install as App…",disabled:!u,action:()=>installSheet(w.el,u)},
    {label:b?"Edit Bookmark…":"Add Bookmark…",disabled:!u,action:()=>bookmarkDialog(u,b||undefined).then(updStar)},
    {label:b&&b.bar?"Remove from Favourites Bar":"Add to Favourites Bar",disabled:!u,action:()=>{if(b){b.bar=!b.bar;BM.save()}else{BM.add(hostOf(u),u,true)}}},
    {label:"Copy Link",disabled:!u,action:()=>{try{navigator.clipboard.writeText(u);UI.toast("Link copied",u)}catch(e){}}},"-",
    {label:extMode()==="safari"?"Open in Safari Window":"Open in Safari",disabled:!u,action:()=>openLink(u)},
    {label:(S.showFavBar===false?"Show":"Hide")+" Favourites Bar",action:()=>{S.showFavBar=S.showFavBar===false;saveSettings();drawBar()}},
    {label:"Bookmarks & History",action:()=>openPanel()}],r.right-230,r.bottom+4)};
  /* refresh star when the page changes */
  const titleEl=$(".title",w.el);const mo=new MutationObserver(updStar);mo.observe(titleEl,{childList:true,characterData:true,subtree:true});
  /* favicons on the start page favourites */
  const so=new MutationObserver(()=>{$$(".favs .fav:not([data-ico])",w.body).forEach(a=>{a.dataset.ico=1;const u=a.dataset.go||a.getAttribute("href");if(!u)return;const i=$("i",a);if(i){const t=html(`<span style="width:60px;height:60px;display:block">${faviconIcon("sf"+hostOf(u).replace(/\W/g,""),a.textContent.trim(),u)()}</span>`);i.replaceWith(t)}})});
  so.observe(w.body,{childList:true,subtree:true});
  BM.listeners.add(drawBar);drawBar();
  const kh=e=>{if(WM.active!==w)return;if((e.metaKey||e.ctrlKey)&&e.key==="d"){e.preventDefault();star.click()}if((e.metaKey||e.ctrlKey)&&e.shiftKey&&(e.key==="b"||e.key==="B")){e.preventDefault();S.showFavBar=S.showFavBar===false;saveSettings();drawBar()}};
  document.addEventListener("keydown",kh);
  const _c=hooks.close;hooks.close=()=>{BM.listeners.delete(drawBar);mo.disconnect();so.disconnect();document.removeEventListener("keydown",kh);_c&&_c()};return hooks};

/* ================= settings: Browser section ================= */
const _setCreate3=APPS.settings.create;
APPS.settings.create=function(w,opts){const hooks=_setCreate3(w,opts);
  const obs=new MutationObserver(()=>{const P=$("[data-pane]",w.body);if(!P||P.dataset.brs||!$("[data-ds]",P))return;P.dataset.brs=1;
    P.insertAdjacentHTML("beforeend",`<h3 style="margin:0;font-size:14px">Browser</h3><div class="set-group">
      <div class="set-row"><div><label>Open outside websites in</label><small>Sites that can't show inside Nimbus (banks, Google, Microsoft…). <b>Safari window</b> opens real Safari as its own window next to Nimbus instead of a full-screen pop-up — turn on iPad Settings › Multitasking & Gestures › Windowed Apps.</small></div>
        <div class="seg">${[["safari","Safari window"],["sheet","Pop-up"]].map(([k,l])=>`<button class="${extMode()===k?"on":""}" data-ext="${k}">${l}</button>`).join("")}</div></div>
      <div class="set-row"><div><label>Let pages go full screen</label><small>Off keeps videos and web apps inside their Nimbus window</small></div><div class="toggle ${S.allowFullscreen?"on":""}" data-fs></div></div>
      <div class="set-row"><div><label>Show Favourites bar</label><small>Bookmarks under the address bar (⇧⌘B)</small></div><div class="toggle ${S.showFavBar!==false?"on":""}" data-fb></div></div></div>`);
    $$("[data-ext]",P).forEach(b=>b.onclick=()=>{S.extOpen=b.dataset.ext;$$("[data-ext]",P).forEach(x=>x.classList.toggle("on",x===b));saveSettings()});
    $("[data-fs]",P).onclick=e=>{S.allowFullscreen=!S.allowFullscreen;e.currentTarget.classList.toggle("on",S.allowFullscreen);saveSettings()};
    $("[data-fb]",P).onclick=e=>{S.showFavBar=S.showFavBar===false;e.currentTarget.classList.toggle("on",S.showFavBar!==false);saveSettings();BM.listeners.forEach(f=>f())}});
  obs.observe(w.body,{childList:true,subtree:true});const _c=hooks.close;hooks.close=()=>{obs.disconnect();_c&&_c()};return hooks};

/* ================= boot ================= */
const _bootBM=window.NIMBUS_BOOT;
window.NIMBUS_BOOT=async function(){await DB.open();await loadSettings();BM.list();BM.syncStart();await _bootBM()};
window.NIMBUS_BOOT();
