NIMBUS DESKTOP — self-hosted version
====================================
Hosting it yourself unlocks: true full-screen Home Screen app, offline use,
Messages/Mail hand-off links, file export, and optional internet inside Linux.

EASIEST (from the iPad, no computer): Netlify Drop
 1. In Safari go to https://app.netlify.com/drop (free account).
 2. Upload this zip (or the unzipped folder) from the Files app.
 3. Open the https://....netlify.app link it gives you.
 4. Share > Add to Home Screen.

GOOGLE FIREBASE HOSTING (needs a computer with Node.js):
   npm install -g firebase-tools
   firebase login
   firebase init hosting      (public directory: this folder, single-page: No)
   firebase deploy

GITHUB PAGES: create a repo, upload these files, Settings > Pages > Deploy from branch.

WHAT'S NEW IN 4.0 (check: Settings > About, or the cloud menu > What's New):
- Linux opens as a Nimbus Terminal: Tiny Core boots straight to a clean terminal that uses the iPad
  keyboard (signs in automatically). The old graphical Tiny Core is still there: Linux window > Classic desktop.
- What's New screen + update checks: Nimbus reads version.json from your site and offers "Update"
  when a newer version is uploaded. To release a new version, bump "version" in version.json and
  window.NIMBUS_VERSION at the top of index.html.
- Nimbus's own files now load network-first, so new uploads show up on the next launch.

WHAT'S NEW IN 3.7: Google Drive and OneDrive inside Nimbus (Files > Cloud): browse, open in Nimbus apps,
Save writes back to the cloud, upload, new folder, rename, delete. PDF / video / audio Viewer.
Setup: add the 'drive' scope (Google) and 'Files.ReadWrite.All' permission (Microsoft), then reconnect.

WHAT'S NEW IN 3.6: Browser bookmarks, Favourites bar, History, share menu with Install as App;
outside websites open in a Safari window beside Nimbus instead of a full-screen pop-up; pages can't go full screen
(Settings > Desktop & Dock > Browser).

WHAT'S NEW IN 3.5: Reminders app + desktop widget (natural dates, alerts, Apple Reminders via Shortcuts),
Launchpad > iPad Apps (open real iPad apps), App Gallery + Install as App in Browser with real site icons,
Liquid Glass look + icon styles (Settings > Appearance), Notification Center (tap the clock), Spotlight actions.

WHAT'S NEW IN 3.0: Mail shows real emails for Gmail and Outlook/Hotmail/365 accounts (read, reply, forward,
send with attachments, archive, delete) after a one-time Connection setup; Browser with tabs that opens pages inside
Nimbus; web apps open in their own Nimbus windows when the site allows it.
IMPORTANT FOR UPDATES: keep the same file name (nimbus-desktop.zip) so your GitHub address stays the same —
Google/Microsoft sign-in is registered to that exact address.

WHAT'S NEW IN 2.2: Mail Hub for all your email accounts (Gmail, Outlook, Yahoo, iCloud...),
New Message window with a From picker and signatures, Mail widget, 'Email this file', Mission Control (F3).

WHAT'S NEW IN 2.1: Word, Excel and ArtCraft in the Dock (open in Safari), App Installer
(install offline web apps like VectorCraft from their .zip; needs this self-hosted version), Add your own web apps.

WHAT'S NEW IN 2.0: Documents (.docx), Sheets (.xlsx), Code (Python/JS/HTML),
permanent Linux drive, Linux Shared folder, Launchpad, Downloads stack, lock screen.

Linux disk: download TinyCore-current.iso (32-bit x86) from
http://www.tinycorelinux.net/17.x/x86/release/ and choose it in the Linux app.
