/* Nimbus Desktop — App Installer, web-app shortcuts (Word, Excel, ArtCraft) and offline web-app packages
   (e.g. VectorCraft's official web build). Loaded after nimbus-extra.js. */
"use strict";

document.head.appendChild(html(`<style>
.inst{flex:1;overflow:auto;padding:24px 28px;line-height:1.5}
.inst h2{margin:0 0 4px;font-size:20px}.inst h3{margin:20px 0 6px;font-size:14px}
.inst ol{padding-left:20px;margin:6px 0}.inst li{margin:4px 0}
.inst code{font-family:var(--mono);background:var(--field);padding:1px 6px;border-radius:5px;font-size:12px;word-break:break-all}
.inst .card{display:flex;gap:14px;align-items:center;background:var(--field);border-radius:14px;padding:12px 14px;margin:8px 0}
.inst .card .ic{width:46px;height:46px;flex:none}.inst .card .grow{flex:1;min-width:0}
.inst .card small{color:var(--text3);display:block}
.inst .warn{background:color-mix(in srgb,#ff9f0a 16%,transparent);border-radius:12px;padding:10px 14px;font-size:12.5px}
.inst .prog{height:6px;border-radius:3px;background:var(--field);overflow:hidden;margin-top:8px}.inst .prog i{display:block;height:100%;width:0;background:var(--accent);transition:width .2s}
.appframe{flex:1;border:0;background:#fff;width:100%;height:100%}
#launchpad .lp.add .ic{opacity:.85}
</style>`));

/* ---------- icons ---------- */
Object.assign(ICON,{
  wordweb:()=>squircle("ww","#4f8cff","#1d4ed8",`<rect x="17" y="13" width="26" height="34" rx="3" fill="#fff"/><path d="M22 22h16M22 28h16M22 34h11" stroke="#1d4ed8" stroke-width="2.4" stroke-linecap="round"/><path d="M36 41a8 8 0 0 1 8-8 9 9 0 0 1 8.7 6.7A6 6 0 0 1 51 51H38a6 6 0 0 1-2-10z" fill="#bfdbfe" stroke="#fff" stroke-width="1.5"/>`),
  excelweb:()=>squircle("xw","#34d399","#047857",`<rect x="15" y="14" width="28" height="32" rx="3" fill="#fff"/><path d="M15 24h28M15 32h28M15 40h28M25 14v32M34 14v32" stroke="#047857" stroke-width="1.8"/><path d="M36 41a8 8 0 0 1 8-8 9 9 0 0 1 8.7 6.7A6 6 0 0 1 51 51H38a6 6 0 0 1-2-10z" fill="#a7f3d0" stroke="#fff" stroke-width="1.5"/>`),
  artcraft:()=>squircle("ac","#ff9a62","#d9387a",`<path d="M32 13c-11 0-20 8.3-20 18.5S20.6 50 30 50c3 0 3.6-2.2 2.6-4.1-1.2-2.3.2-4.4 2.9-4.4H40c6.6 0 12-4.7 12-11C52 20.6 43 13 32 13z" fill="#fff"/><circle cx="22" cy="29" r="3.4" fill="#ff6b6b"/><circle cx="28" cy="21" r="3.4" fill="#ffd43b"/><circle cx="37.5" cy="21" r="3.4" fill="#51cf66"/><circle cx="43.5" cy="29" r="3.4" fill="#4dabf7"/>`),
  vectorcraft:()=>squircle("vc","#2b2f3a","#0b0d12",`<path d="M14 44C22 20 42 20 50 44" fill="none" stroke="#64d2ff" stroke-width="2.5"/><circle cx="14" cy="44" r="3.6" fill="#fff"/><circle cx="50" cy="44" r="3.6" fill="#fff"/><path d="M32 14l6 11-6 13-6-13z" fill="#ff6b9a"/><circle cx="32" cy="27" r="2" fill="#0b0d12"/><path d="M20 22h10M34 22h10" stroke="#9aa3b5" stroke-width="1.6"/><rect x="18" y="20" width="4" height="4" fill="#9aa3b5"/><rect x="42" y="20" width="4" height="4" fill="#9aa3b5"/>`),
  installer:()=>squircle("in","#7c8cff","#3b3fd6",`<path d="M14 34v10a4 4 0 0 0 4 4h28a4 4 0 0 0 4-4V34" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/><path d="M32 13v23M24 28l8 8 8-8" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>`),
  addapp:()=>`<svg class="ic" viewBox="0 0 64 64"><rect x="3" y="3" width="58" height="58" rx="15" fill="rgba(255,255,255,.18)" stroke="rgba(255,255,255,.7)" stroke-width="2" stroke-dasharray="5 4"/><path d="M32 20v24M20 32h24" stroke="#fff" stroke-width="4" stroke-linecap="round"/></svg>`
});
const letterIcon=(id,name,color)=>()=>squircle("u"+id,color,shade(color,-0.35),`<text x="32" y="42" font-size="26" font-weight="700" text-anchor="middle" fill="#fff" font-family="-apple-system,sans-serif">${esc((name||"?").trim().slice(0,2))}</text>`);
function shade(hex,amt){const n=parseInt(hex.slice(1),16);let r=n>>16,g=(n>>8)&255,b=n&255;const f=v=>Math.max(0,Math.min(255,Math.round(v+(amt<0?v*amt:(255-v)*amt))));return "#"+[f(r),f(g),f(b)].map(v=>v.toString(16).padStart(2,"0")).join("")}

/* ---------- web-app shortcuts ---------- */
const WEBAPPS_BUILTIN=[
  {id:"word",name:"Word",icon:"wordweb",url:"https://www.office.com/launch/word",note:"Microsoft Word on the web — free with a Microsoft account. Opens in Safari."},
  {id:"excel",name:"Excel",icon:"excelweb",url:"https://www.office.com/launch/excel",note:"Microsoft Excel on the web — free with a Microsoft account. Opens in Safari."},
  {id:"artcraft",name:"ArtCraft",icon:"artcraft",url:"https://getartcraft.com/",note:"ArtCraft's AI image & video studio. Opens in Safari."}
];
function registerWebApp(a){
  if(!ICON[a.icon])ICON[a.icon]=letterIcon(a.id,a.name,a.color||"#5e5ce6");
  APPS[a.id]={name:a.name,icon:a.icon,url:a.url,webapp:true,user:!!a.user,
    launch(){openLink(a.url);UI.toast(`Opening ${a.name}`,"In Safari",a.icon);return false},create(){}}}
WEBAPPS_BUILTIN.forEach(registerWebApp);
function loadUserWebApps(){(S.webapps||[]).forEach(a=>registerWebApp({...a,icon:"u_"+a.id,user:true}))}

/* ---------- offline web-app packages (installed from a .zip) ---------- */
const APPCACHE="nimbus-apps";
const MIME={html:"text/html",htm:"text/html",js:"text/javascript",mjs:"text/javascript",wasm:"application/wasm",css:"text/css",json:"application/json",
  svg:"image/svg+xml",png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp",ico:"image/x-icon",ttf:"font/ttf",otf:"font/otf",woff:"font/woff",woff2:"font/woff2",
  txt:"text/plain",map:"application/json",xml:"application/xml",webmanifest:"application/manifest+json",mp3:"audio/mpeg",wav:"audio/wav",ogg:"audio/ogg",mp4:"video/mp4"};
const PKG={
  canInstall(){return !SANDBOXED&&"serviceWorker" in navigator&&"caches" in window&&!!navigator.serviceWorker.controller},
  why(){if(SANDBOXED)return "This preview page can't install offline apps (it isn't allowed to run the helper that serves them). Use the installed version of Nimbus — the self-hosted one you add to your Home Screen.";
    if(!("serviceWorker" in navigator))return "This browser doesn't support offline apps.";
    if(!navigator.serviceWorker.controller)return "Nimbus is still setting up offline support. Reload Nimbus once, then try again.";return ""},
  async list(){return await DB.get("installed-apps",[])},
  async loadZipLib(){if(window.fflate)return;const d=window.define;try{window.define=undefined;await loadJS("lib/fflate.js")}finally{window.define=d}},
  async install(file,onProg){
    await PKG.loadZipLib();onProg&&onProg(5,"Reading package…");
    const files=fflate.unzipSync(new Uint8Array(await file.arrayBuffer()));
    const names=Object.keys(files).filter(n=>!n.endsWith("/")&&!/(^|\/)(__MACOSX|\.DS_Store)/.test(n));
    const idx=names.filter(n=>/(^|\/)index\.html$/i.test(n)).sort((a,b)=>a.split("/").length-b.split("/").length)[0];
    if(!idx)throw new Error("This .zip doesn't contain a web app (no index.html).");
    const prefix=idx.slice(0,idx.length-"index.html".length);
    const base=(file.name||"app").replace(/\.zip$/i,"");
    const lower=base.toLowerCase();
    const known=/vectorcraft/.test(lower)?{id:"vectorcraft",name:"VectorCraft",icon:"vectorcraft"}:null;
    const id=known?known.id:"pkg_"+lower.replace(/[^a-z0-9]+/g,"-").replace(/-+$/,"").slice(0,40);
    let name=known?known.name:base.replace(/[-_]v?\d[\w.]*$/,"").replace(/[-_]+/g," ").replace(/\b\w/g,c=>c.toUpperCase()).trim()||"App";
    const root=new URL(`installed/${id}/`,location.href).href;
    await PKG.remove(id,true);
    const cache=await caches.open(APPCACHE);let done=0,bytes=0;const todo=names.filter(n=>n.startsWith(prefix));
    for(const n of todo){const rel=n.slice(prefix.length);const ext=(rel.split(".").pop()||"").toLowerCase();const data=files[n];bytes+=data.length;
      await cache.put(new Request(root+rel),new Response(data,{headers:{"Content-Type":MIME[ext]||"application/octet-stream","Content-Length":String(data.length)}}));
      done++;if(done%5===0||done===todo.length)onProg&&onProg(5+Math.round(done/todo.length*93),`Installing ${done}/${todo.length}…`)}
    const meta={id,name,icon:known?known.icon:"u_"+id,color:"#5e5ce6",entry:"index.html",root,size:bytes,files:todo.length,t:Date.now(),src:file.name};
    const list=(await PKG.list()).filter(x=>x.id!==id);list.push(meta);await DB.set("installed-apps",list);
    PKG.register(meta);if(!(S.pinned||[]).includes(id)){S.pinned=[...(S.pinned||[]),id];saveSettings()}rebuildDock();onProg&&onProg(100,"Installed");return meta},
  async remove(id,silent){
    try{const cache=await caches.open(APPCACHE);const root=new URL(`installed/${id}/`,location.href).href;for(const req of await cache.keys())if(req.url.startsWith(root))await cache.delete(req)}catch(e){}
    const list=(await PKG.list()).filter(x=>x.id!==id);await DB.set("installed-apps",list);
    if(!silent){if(id!=="vectorcraft")delete APPS[id];else registerVectorCraftPlaceholder();S.pinned=(S.pinned||[]).filter(x=>x!==id||id==="vectorcraft");saveSettings();rebuildDock()}},
  register(m){if(!ICON[m.icon])ICON[m.icon]=letterIcon(m.id,m.name,m.color);
    APPS[m.id]={name:m.name,icon:m.icon,installed:m,w:1100,h:720,
      create(w){w.body.innerHTML=`<iframe class="appframe" allow="clipboard-read; clipboard-write; fullscreen" src="${esc(m.root+m.entry)}"></iframe>`;
        if(!navigator.serviceWorker||!navigator.serviceWorker.controller){w.body.innerHTML=`<div class="inst"><h2>${esc(m.name)}</h2><p>Offline support is still starting. Reload Nimbus, then open ${esc(m.name)} again.</p></div>`}
        return {resize(){}}}}}
};
function registerVectorCraftPlaceholder(){
  APPS.vectorcraft={name:"VectorCraft",icon:"vectorcraft",w:720,h:600,create(w){renderInstaller(w,{focus:"vectorcraft"})}}}
registerVectorCraftPlaceholder();

/* ---------- App Installer window ---------- */
APPS.installer={name:"App Installer",icon:"installer",w:760,h:640,single:true,
  create(w,opts){renderInstaller(w,opts);return {reopenInst(o){renderInstaller(w,o||{})}}},reopen(w,o){w.hooks.reopenInst&&w.hooks.reopenInst(o)}};
async function renderInstaller(w,opts={}){
  const inst=await PKG.list();const why=PKG.why();const vc=inst.find(x=>x.id==="vectorcraft");
  w.body.innerHTML=`<div class="inst">
    <h2>${opts.focus==="vectorcraft"&&!vc?"Install VectorCraft":"App Installer"}</h2>
    <p class="muted">Add apps to your Dock. <b>Offline apps</b> are real web-app packages that run inside Nimbus with no internet. <b>Web apps</b> are shortcuts that open in Safari.</p>
    ${why?`<div class="warn">⚠️ ${esc(why)}</div>`:""}
    <h3>VectorCraft — vector illustration (offline, built in Rust)</h3>
    <div class="card">${ICON.vectorcraft()}<div class="grow"><b>VectorCraft</b><small>${vc?`Installed · ${fmtSize(vc.size)} · ${vc.files} files`:"Not installed — about 5 MB download"}</small></div>
      ${vc?`<button class="btn primary" data-open="vectorcraft">Open</button><button class="btn" data-rm="vectorcraft">Remove</button>`:`<button class="btn primary" data-pick ${why?"disabled":""}>Choose .zip…</button>`}</div>
    ${vc?"":`<ol><li>In Safari, open <a href="https://github.com/storytold/vectorcraft/releases/latest" target="_blank" rel="noopener"><code>github.com/storytold/vectorcraft/releases/latest</code></a></li>
      <li>Under <b>Assets</b>, download <b>vectorcraft-web-<i>version</i>.zip</b> (the <i>web</i> one, not the Windows/Mac/Linux files). It goes to Files › Downloads.</li>
      <li>Come back and tap <b>Choose .zip…</b>. Nimbus unpacks it and adds VectorCraft to your Dock.</li></ol>
      <p class="muted" style="font-size:12px">VectorCraft is free and open source (MIT / Apache‑2.0) by the ArtCraft team. Other Craft apps that publish a web build (a .zip with an index.html) install the same way.</p>`}
    <div class="prog" data-prog style="display:none"><i></i></div><div class="muted" data-pmsg style="font-size:12px"></div>
    <h3>Other offline apps</h3>
    ${inst.filter(x=>x.id!=="vectorcraft").map(m=>`<div class="card">${(ICON[m.icon]||letterIcon(m.id,m.name,m.color))()}<div class="grow"><b>${esc(m.name)}</b><small>${fmtSize(m.size)} · from ${esc(m.src||"zip")}</small></div><button class="btn primary" data-open="${m.id}">Open</button><button class="btn" data-rm="${m.id}">Remove</button></div>`).join("")||`<p class="muted" style="font-size:12.5px">None yet.</p>`}
    <button class="btn" data-pick2 ${why?"disabled":""}>${SVG.imp} Install another app from .zip…</button>
    <h3>Web apps (open in Safari)</h3>
    ${[...WEBAPPS_BUILTIN,...(S.webapps||[]).map(a=>({...a,icon:"u_"+a.id,user:true}))].map(a=>`<div class="card">${(ICON[a.icon]||letterIcon(a.id,a.name,a.color))()}<div class="grow"><b>${esc(a.name)}</b><small>${esc(a.note||a.url)}</small></div>
      <button class="btn" data-pin="${a.id}">${(S.pinned||[]).includes(a.id)?"Remove from Dock":"Keep in Dock"}</button>${a.user?`<button class="btn" data-delweb="${a.id}">Delete</button>`:""}</div>`).join("")}
    <button class="btn" data-addweb>${SVG.plus} Add a web app…</button>
    <p class="muted" style="font-size:12px;margin-top:18px">Ideas: Photopea (photopea.com), Canva, Graphite (editor.graphite.rs), Figma, Google Docs, Notion.</p></div>`;
  const prog=$("[data-prog]",w.body),pmsg=$("[data-pmsg]",w.body);
  const doPick=()=>pickFiles(async f=>{if(!f[0])return;prog.style.display="";try{const m=await PKG.install(f[0],(p,t)=>{$("i",prog).style.width=p+"%";pmsg.textContent=t});
      UI.toast(`${m.name} installed`,"Added to your Dock",m.icon);renderInstaller(w,{})}catch(e){pmsg.textContent="⚠️ "+e.message;prog.style.display="none"}},".zip,application/zip");
  $$("[data-pick],[data-pick2]",w.body).forEach(b=>b.onclick=doPick);
  $$("[data-open]",w.body).forEach(b=>b.onclick=()=>{const id=b.dataset.open;if(w.app===id){WM.close(w);setTimeout(()=>WM.open(id),200)}else WM.open(id)});
  $$("[data-rm]",w.body).forEach(b=>b.onclick=async()=>{const m=inst.find(x=>x.id===b.dataset.rm);if(await UI.confirm(`Remove ${m?m.name:"app"}?`,"Its files are deleted from this iPad.","Remove",true)){await PKG.remove(b.dataset.rm);renderInstaller(w,opts)}});
  $$("[data-pin]",w.body).forEach(b=>b.onclick=()=>{const id=b.dataset.pin;S.pinned=(S.pinned||[]).includes(id)?S.pinned.filter(x=>x!==id):[...(S.pinned||[]),id];saveSettings();rebuildDock();renderInstaller(w,opts)});
  $$("[data-delweb]",w.body).forEach(b=>b.onclick=()=>{const id=b.dataset.delweb;S.webapps=(S.webapps||[]).filter(a=>a.id!==id);S.pinned=(S.pinned||[]).filter(x=>x!==id);delete APPS[id];saveSettings();rebuildDock();renderInstaller(w,opts)});
  $("[data-addweb]",w.body).onclick=()=>addWebAppDialog().then(ok=>ok&&renderInstaller(w,opts));
  if(w.app==="vectorcraft"&&vc){WM.close(w);setTimeout(()=>WM.open("vectorcraft"),200)}
}
async function addWebAppDialog(){
  const r=await UI.dialog({title:"Add a Web App",text:"It gets its own icon in Launchpad and the Dock, and opens in Safari.",fields:[{ph:"Name (e.g. Photopea)"},{ph:"Website (e.g. photopea.com)",type:"url"}],ok:"Add"});
  if(!r||!r[0].trim()||!r[1].trim())return false;let url=r[1].trim();if(!/^https?:\/\//i.test(url))url="https://"+url;
  const id="web_"+uid();const colors=["#5e5ce6","#ff375f","#ff9f0a","#30d158","#0a84ff","#bf5af2","#64d2ff","#ff6b6b"];
  const a={id,name:r[0].trim(),url,color:colors[(S.webapps||[]).length%colors.length]};
  S.webapps=[...(S.webapps||[]),a];S.pinned=[...(S.pinned||[]),id];saveSettings();registerWebApp({...a,icon:"u_"+id,user:true});rebuildDock();UI.toast("Added",`${a.name} is in your Dock`);return true}

/* ---------- Dock & Launchpad integration ---------- */
const BASE_DOCK=["files","launchpad","web","messages","mail","docs","sheets","code","linux","notes"];
function rebuildDock(){const pins=(S.pinned||[]).filter(id=>APPS[id]);DOCK_APPS.splice(0,DOCK_APPS.length,...BASE_DOCK,...pins,"settings");Dock.render()}
const _lpDraw=Launchpad.draw;
Launchpad.draw=function(q){_lpDraw(q);const g=$("[data-lpg]");
  const add=html(`<div class="lp add">${ICON.addapp()}<span>Add App</span></div>`);add.onclick=e=>{e.stopPropagation();Launchpad.close();WM.open("installer")};g.appendChild(add);
  $$(".lp[data-app]",g).forEach(el=>longPress(el,e=>{const id=el.dataset.app,a=APPS[id];const pinned=(S.pinned||[]).includes(id);
    UI.menu([{label:"Open",action:()=>{Launchpad.close();Dock.launch(id)}},
      ...(BASE_DOCK.includes(id)?[]:[{label:pinned?"Remove from Dock":"Keep in Dock",action:()=>{S.pinned=pinned?S.pinned.filter(x=>x!==id):[...(S.pinned||[]),id];saveSettings();rebuildDock()}}]),
      ...(a&&a.user?[{label:"Delete",action:()=>{S.webapps=(S.webapps||[]).filter(x=>x.id!==id);S.pinned=(S.pinned||[]).filter(x=>x!==id);delete APPS[id];saveSettings();rebuildDock();Launchpad.draw(q)}}]:[]),
      ...(a&&a.installed?[{label:"Uninstall",action:async()=>{await PKG.remove(id);Launchpad.draw(q)}}]:[])],e.clientX,e.clientY)}))};
/* Dock: long-press to remove pinned apps */
const _dockRender2=Dock.render;
Dock.render=function(){_dockRender2();$$("#dock .dk[data-app]").forEach(el=>{const id=el.dataset.app;if(BASE_DOCK.includes(id)||id==="settings")return;
  longPress(el,e=>UI.menu([{label:"Open",action:()=>Dock.launch(id,el)},{label:"Remove from Dock",action:()=>{S.pinned=(S.pinned||[]).filter(x=>x!==id);saveSettings();rebuildDock()}},{label:"App Installer…",action:()=>WM.open("installer")}],e.clientX,e.clientY-60))})};

/* ---------- settings default & boot ---------- */
const _bootCore=window.NIMBUS_BOOT;
window.NIMBUS_BOOT=async function(){
  await DB.open();await loadSettings();
  if(!S.pinned)S.pinned=["word","excel","artcraft","vectorcraft"];
  loadUserWebApps();(await PKG.list()).forEach(PKG.register);
  DOCK_APPS.splice(0,DOCK_APPS.length,...BASE_DOCK,...S.pinned.filter(id=>APPS[id]),"settings");
  await _bootCore()};
/* boot is started by nimbus-mail.js */
