/* =====================================================================
   Nimbus 4.1: iPad Folders in Files
   Link a whole folder from the iPad's Files app (On My iPad, iCloud Drive,
   Downloads, OneDrive/Google Drive providers, USB drives) and browse it
   inside Nimbus Files. iPadOS gives web apps a copy of the folder, not a live
   link, so: Refresh = choose the folder again (Nimbus syncs the differences),
   and edits go back with "Save Changes to iPad" (Save to Files / zip).
   ===================================================================== */
const IPAD_ROOT="ipadlinks";
const FOLDER_PICK_OK=(()=>{try{return "webkitdirectory" in document.createElement("input")}catch(e){return false}})();
const JUNK=/(^|\/)(\.DS_Store|\._[^/]*|Thumbs\.db|desktop\.ini|\.Trashes|\.Spotlight-V100|\.fseventsd)(\/|$)/i;

document.head.appendChild(Object.assign(document.createElement("style"),{textContent:`
.sidebar .si .sub{margin-left:auto;font-size:10.5px;opacity:.5;font-weight:400}
.ipf-note{margin:4px 8px 6px;font-size:11px;line-height:1.35;color:var(--text3)}
.ipf-banner{display:flex;gap:10px;align-items:center;padding:8px 12px;font-size:12px;background:color-mix(in srgb,var(--accent) 10%,transparent);border-bottom:1px solid var(--hair)}
.ipf-banner .btn{padding:4px 10px;font-size:12px}
.ipf-banner span{flex:1}
`}));

const IPF={
  async ensureRoot(){if(!(await DB.fs.get(IPAD_ROOT)))await DB.fs.put({id:IPAD_ROOT,parent:"hidden",name:"iPad Folders",type:"folder",mtime:Date.now()})},
  async links(){await IPF.ensureRoot();return (await DB.fs.children(IPAD_ROOT)).filter(e=>e.type==="folder").sort((a,b)=>a.name.localeCompare(b.name))},
  /* which linked folder (if any) an entry lives in */
  async linkOf(id){let e=await DB.fs.get(id);let guard=0;while(e&&guard++<64){if(e.parent===IPAD_ROOT)return e;e=await DB.fs.get(e.parent)}return null},
  pick(){return new Promise(res=>{const inp=document.createElement("input");inp.type="file";inp.multiple=true;
    if(FOLDER_PICK_OK){inp.webkitdirectory=true;inp.setAttribute("webkitdirectory","")}
    inp.style.display="none";document.body.appendChild(inp);
    inp.onchange=()=>{const f=[...inp.files];inp.remove();res(f)};
    inp.addEventListener("cancel",()=>{inp.remove();res([])});inp.click()})},
  /* split files into {root name, [{rel, file}]} */
  shape(files){files=files.filter(f=>!JUNK.test(f.webkitRelativePath||f.name));
    const withPath=files.filter(f=>f.webkitRelativePath&&f.webkitRelativePath.includes("/"));
    if(!withPath.length)return {root:null,items:files.map(f=>({rel:f.name,file:f}))};
    const root=withPath[0].webkitRelativePath.split("/")[0];
    return {root,items:files.map(f=>{const p=(f.webkitRelativePath||f.name).split("/");if(p[0]===root&&p.length>1)p.shift();return {rel:p.join("/"),file:f}})}},
  async folderFor(linkId,relDir,cache){if(!relDir)return linkId;if(cache[relDir])return cache[relDir];
    const parts=relDir.split("/");const name=parts.pop();const parent=await IPF.folderFor(linkId,parts.join("/"),cache);
    const kids=await DB.fs.children(parent);let f=kids.find(k=>k.type==="folder"&&k.name===name);
    if(!f){f={id:uid(),parent,name,type:"folder",mtime:Date.now(),ipad:{rel:relDir}};await DB.fs.put(f)}
    return cache[relDir]=f.id},
  /* every file under a linked folder, keyed by relative path */
  async index(linkId){const out={};const walk=async(id,pre)=>{for(const k of await DB.fs.children(id)){const rel=pre?pre+"/"+k.name:k.name;
      if(k.type==="folder"){await walk(k.id,rel)}else out[(k.ipad&&k.ipad.rel)||rel]=k}};await walk(linkId,"");return out},
  edited(e){return e.type==="file"&&(!e.ipad||!e.ipad.syncedAt||e.mtime>e.ipad.syncedAt+800)},
  async link(){
    const files=await IPF.pick();if(!files.length)return null;
    const {root,items}=IPF.shape(files);
    if(!root&&FOLDER_PICK_OK&&items.length===0)return null;
    const bytes=items.reduce((s,i)=>s+i.file.size,0);
    if(bytes>400*1048576&&!(await UI.confirm("This is a big folder",`It holds ${items.length} files (${fmtSize(bytes)}). Nimbus keeps a copy on this iPad, so it uses that much space. Link it anyway?`,"Link")))return null;
    await IPF.ensureRoot();
    const name=root||await UI.prompt("Name this folder","iPad Files")||"iPad Files";
    const existing=(await IPF.links()).find(l=>l.name===name);
    if(existing&&await UI.confirm(`“${name}” is already linked`,"Refresh it with these files instead of linking it twice?","Refresh"))return IPF.sync(existing,items);
    const link={id:uid(),parent:IPAD_ROOT,name:existing?await FS.uniqueName(IPAD_ROOT,name):name,type:"folder",mtime:Date.now(),ipad:{linkedAt:Date.now(),syncedAt:Date.now(),files:items.length,bytes,pathsOk:!!root}};
    await DB.fs.put(link);
    return IPF.sync(link,items,true)},
  async sync(link,items,fresh){
    const t0=Date.now();let added=0,updated=0,removed=0,kept=0,done=0;const cache={};
    const idx=fresh?{}:await IPF.index(link.id);const seen=new Set();
    UI.toast(fresh?"Linking folder…":"Refreshing…",`${link.name} · ${items.length} files`,"files");
    for(const {rel,file} of items){seen.add(rel);
      const dir=rel.includes("/")?rel.slice(0,rel.lastIndexOf("/")):"";const name=rel.split("/").pop();
      const cur=idx[rel];const meta={rel,size:file.size,lm:file.lastModified,syncedAt:Date.now()};
      if(cur){
        if(cur.ipad&&cur.ipad.size===file.size&&cur.ipad.lm===file.lastModified){done++;continue}
        if(IPF.edited(cur)){/* both changed: keep Nimbus copy, add the iPad version beside it */
          const m=name.match(/^(.*?)(\.[^.]*)?$/);const parent=await IPF.folderFor(link.id,dir,cache);
          const nn=await FS.uniqueName(parent,`${m[1]} (iPad)${m[2]||""}`);
          await DB.fs.put({id:uid(),parent,name:nn,type:"file",mime:file.type||guessMime(name),size:file.size,mtime:Date.now(),blob:file.slice(0,file.size,file.type),ipad:{...meta,rel:(dir?dir+"/":"")+nn}});kept++}
        else{cur.blob=file.slice(0,file.size,file.type);cur.size=file.size;cur.mtime=Date.now();cur.ipad=meta;cur.mime=file.type||cur.mime;await DB.fs.put(cur);updated++}}
      else{const parent=await IPF.folderFor(link.id,dir,cache);
        await DB.fs.put({id:uid(),parent,name,type:"file",mime:file.type||guessMime(name),size:file.size,mtime:Date.now(),blob:file.slice(0,file.size,file.type),ipad:meta});added++}
      if(++done%40===0)FS.changed()}
    if(!fresh&&link.ipad&&link.ipad.pathsOk!==false){for(const [rel,e] of Object.entries(idx)){if(seen.has(rel))continue;
      if(IPF.edited(e)){kept++;continue}await DB.fs.del(e.id);removed++}}
    link.ipad={...(link.ipad||{}),syncedAt:Date.now(),files:items.length,bytes:items.reduce((s,i)=>s+i.file.size,0)};link.mtime=Date.now();await DB.fs.put(link);
    FS.changed();
    const parts=[];if(added)parts.push(`${added} new`);if(updated)parts.push(`${updated} updated`);if(removed)parts.push(`${removed} removed`);if(kept)parts.push(`${kept} kept (changed in Nimbus)`);
    UI.toast(fresh?`Linked “${link.name}”`:`Refreshed “${link.name}”`,parts.length?parts.join(" · "):"Everything was already up to date","files");
    return link},
  async refresh(link){
    await UI.dialog({title:`Refresh “${link.name}”`,text:"iPadOS doesn't let Nimbus look inside the folder on its own. In the next screen, choose the same folder again and Nimbus will bring in only what changed.",ok:"Choose Folder",cancel:"Cancel"})&&
    (async()=>{const files=await IPF.pick();if(!files.length)return;const {root,items}=IPF.shape(files);
      if(root&&root!==link.name&&!(await UI.confirm("Different folder?",`You picked “${esc(root)}”, but this is “${esc(link.name)}”. Use it anyway?`,"Use It")))return;
      await IPF.sync(link,items)})()},
  async changes(link){const idx=await IPF.index(link.id);return Object.entries(idx).filter(([,e])=>IPF.edited(e))},
  async saveBack(link){
    const ch=await IPF.changes(link);
    if(!ch.length){UI.toast("Nothing to save",`No files in “${link.name}” were changed in Nimbus.`,"files");return}
    if(ch.length===1){await shareFile(ch[0][1]);markSaved(ch);return}
    const ok=await UI.dialog({title:`Save ${ch.length} changed files`,text:`Nimbus will make one zip file (“${esc(link.name)} changes.zip”) keeping the folder layout. Choose “Save to Files”, then open the zip in the Files app to put the files back.`,ok:"Make Zip",cancel:"Cancel"});if(!ok)return;
    const d=window.define;try{window.define=undefined;if(!window.fflate)await loadJS("lib/fflate.js")}finally{window.define=d}
    const z={};for(const [rel,e] of ch)z[rel]=new Uint8Array(await e.blob.arrayBuffer());
    const zip=new Blob([fflate.zipSync(z,{level:6})],{type:"application/zip"});
    await shareFile({name:`${link.name} changes.zip`,mime:"application/zip",blob:zip});markSaved(ch);
    async function markSaved(list){for(const [,e] of list){e.ipad={...(e.ipad||{}),syncedAt:Date.now()+1000};await DB.fs.put(e)}FS.changed()}},
  async unlink(link){if(!(await UI.confirm(`Remove “${link.name}” from Nimbus?`,"This deletes Nimbus's copy only. The folder on your iPad isn't touched.","Remove",true)))return;
    const ch=await IPF.changes(link);
    if(ch.length&&!(await UI.confirm(`${ch.length} file(s) changed in Nimbus`,"Those changes haven't been saved back to the iPad and will be lost.","Remove Anyway",true)))return;
    await FS.remove(link.id);UI.toast("Removed",link.name,"files")}
};
window.IPF=IPF;

/* ---------------------- Files: sidebar + banner ---------------------- */
const _filesCreate41=APPS.files.create;
APPS.files.create=function(w,opts){
  const hooks=_filesCreate41(w,opts);const side=$(".sidebar",w.body);if(!side)return hooks;
  const imp=$(".si[data-x=ipad]",side);if(imp)imp.innerHTML=`${SVG.imp||SVG.ipad}Import Files…`;
  const box=html(`<div data-ipad></div>`);
  const loc=$$("h5",side).find(h=>/Locations/i.test(h.textContent));side.insertBefore(box,loc||null);
  /* navigate using Files' own sidebar handler */
  const nav=id=>{const s=$(".si[data-f]:not([data-ipf])",side);if(!s)return;const old=s.dataset.f;s.dataset.f=id;s.onclick();s.dataset.f=old;
    $$(".si",side).forEach(x=>x.classList.toggle("act",x.dataset.f===id))};
  const drawSide=async()=>{const links=await IPF.links();
    box.innerHTML=`<h5>iPad</h5>${links.map(l=>`<div class="si" data-f="${l.id}" data-ipf="${l.id}">${SVG.ipad}<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(l.name)}</span></div>`).join("")}
      <div class="si" data-ipadd>${SVG.plus.replace("<svg",'<svg style="color:var(--accent)"')}Link iPad Folder…</div>
      ${links.length?"":`<div class="ipf-note">Browse a folder from the iPad's Files app, like Downloads or iCloud Drive, right here.</div>`}`;
    $$("[data-ipf]",box).forEach(s=>{s.onclick=()=>nav(s.dataset.ipf);
      longPress(s,async e=>{const l=await DB.fs.get(s.dataset.ipf);if(l)linkMenu(l,e.clientX,e.clientY)})});
    $("[data-ipadd]",box).onclick=async()=>{if(!FOLDER_PICK_OK){UI.toast("Update iPadOS","Linking folders needs iPadOS 18.4 or later. You can still Import Files.","files");return}
      const l=await IPF.link();if(l)nav(l.id)}};
  /* banner inside a linked folder */
  const main=$(".main",w.body),scroll=$("[data-drop]",w.body);
  const banner=html(`<div class="ipf-banner" style="display:none"><span data-t></span><button class="btn" data-r>Refresh</button><button class="btn" data-s>Save Changes to iPad</button></div>`);
  main.insertBefore(banner,scroll);
  let curLink=null;
  const drawBanner=async()=>{const act=$(".si.act[data-f]",side);const title=$(".ftitle",w.body).textContent;
    /* find the folder being shown: the status bar ends with its path; use the active sidebar item or walk from the title */
    let id=w._ipfFolder;curLink=id?await IPF.linkOf(id):null;
    if(!curLink){banner.style.display="none";return}
    const ch=(await IPF.changes(curLink)).length;
    $("[data-t]",banner).innerHTML=`<b>${esc(curLink.name)}</b> · from your iPad · synced ${fmtDate(curLink.ipad?.syncedAt||curLink.mtime)}${ch?` · <b>${ch} changed in Nimbus</b>`:""}`;
    banner.style.display="flex"};
  $("[data-r]",banner).onclick=()=>curLink&&IPF.refresh(curLink);
  $("[data-s]",banner).onclick=()=>curLink&&IPF.saveBack(curLink);
  /* track which folder Files is showing by watching its title/status changes */
  const track=async()=>{const st=$("[data-status]",w.body);if(!st)return;
    const act=$(".si.act[data-f]",side);
    if(act){w._ipfFolder=act.dataset.f}
    else{/* opened a subfolder: find a folder with this title whose parent chain matches the status path */
      const path=(st.textContent.split(" · ")[1]||"").trim();const all=await DB.fs.all();const title=$(".ftitle",w.body).textContent;
      const cands=all.filter(e=>e.type==="folder"&&e.name===title);let best=null;
      for(const c of cands){if(path&&(await FS.path(c.id))===path){best=c;break}}
      w._ipfFolder=(best||cands[0]||{}).id}
    drawBanner()};
  const mo=new MutationObserver(()=>{clearTimeout(mo.t);mo.t=setTimeout(track,60)});
  mo.observe($("[data-status]",w.body),{childList:true,characterData:true,subtree:true});
  const lst=()=>drawSide();FS.listeners.add(lst);drawSide();
  if(opts&&opts.ipadLink)setTimeout(()=>nav(opts.ipadLink),50);
  return {...hooks,close(){FS.listeners.delete(lst);mo.disconnect();hooks&&hooks.close&&hooks.close()}}};

function linkMenu(l,x,y){UI.menu([
  {label:"Refresh from iPad…",action:()=>IPF.refresh(l)},
  {label:"Save Changes to iPad…",action:()=>IPF.saveBack(l)},"-",
  {label:"Rename in Nimbus…",action:async()=>{const n=await UI.prompt("Rename",l.name);if(n){l.name=n;await DB.fs.put(l);FS.changed()}}},
  {label:"Remove from Nimbus…",danger:true,action:()=>IPF.unlink(l)}],x,y)}

/* file menu: show where an iPad-linked file came from */
const _fileMenu41=fileMenu;
fileMenu=async function(id,x,y,after){await _fileMenu41(id,x,y,after);const e=await DB.fs.get(id);const m=$(".menu");if(!m||!e||!e.ipad||e.type!=="file")return;
  const l=await IPF.linkOf(id);if(!l)return;
  const it=html(`<div class="it"><span>Save Changes to iPad…</span></div>`);it.onclick=ev=>{ev.stopPropagation();UI.closeMenus();IPF.saveBack(l)};
  m.insertBefore(it,m.children[2]||null)};

/* FS.path shouldn't show the hidden root */
const _fsPath41=FS.path;
FS.path=async function(id){const p=await _fsPath41.call(FS,id);return String(p).replace(/^.*?iPad Folders\s*›?\s*/,"iPad › ").replace(/^.*?iPad Folders\/?/,"iPad/")};

/* Spotlight / desktop: offer linking */
window.linkIpadFolder=async()=>{const l=await IPF.link();if(l)WM.open("files",{ipadLink:l.id})};
