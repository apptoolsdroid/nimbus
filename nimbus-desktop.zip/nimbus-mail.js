/* Nimbus Desktop — Mail Hub (all your email accounts in one Mac-style window), Compose with From picker,
   Mail widget, and Mission Control. Loaded last; starts the desktop. */
"use strict";

document.head.appendChild(html(`<style>
.mh{flex:1;display:flex;min-width:0}
.mh .sidebar{width:210px}
.mh .si .dot{width:10px;height:10px;border-radius:50%;flex:none;margin:0 3px}
.mh .si .cnt{margin-left:auto;font-size:11px;color:var(--text3)}
.mh .addacc{margin:10px 8px;width:calc(100% - 16px);justify-content:center}
.mh .list{width:310px;flex:none;border-right:1px solid var(--hair);display:flex;flex-direction:column;min-height:0}
.mh .list .toolbar{border-bottom:1px solid var(--hair)}
.mh .rows{flex:1;overflow:auto}
.mh .row{display:flex;gap:11px;padding:11px 14px;border-bottom:1px solid var(--hair);cursor:default;align-items:center;position:relative}
.mh .row:hover{background:var(--hover)}
.mh .row.act{background:var(--accent);color:#fff}.mh .row.act small,.mh .row.act .pv{color:rgba(255,255,255,.85)}
.mh .row .av{width:40px;height:40px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:15px;box-shadow:inset 0 -6px 12px rgba(0,0,0,.15)}
.mh .row .meta{min-width:0;flex:1}
.mh .row b{display:flex;justify-content:space-between;gap:8px;font-size:13.5px}
.mh .row b span{font-weight:400;font-size:11.5px;color:var(--text3);white-space:nowrap}
.mh .row.act b span{color:rgba(255,255,255,.8)}
.mh .row small{display:block;color:var(--text2);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mh .row .pv{font-size:11.5px;color:var(--text3);margin-top:2px;display:flex;gap:6px;align-items:center}
.mh .pbadge{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;border-radius:5px;font-size:10px;font-weight:800;color:#fff}
.mh .detail{flex:1;overflow:auto;min-width:0}
.mh .dhead{display:flex;gap:16px;align-items:center;padding:26px 28px 18px;border-bottom:1px solid var(--hair)}
.mh .dhead .av{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:24px;box-shadow:0 6px 18px rgba(0,0,0,.18)}
.mh .dhead h2{margin:0;font-size:21px}.mh .dhead .em{color:var(--text2);font-size:13.5px;-webkit-user-select:text;user-select:text}
.mh .dbody{padding:18px 28px 28px;display:flex;flex-direction:column;gap:18px}
.mh .big{display:flex;gap:10px;flex-wrap:wrap}
.mh .big .btn{padding:10px 16px;font-size:13.5px;border-radius:10px}
.mh .folders{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px}
.mh .folder{background:var(--field);border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:6px;cursor:pointer;font-size:12.5px;font-weight:600;transition:transform .1s}
.mh .folder:active{transform:scale(.97)}
.mh .folder svg{width:22px;height:22px;color:var(--accent)}
.mh .sect{font-size:11px;letter-spacing:.05em;color:var(--text3);font-weight:600;text-transform:uppercase;margin-bottom:-8px}
.mh .searchrow{display:flex;gap:8px}
.mh .empty2{margin:auto;text-align:center;padding:40px;max-width:420px}
.mh .empty2 .ic{width:84px;height:84px;margin:0 auto 12px}
.sheet-wrap{position:absolute;inset:0;z-index:20;background:rgba(0,0,0,.18);display:flex;justify-content:center;align-items:flex-start}
.sheet{width:min(520px,94%);max-height:calc(100% - 20px);overflow:auto;margin-top:0;border-radius:0 0 16px 16px;background:var(--glass-strong);box-shadow:var(--shadow);
  backdrop-filter:blur(40px);-webkit-backdrop-filter:blur(40px);padding:20px 22px;animation:sheetin .22s ease;color:var(--text)}
@keyframes sheetin{from{transform:translateY(-30px);opacity:0}}
.sheet h3{margin:0 0 12px;font-size:16px}
.sheet .frow{display:grid;grid-template-columns:110px 1fr;gap:10px;align-items:center;margin:8px 0}
.sheet .frow label{text-align:right;color:var(--text2);font-size:13px}
.sheet select,.compose select{border:0;background:var(--field);border-radius:8px;padding:8px 10px;font-size:13.5px;color:var(--text);font-family:inherit;width:100%}
.sheet .sw2{display:flex;gap:7px;flex-wrap:wrap}.sheet .sw2 i{width:22px;height:22px;border-radius:50%;cursor:pointer;border:2px solid transparent}.sheet .sw2 i.on{box-shadow:0 0 0 2px var(--glass-strong),0 0 0 4px var(--text3)}
.sheet .acts{display:flex;gap:8px;justify-content:flex-end;margin-top:16px}
.sheet small.hint{display:block;color:var(--text3);font-size:11.5px;margin-top:4px}
.compose{flex:1;display:flex;flex-direction:column;min-width:0}
.compose .ctool{display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--hair)}
.compose .sendb{width:34px;height:34px;border-radius:50%;border:0;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center}
.compose .sendb svg{width:17px;height:17px}
.compose .cf{display:flex;align-items:center;gap:8px;padding:0 16px;border-bottom:1px solid var(--hair);min-height:40px}
.compose .cf span{color:var(--text3);width:62px;flex:none;font-size:13px}
.compose .cf input{flex:1;border:0;background:none;outline:none;font-size:14px;padding:9px 0}
.compose .cf select{background:none;padding:8px 0}
.compose .atts{display:flex;gap:8px;flex-wrap:wrap;padding:8px 16px;border-top:1px solid var(--hair)}
.compose .att{display:flex;gap:6px;align-items:center;background:var(--field);border-radius:8px;padding:5px 9px;font-size:12px}
.compose .att u{text-decoration:none;cursor:pointer;opacity:.6}
.compose .via{font-size:11.5px;color:var(--text3);padding:6px 16px;border-top:1px solid var(--hair)}
.w-mail .chips{display:grid;grid-template-columns:repeat(3,1fr);gap:7px}
.w-mail .chip{display:flex;align-items:center;gap:7px;background:rgba(255,255,255,.35);border-radius:10px;padding:7px 8px;font-size:11.5px;font-weight:600;cursor:pointer;white-space:nowrap;overflow:hidden}
:root[data-theme=dark] .w-mail .chip{background:rgba(255,255,255,.08)}
.w-mail .chip i{width:9px;height:9px;border-radius:50%;flex:none}
.w-mail .chip span{overflow:hidden;text-overflow:ellipsis}
/* mission control */
#windows.mc{background:rgba(10,10,20,.35);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);z-index:7000;position:fixed;inset:0}
#windows.mc .win{transition:transform .32s cubic-bezier(.2,.8,.2,1),box-shadow .2s;cursor:pointer;display:flex!important}
#windows.mc .win *{pointer-events:none}
#windows.mc .win:hover{box-shadow:0 0 0 4px var(--accent),var(--shadow)}
#windows .mc-label{position:absolute;left:50%;transform:translateX(-50%);color:#fff;font-size:13px;font-weight:600;text-shadow:0 1px 4px rgba(0,0,0,.6);pointer-events:none;white-space:nowrap;z-index:99999}
</style>`));

/* ================= providers ================= */
const enc=encodeURIComponent;
const qs=o=>Object.entries(o).filter(([k,v])=>v).map(([k,v])=>k+"="+enc(v)).join("&");
const MAILP={
  gmail:{name:"Gmail",letter:"G",color:"#ea4335",domains:["gmail.com","googlemail.com"],
    web:a=>`https://mail.google.com/mail/?authuser=${enc(a.email)}`,
    folders:{inbox:"#inbox",starred:"#starred",sent:"#sent",drafts:"#drafts",spam:"#spam",all:"#all"},
    folderUrl:(a,f)=>`https://mail.google.com/mail/?authuser=${enc(a.email)}${MAILP.gmail.folders[f]}`,
    search:(a,q)=>`https://mail.google.com/mail/?authuser=${enc(a.email)}#search/${enc(q)}`,
    compose:(a,m)=>`https://mail.google.com/mail/?authuser=${enc(a.email)}&view=cm&fs=1&${qs({to:m.to,cc:m.cc,su:m.subject,body:m.body})}`,
    app:{name:"Gmail app",open:"googlegmail://",compose:m=>`googlegmail:///co?${qs({to:m.to,cc:m.cc,subject:m.subject,body:m.body})}`}},
  outlook:{name:"Outlook.com",letter:"O",color:"#0a64d8",domains:["outlook.com","hotmail.com","live.com","msn.com","hotmail.co.uk","outlook.co.uk","live.co.uk"],
    web:a=>`https://outlook.live.com/mail/0/inbox`,
    folders:{inbox:"inbox",sent:"sentitems",drafts:"drafts",spam:"junkemail",archive:"archive"},
    folderUrl:(a,f)=>`https://outlook.live.com/mail/0/${MAILP.outlook.folders[f]}`,
    compose:(a,m)=>`https://outlook.live.com/mail/0/deeplink/compose?${qs({to:m.to,cc:m.cc,subject:m.subject,body:m.body})}`,
    app:{name:"Outlook app",open:"ms-outlook://",compose:m=>`ms-outlook://compose?${qs({to:m.to,cc:m.cc,subject:m.subject,body:m.body})}`}},
  m365:{name:"Microsoft 365 (work/school)",letter:"O",color:"#0f6cbd",domains:[],
    web:a=>`https://outlook.office.com/mail/inbox`,
    folders:{inbox:"inbox",sent:"sentitems",drafts:"drafts",spam:"junkemail",archive:"archive"},
    folderUrl:(a,f)=>`https://outlook.office.com/mail/${MAILP.m365.folders[f]}`,
    compose:(a,m)=>`https://outlook.office.com/mail/deeplink/compose?${qs({to:m.to,cc:m.cc,subject:m.subject,body:m.body})}`,
    app:{name:"Outlook app",open:"ms-outlook://",compose:m=>`ms-outlook://compose?${qs({to:m.to,cc:m.cc,subject:m.subject,body:m.body})}`}},
  yahoo:{name:"Yahoo Mail",letter:"Y",color:"#6001d2",domains:["yahoo.com","ymail.com","rocketmail.com","yahoo.co.uk","yahoo.co.in","yahoo.ca"],
    web:a=>`https://mail.yahoo.com/`,
    folders:{inbox:"1",sent:"2",drafts:"3",spam:"6"},
    folderUrl:(a,f)=>`https://mail.yahoo.com/d/folders/${MAILP.yahoo.folders[f]}`,
    search:(a,q)=>`https://mail.yahoo.com/d/search/keyword=${enc(q)}`,
    compose:(a,m)=>`https://compose.mail.yahoo.com/?${qs({to:m.to,cc:m.cc,subject:m.subject,body:m.body})}`,
    app:{name:"Yahoo Mail app",open:"ymail://",compose:m=>`ymail://mail/compose?${qs({to:m.to,subject:m.subject,body:m.body})}`}},
  icloud:{name:"iCloud Mail",letter:"iC",color:"#3693f3",domains:["icloud.com","me.com","mac.com"],web:a=>`https://www.icloud.com/mail/`},
  aol:{name:"AOL Mail",letter:"A",color:"#31459b",domains:["aol.com","aim.com"],web:a=>`https://mail.aol.com/`},
  proton:{name:"Proton Mail",letter:"P",color:"#6d4aff",domains:["proton.me","protonmail.com","pm.me"],web:a=>`https://mail.proton.me/`},
  zoho:{name:"Zoho Mail",letter:"Z",color:"#e42527",domains:["zoho.com","zohomail.com"],web:a=>`https://mail.zoho.com/`},
  gmx:{name:"GMX",letter:"GX",color:"#1c449b",domains:["gmx.com","gmx.net","gmx.de"],web:a=>`https://www.gmx.com/`},
  other:{name:"Other",letter:"@",color:"#8e8e93",domains:[],web:a=>a.webUrl||""}
};
const OPEN_WITH={web:"Website (Safari)",app:"Provider's app",applemail:"Apple Mail app",spark:"Spark app"};
function detectProvider(email){const d=(email.split("@")[1]||"").toLowerCase().trim();for(const [k,p] of Object.entries(MAILP))if(p.domains.includes(d))return k;return d?"other":"gmail"}
const accColor=a=>a.color||MAILP[a.provider]?.color||"#8e8e93";
const accLabel=a=>a.label||a.email.split("@")[0];
const accInitial=a=>initials(accLabel(a));
function badge(a){const p=MAILP[a.provider]||MAILP.other;return `<span class="pbadge" style="background:${p.color}">${esc(p.letter)}</span>`}
function mailAccounts(){return S.mailAccounts||(S.mailAccounts=[])}
const MailHub={
  openUrl(a,url,what){if(!url)return UI.toast("No web address",`Edit ${accLabel(a)} and add its webmail address.`,"mail");a.lastOpened=Date.now();saveSettings();openLink(url);
    UI.toast(`${accLabel(a)}`,what||"Opening…","mail");MailHub.refresh()},
  inbox(a){const p=MAILP[a.provider]||MAILP.other;
    if(a.openWith==="applemail")return MailHub.openUrl(a,"message://","Opening Apple Mail");
    if(a.openWith==="spark")return MailHub.openUrl(a,"readdle-spark://","Opening Spark");
    if(a.openWith==="app"&&p.app)return MailHub.openUrl(a,p.app.open,`Opening ${p.app.name}`);
    MailHub.openUrl(a,p.web(a),"Opening inbox in Safari")},
  folder(a,f){const p=MAILP[a.provider];if(p&&p.folderUrl&&a.openWith!=="applemail"&&a.openWith!=="spark")MailHub.openUrl(a,p.folderUrl(a,f),`Opening ${f}`);else MailHub.inbox(a)},
  search(a,q){const p=MAILP[a.provider];if(p&&p.search)MailHub.openUrl(a,p.search(a,q),`Searching “${q}”`);else{UI.toast("Search","This provider has no search link — opening the inbox; search there.","mail");MailHub.inbox(a)}},
  composeUrl(a,m){const p=MAILP[a.provider]||MAILP.other;
    if(a.openWith==="spark")return `readdle-spark://compose?${qs({recipient:m.to,subject:m.subject,body:m.body})}`;
    if(a.openWith==="app"&&p.app&&p.app.compose)return p.app.compose(m);
    if(a.openWith==="web"&&p.compose)return p.compose(a,m);
    return `mailto:${(m.to||"").split(/[,;\s]+/).filter(Boolean).map(x=>enc(x).replace(/%40/g,"@")).join(",")}?${qs({cc:m.cc,subject:m.subject,body:m.body})}`},
  refresh(){WM.wins.filter(w=>w.app==="mail").forEach(w=>w.hooks.redraw&&w.hooks.redraw());Widgets.mail&&Widgets.mail()}
};

/* ================= add / edit account sheet ================= */
const ACC_COLORS=["#ea4335","#ff9f0a","#ffd60a","#30d158","#64d2ff","#0a84ff","#5e5ce6","#bf5af2","#ff375f","#8e8e93"];
function accountSheet(host,acc,onDone){
  const isNew=!acc;const a=acc?{...acc}:{id:uid(),email:"",label:"",provider:"gmail",color:"",openWith:"web",signature:"",note:"",webUrl:""};
  const wrap=html(`<div class="sheet-wrap"><div class="sheet"><h3>${isNew?"Add Email Account":"Edit Account"}</h3>
    <div class="frow"><label>Email</label><input class="field" data-f="email" type="email" placeholder="name@gmail.com" value="${esc(a.email)}" autocapitalize="off" autocorrect="off"></div>
    <div class="frow"><label>Label</label><input class="field" data-f="label" placeholder="e.g. Work, Personal, Shop" value="${esc(a.label)}"></div>
    <div class="frow"><label>Provider</label><select data-f="provider">${Object.entries(MAILP).map(([k,p])=>`<option value="${k}" ${a.provider===k?"selected":""}>${esc(p.name)}</option>`).join("")}</select></div>
    <div class="frow" data-weburl style="display:${a.provider==="other"?"grid":"none"}"><label>Webmail</label><input class="field" data-f="webUrl" placeholder="https://mail.example.com" value="${esc(a.webUrl)}" autocapitalize="off"></div>
    <div class="frow"><label>Open with</label><select data-f="openWith">${Object.entries(OPEN_WITH).map(([k,v])=>`<option value="${k}" ${a.openWith===k?"selected":""}>${v}</option>`).join("")}</select></div>
    <div class="frow"><label></label><small class="hint" data-owhint></small></div>
    <div class="frow"><label>Colour</label><div class="sw2">${ACC_COLORS.map(c=>`<i style="background:${c}" data-c="${c}" class="${(a.color||"")===c?"on":""}"></i>`).join("")}</div></div>
    <div class="frow" style="align-items:start"><label style="padding-top:8px">Signature</label><textarea class="field" data-f="signature" rows="3" placeholder="Best regards,&#10;Your name">${esc(a.signature)}</textarea></div>
    <div class="frow"><label>Note</label><input class="field" data-f="note" placeholder="What you use this account for" value="${esc(a.note)}"></div>
    <div class="acts">${isNew?"":`<button class="btn" data-del style="color:#ff3b30;margin-right:auto">Remove Account</button>`}<button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok>${isNew?"Add Account":"Save"}</button></div></div></div>`);
  host.appendChild(wrap);
  const f=k=>$(`[data-f="${k}"]`,wrap);
  const hint=()=>{const p=MAILP[f("provider").value];const ow=f("openWith").value;
    $("[data-owhint]",wrap).textContent=ow==="web"?(f("provider").value==="gmail"?"Opens this exact Gmail account in Safari — no account switching.":"Opens the webmail in Safari. If you have several accounts with this provider, sign in once per account in Safari.")
      :ow==="app"?(p.app?`Opens the ${p.app.name} if it's installed. You pick the account inside the app.`:"This provider has no app link — the website will be used.")
      :ow==="applemail"?"Opens the iPad's Mail app (add this account in Settings › Mail › Accounts first).":"Opens Spark if it's installed."};
  f("email").addEventListener("input",()=>{if(isNew){const p=detectProvider(f("email").value);f("provider").value=p;$("[data-weburl]",wrap).style.display=p==="other"?"grid":"none";hint()}});
  f("provider").onchange=()=>{$("[data-weburl]",wrap).style.display=f("provider").value==="other"?"grid":"none";hint()};
  f("openWith").onchange=hint;hint();
  $$(".sw2 i",wrap).forEach(i=>i.onclick=()=>{$$(".sw2 i",wrap).forEach(x=>x.classList.remove("on"));i.classList.add("on");a.color=i.dataset.c});
  const close=()=>wrap.remove();
  $("[data-cancel]",wrap).onclick=close;wrap.addEventListener("pointerdown",e=>{if(e.target===wrap)close()});
  const del=$("[data-del]",wrap);if(del)del.onclick=async()=>{if(await UI.confirm(`Remove ${accLabel(a)}?`,"This only removes the shortcut from Nimbus. Your email account isn't touched.","Remove",true)){S.mailAccounts=mailAccounts().filter(x=>x.id!==a.id);saveSettings();close();onDone&&onDone(null)}};
  $("[data-ok]",wrap).onclick=()=>{const email=f("email").value.trim();if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){f("email").focus();f("email").style.boxShadow="0 0 0 2px #ff3b30";return}
    Object.assign(a,{email,label:f("label").value.trim(),provider:f("provider").value,openWith:f("openWith").value,signature:f("signature").value,note:f("note").value.trim(),webUrl:f("webUrl").value.trim()});
    if(isNew)mailAccounts().push(a);else{const i=mailAccounts().findIndex(x=>x.id===a.id);mailAccounts()[i]=a}saveSettings();close();onDone&&onDone(a)};
  setTimeout(()=>f(isNew?"email":"label").focus(),60)}

/* ================= Mail Hub window ================= */
const FOLDER_ICONS={inbox:SVG.imp,starred:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/></svg>`,
  sent:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M21 3 10 14M21 3l-7 18-4-7-7-4z"/></svg>`,drafts:SVG.docs,spam:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></svg>`,
  archive:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10h14V9M10 13h4"/></svg>`,all:SVG.listv};
const FOLDER_NAMES={inbox:"Inbox",starred:"Starred",sent:"Sent",drafts:"Drafts",spam:"Junk",archive:"Archive",all:"All Mail"};
const PEN=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m14 6 4 4"/></svg>`;
APPS.mail={name:"Mail",icon:"mail",w:1040,h:640,single:true,
  create(w,opts){
    const st={view:"all",sel:null,q:""};
    const fmtWhen=t=>{if(!t)return "";const d=new Date(t),n=new Date();return d.toDateString()===n.toDateString()?d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}):d.toLocaleDateString([], {month:"short",day:"numeric"})};
    const draw=()=>{const accs=mailAccounts();
      if(st.sel&&!accs.find(a=>a.id===st.sel))st.sel=null;
      const shown=accs.filter(a=>(st.view==="all"||st.view===a.id)&&(!st.q||(a.email+" "+accLabel(a)+" "+(a.note||"")).toLowerCase().includes(st.q.toLowerCase())));
      if(!st.sel&&shown[0])st.sel=shown[0].id;
      const a=accs.find(x=>x.id===st.sel);
      w.setTitle(st.view==="all"?`All Accounts — ${accs.length}`:accLabel(accs.find(x=>x.id===st.view)||{email:"Mail"}));
      w.tools.innerHTML=`<button class="btn icon" data-compose title="New Message (⌘N)">${PEN}</button>`;
      $("[data-compose]",w.tools).onclick=()=>openCompose({from:st.sel});
      if(!accs.length){w.body.innerHTML=`<div class="mh"><div class="empty2"><div class="ic">${ICON.mail()}</div><h2 style="margin:0 0 6px">Welcome to Mail</h2>
          <p class="muted">Add each of your email accounts once. Then every inbox is one tap away, and you can write from any address.</p>
          <button class="btn primary" data-add style="padding:10px 18px;font-size:14px">${SVG.plus} Add Your First Account</button>
          <p class="muted" style="font-size:12px;margin-top:16px">Works with Gmail, Outlook / Hotmail, Microsoft 365, Yahoo, iCloud, AOL, Proton, Zoho, GMX and any other provider.</p></div></div>`;
        $("[data-add]",w.body).onclick=()=>accountSheet(w.el,null,acc=>{if(acc){st.sel=acc.id}draw();Widgets.mail()});return}
      w.body.innerHTML=`<div class="mh">
        <div class="sidebar"><h5>Favourites</h5><div class="si ${st.view==="all"?"act":""}" data-v="all">${SVG.imp}All Inboxes<span class="cnt">${accs.length}</span></div>
          <h5>Accounts</h5>${accs.map(x=>`<div class="si ${st.view===x.id?"act":""}" data-v="${x.id}"><span class="dot" style="background:${accColor(x)}"></span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(accLabel(x))}</span></div>`).join("")}
          <button class="btn addacc" data-add>${SVG.plus} Add Account</button></div>
        <div class="list"><div class="toolbar"><input class="field" data-q placeholder="Filter accounts" value="${esc(st.q)}" style="padding:6px 10px"></div>
          <div class="rows">${shown.map(x=>`<div class="row ${x.id===st.sel?"act":""}" data-id="${x.id}"><div class="av" style="background:${accColor(x)}">${esc(accInitial(x))}</div>
            <div class="meta"><b>${esc(accLabel(x))}<span>${esc(fmtWhen(x.lastOpened))}</span></b><small>${esc(x.email)}</small><div class="pv">${badge(x)}${esc((MAILP[x.provider]||MAILP.other).name)} · ${esc(OPEN_WITH[x.openWith]||"")}</div></div></div>`).join("")||`<div class="empty">No matches</div>`}</div></div>
        <div class="detail">${a?detailHTML(a):`<div class="empty">Select an account</div>`}</div></div>`;
      $$(".si[data-v]",w.body).forEach(s=>s.onclick=()=>{st.view=s.dataset.v;if(st.view!=="all")st.sel=st.view;draw()});
      $("[data-add]",w.body).onclick=()=>accountSheet(w.el,null,acc=>{if(acc){st.sel=acc.id;st.view="all"}draw();Widgets.mail()});
      const qi=$("[data-q]",w.body);qi.oninput=()=>{st.q=qi.value;const pos=qi.selectionStart;draw();const n=$("[data-q]",w.body);n.focus();n.setSelectionRange(pos,pos)};
      $$(".row[data-id]",w.body).forEach(r=>{r.onclick=e=>{if(st.sel===r.dataset.id&&e.detail>=2){MailHub.inbox(mailAccounts().find(x=>x.id===r.dataset.id));return}st.sel=r.dataset.id;draw()};
        r.ondblclick=()=>MailHub.inbox(mailAccounts().find(x=>x.id===r.dataset.id));
        longPress(r,e=>{const x=mailAccounts().find(y=>y.id===r.dataset.id);UI.menu([{label:"Open Inbox",action:()=>MailHub.inbox(x)},{label:"New Message",action:()=>openCompose({from:x.id})},"-",
          {label:"Edit…",action:()=>accountSheet(w.el,x,()=>{draw();Widgets.mail()})},{label:"Move Up",action:()=>moveAcc(x.id,-1)},{label:"Move Down",action:()=>moveAcc(x.id,1)},"-",{label:"Copy Address",action:()=>{try{navigator.clipboard.writeText(x.email);UI.toast("Copied",x.email,"mail")}catch(_){}}}],e.clientX,e.clientY)})});
      if(a)bindDetail(a)};
    const moveAcc=(id,d)=>{const L=mailAccounts();const i=L.findIndex(x=>x.id===id),j=i+d;if(j<0||j>=L.length)return;[L[i],L[j]]=[L[j],L[i]];saveSettings();draw();Widgets.mail()};
    const detailHTML=a=>{const p=MAILP[a.provider]||MAILP.other;const fl=p.folderUrl&&a.openWith!=="applemail"&&a.openWith!=="spark"?Object.keys(p.folders):[];
      return `<div class="dhead"><div class="av" style="background:${accColor(a)}">${esc(accInitial(a))}</div><div style="min-width:0"><h2>${esc(accLabel(a))}</h2><div class="em">${esc(a.email)}</div>
        <div class="muted" style="font-size:12px;margin-top:3px">${badge(a)} ${esc(p.name)} · opens with ${esc(OPEN_WITH[a.openWith]||"")}${a.lastOpened?` · last opened ${esc(fmtWhen(a.lastOpened))}`:""}</div></div>
        <button class="btn" data-edit style="margin-left:auto">Edit</button></div>
        <div class="dbody">
          <div class="big"><button class="btn primary" data-inbox>${SVG.imp} Open Inbox</button><button class="btn" data-new>${PEN} New Message</button><button class="btn" data-copy>Copy Address</button></div>
          ${fl.length?`<div class="sect">Mailboxes</div><div class="folders">${fl.map(f=>`<div class="folder" data-folder="${f}">${FOLDER_ICONS[f]||SVG.docs}${FOLDER_NAMES[f]||f}</div>`).join("")}</div>`:""}
          <div class="sect">Search</div><div class="searchrow"><input class="field" data-sq placeholder="Search ${esc(accLabel(a))} mail…" enterkeyhint="search"><button class="btn" data-sgo>${SVG.search.replace("<svg",'<svg width="15" height="15"')}</button></div>
          ${a.note?`<div class="sect">Note</div><div style="font-size:13.5px">${esc(a.note)}</div>`:""}
          ${a.signature?`<div class="sect">Signature</div><div style="font-size:13px;white-space:pre-wrap;color:var(--text2);background:var(--field);border-radius:10px;padding:10px 12px">${esc(a.signature)}</div>`:""}
          <p class="muted" style="font-size:11.5px;line-height:1.5">Your emails open in ${a.openWith==="web"?"Safari":"the app you chose"} — Nimbus never sees your password or messages.${a.provider==="gmail"&&a.openWith==="web"?" This shortcut opens exactly this Gmail account.":""}</p></div>`};
    const bindDetail=a=>{const d=$(".detail",w.body);
      $("[data-edit]",d).onclick=()=>accountSheet(w.el,a,()=>{draw();Widgets.mail()});
      $("[data-inbox]",d).onclick=()=>MailHub.inbox(a);$("[data-new]",d).onclick=()=>openCompose({from:a.id});
      $("[data-copy]",d).onclick=()=>{try{navigator.clipboard.writeText(a.email);UI.toast("Copied",a.email,"mail")}catch(_){}};
      $$("[data-folder]",d).forEach(f=>f.onclick=()=>MailHub.folder(a,f.dataset.folder));
      const sq=$("[data-sq]",d);const go=()=>{if(sq.value.trim())MailHub.search(a,sq.value.trim())};$("[data-sgo]",d).onclick=go;sq.onkeydown=e=>{if(e.key==="Enter")go()}};
    if(opts&&opts.account){st.sel=opts.account}
    draw();
    const kh=e=>{if(WM.active===w&&(e.metaKey||e.ctrlKey)&&e.key==="n"){e.preventDefault();openCompose({from:st.sel})}};document.addEventListener("keydown",kh);
    return {redraw:draw,reopenMail(o){if(o&&o.account){st.sel=o.account;draw()}},close(){document.removeEventListener("keydown",kh)}}},
  reopen(w,o){w.hooks.reopenMail&&w.hooks.reopenMail(o)}
};

/* ================= Compose ================= */
function openCompose(o={}){return WM.open("compose",o)}
APPS.compose={name:"New Message",icon:"mail",w:640,h:560,hidden:true,
  create(w,opts){
    const accs=mailAccounts();let atts=[];
    const pick=accs.find(a=>a.id===opts.from)||accs[0];
    w.body.innerHTML=`<div class="compose"><div class="ctool"><button class="sendb" data-send title="Send">${`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M21 3 10 14M21 3l-7 18-4-7-7-4z"/></svg>`}</button>
        <button class="btn" data-attach>${`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m21 12-8.5 8.5a5 5 0 0 1-7-7L14 5a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 8"/></svg>`}Attach</button>
        <span style="flex:1"></span><span class="muted" style="font-size:12px" data-sendvia></span></div>
      <div class="cf"><span>To:</span><input data-to type="email" multiple autocapitalize="off" autocorrect="off" value="${esc(opts.to||"")}"></div>
      <div class="cf"><span>Cc:</span><input data-cc type="email" multiple autocapitalize="off" autocorrect="off"></div>
      <div class="cf"><span>Subject:</span><input data-sub value="${esc(opts.subject||"")}" style="font-weight:600"></div>
      <div class="cf"><span>From:</span>${accs.length?`<span class="dot" data-fdot style="width:10px;height:10px;border-radius:50%;flex:none;display:inline-block"></span><select data-from>${accs.map(a=>`<option value="${a.id}" ${pick&&a.id===pick.id?"selected":""}>${esc(accLabel(a))} — ${esc(a.email)}</option>`).join("")}</select>`:`<em class="muted" style="font-size:13px">No accounts yet — the iPad's default Mail app will be used.</em>`}</div>
      <textarea class="editor" data-body placeholder="Write your message…"></textarea>
      <div class="atts" data-atts style="display:none"></div>
      <div class="via" data-via></div></div>`;
    const f=k=>$(`[data-${k}]`,w.body);
    const cur=()=>accs.find(a=>a.id===(f("from")&&f("from").value));
    let lastSig="";
    const applySig=()=>{const a=cur();const body=f("body");const sig=a&&a.signature?`\n\n${a.signature}`:"";
      if(lastSig&&body.value.endsWith(lastSig))body.value=body.value.slice(0,-lastSig.length);body.value+=sig;lastSig=sig;
      if(f("fdot"))f("fdot").style.background=a?accColor(a):"#8e8e93";updVia()};
    const updVia=()=>{const a=cur();const p=a?MAILP[a.provider]||MAILP.other:null;
      f("via").textContent=atts.length?"With attachments, Send opens the iPad share sheet — choose Mail, Gmail or Outlook there and pick the account to send from.":
        !a?"Send opens the iPad's default Mail app.":a.openWith==="web"&&p.compose?`Send opens ${p.name} in Safari${a.provider==="gmail"?` as ${a.email}`:""} with everything filled in — tap Send there.`:
        a.openWith==="app"&&p.app?`Send opens the ${p.app.name} with everything filled in — check the From account there, then tap Send.`:
        a.openWith==="spark"?"Send opens Spark with everything filled in.":"Send opens the iPad's Mail app with everything filled in — choose the From account there.";
      f("sendvia").textContent=a?`via ${a.openWith==="web"?(p.name):OPEN_WITH[a.openWith]}`:""};
    if(f("from"))f("from").onchange=applySig;applySig();f("body").setSelectionRange(0,0);
    const drawAtts=()=>{const box=f("atts");box.style.display=atts.length?"flex":"none";box.innerHTML=atts.map((x,i)=>`<div class="att">📎 ${esc(x.name)} <span class="muted">${fmtSize(x.size)}</span><u data-i="${i}">✕</u></div>`).join("");
      $$("u",box).forEach(u=>u.onclick=()=>{atts.splice(+u.dataset.i,1);drawAtts();updVia()});updVia()};
    f("attach").onclick=e=>{const r=e.target.getBoundingClientRect();UI.menu([
      {label:"From the iPad…",action:()=>pickFiles(fl=>{atts.push(...fl);drawAtts()})},
      {label:"From Nimbus Files…",action:async()=>{const all=(await DB.fs.all()).filter(x=>x.type==="file").sort((a,b)=>b.mtime-a.mtime).slice(0,25);
        UI.menu(all.length?all.map(x=>({label:x.name,action:()=>{atts.push(new File([x.blob],x.name,{type:x.mime||"application/octet-stream"}));drawAtts()}})):[{label:"No files yet",disabled:true}],r.left,r.bottom+4)}}],r.left,r.bottom+4)};
    if(opts.attach)opts.attach.forEach(x=>atts.push(x)),drawAtts();
    w.setTitle(opts.subject||"New Message");f("sub").oninput=()=>w.setTitle(f("sub").value||"New Message");
    f("send").onclick=async()=>{const m={to:f("to").value.trim(),cc:f("cc").value.trim(),subject:f("sub").value,body:f("body").value};const a=cur();
      if(atts.length){const text=(m.to?`To: ${m.to}\n`:"")+m.body;
        try{if(navigator.canShare&&navigator.canShare({files:atts})){await navigator.share({files:atts,title:m.subject,text});UI.toast("Shared","Finish sending in the app you picked","mail");WM.close(w);return}}catch(err){if(err.name==="AbortError")return}
        UI.toast("Can't attach here",SANDBOXED?"This preview can't open the share sheet. Use the installed version of Nimbus.":"This browser can't share files.","mail");return}
      const url=a?MailHub.composeUrl(a,m):MailHub.composeUrl({provider:"other",openWith:"applemail"},m);
      if(a){a.lastOpened=Date.now();saveSettings();MailHub.refresh()}
      openLink(url);UI.toast("Handed off",a?`Tap Send in ${a.openWith==="web"?(MAILP[a.provider]||MAILP.other).name:OPEN_WITH[a.openWith]} to deliver it.`:"Tap Send in Mail.","mail");dirty=false;WM.close(w)};
    let dirty=false;["to","cc","sub","body"].forEach(k=>f(k).addEventListener("input",()=>dirty=true));
    setTimeout(()=>(opts.to?f("sub"):f("to")).focus(),80);
    return {async beforeClose(){if(!dirty)return true;return !!(await UI.confirm("Discard this message?","It hasn't been sent.","Discard",true))}}}
};
/* attach files to email straight from Files */
const _fileMenu2=fileMenu;
fileMenu=async function(id,x,y,after){await _fileMenu2(id,x,y,after);const e=await DB.fs.get(id);const m=$(".menu");if(!m||!e||e.type!=="file")return;
  const it=html(`<div class="it"><span>Email this file…</span></div>`);it.onclick=ev=>{ev.stopPropagation();UI.closeMenus();openCompose({subject:e.name,attach:[new File([e.blob],e.name,{type:e.mime||"application/octet-stream"})]})};
  m.insertBefore(it,m.children[1]||null)};

/* ================= Mail widget ================= */
const _wRender=Widgets.render;
Widgets.render=async function(){await _wRender.call(Widgets);const box=$("#widgets");if(!box||!S.widgets)return;
  const msg=$("#wg-contacts")?.closest(".widget");const wg=html(`<div class="widget glass wide w-mail"><h4>Mail <span style="display:flex;gap:6px"><span class="pill" style="cursor:pointer" data-wnew>New</span><span class="pill" style="cursor:pointer" data-wopen>All</span></span></h4><div class="chips" id="wg-mail"></div></div>`);
  if(msg)msg.after(wg);else box.appendChild(wg);$("[data-wnew]",wg).onclick=()=>openCompose({});$("[data-wopen]",wg).onclick=()=>WM.open("mail");Widgets.mail()};
Widgets.mail=function(){const el=$("#wg-mail");if(!el)return;const accs=mailAccounts();
  el.innerHTML=accs.length?accs.slice(0,9).map(a=>`<div class="chip" data-id="${a.id}" title="${esc(a.email)}"><i style="background:${accColor(a)}"></i><span>${esc(accLabel(a))}</span></div>`).join(""):`<div class="muted" style="grid-column:span 3;font-size:12px;cursor:pointer" data-first>Tap to add your email accounts</div>`;
  $$(".chip",el).forEach(c=>{c.onclick=()=>{const a=mailAccounts().find(x=>x.id===c.dataset.id);a&&MailHub.inbox(a)};
    longPress(c,e=>{const a=mailAccounts().find(x=>x.id===c.dataset.id);UI.menu([{label:"Open Inbox",action:()=>MailHub.inbox(a)},{label:"New Message",action:()=>openCompose({from:a.id})},{label:"Show in Mail",action:()=>WM.open("mail",{account:a.id})}],e.clientX,e.clientY)})});
  const ff=$("[data-first]",el);if(ff)ff.onclick=()=>WM.open("mail")};

/* ================= Spotlight: accounts ================= */
const _spSearch=Spotlight.search;
Spotlight.search=async function(q){await _spSearch.call(Spotlight,q);const t=q.trim().toLowerCase();if(!t)return;
  const hits=mailAccounts().filter(a=>(a.email+" "+accLabel(a)).toLowerCase().includes(t)).slice(0,5).map(a=>({icon:ICON.mail(),label:`${accLabel(a)} — ${a.email}`,sub:"Open inbox",go:()=>MailHub.inbox(a)}));
  if(hits.length){Spotlight.items.splice(Math.max(0,Spotlight.items.length-1),0,...hits);Spotlight.draw()}};

/* ================= Mission Control ================= */
const MC={on:false,
  toggle(){MC.on?MC.exit():MC.enter()},
  enter(){const wins=WM.wins.slice();if(!wins.length){UI.toast("Mission Control","No open windows");return}
    UI.closeMenus();Launchpad.close&&Launchpad.close();MC.on=true;const box=$("#windows");box.classList.add("mc");
    const W=innerWidth,H=innerHeight-110,top=60,n=wins.length,cols=Math.ceil(Math.sqrt(n*W/H)),rows=Math.ceil(n/cols);
    const cw=W/cols,ch=H/rows;
    wins.forEach((w,i)=>{const el=w.el;w._mcMin=el.classList.contains("minimized");el.classList.remove("minimized");
      const r=el.getBoundingClientRect();const c=i%cols,ro=Math.floor(i/cols);
      const s=Math.min((cw-40)/r.width,(ch-50)/r.height,1);const cx=c*cw+cw/2,cy=top+ro*ch+ch/2-10;
      const tx=cx-(r.left+r.width/2),ty=cy-(r.top+r.height/2);el.style.transform=`translate(${tx}px,${ty}px) scale(${s})`;
      const lb=html(`<div class="mc-label">${esc(APPS[w.app]?.name||"")} — ${esc($(".title",el).textContent)}</div>`);lb.style.top=(cy+r.height*s/2+8)+"px";lb.style.left=cx+"px";box.appendChild(lb);
      w._mcClick=e=>{e.stopPropagation();e.preventDefault();MC.exit(w)};el.addEventListener("click",w._mcClick,true)});
    MC._bg=e=>{if(e.target===box)MC.exit()};box.addEventListener("click",MC._bg)},
  exit(pick){if(!MC.on)return;MC.on=false;const box=$("#windows");$$(".mc-label",box).forEach(l=>l.remove());box.removeEventListener("click",MC._bg);
    WM.wins.forEach(w=>{w.el.style.transform="";w.el.removeEventListener("click",w._mcClick,true);if(w._mcMin&&w!==pick)w.el.classList.add("minimized")});
    setTimeout(()=>box.classList.remove("mc"),280);if(pick){WM.restore(pick)}}
};
document.addEventListener("keydown",e=>{if(e.key==="F3"||(e.ctrlKey&&e.key==="ArrowUp")){e.preventDefault();MC.toggle()}if(e.key==="Escape"&&MC.on)MC.exit()},true);
const _openMenu2=Menubar.openMenu;
Menubar.openMenu=function(m,el){if(m==="window"&&!el.classList.contains("open")){el.classList.add("open");const r=el.getBoundingClientRect();const w=WM.active;
    UI.menu([{label:"Mission Control",key:"F3",action:()=>MC.enter()},{label:"Minimise",key:"⌘M",disabled:!w,action:()=>WM.minimize(w)},{label:"Zoom",disabled:!w,action:()=>WM.toggleMax(w)},"-",
      ...WM.wins.map(x=>({label:APPS[x.app].name+" — "+$(".title",x.el).textContent,action:()=>WM.restore(x)}))],r.left,r.bottom+4);return}
  if(m==="file"&&WM.active&&(WM.active.app==="mail"||WM.active.app==="compose")&&!el.classList.contains("open")){el.classList.add("open");const r=el.getBoundingClientRect();
    UI.menu([{label:"New Message",key:"⌘N",action:()=>openCompose({})},{label:"Add Account…",action:()=>{const w=WM.wins.find(x=>x.app==="mail")||WM.open("mail");accountSheet(w.el,null,()=>MailHub.refresh())}},"-",{label:"Close Window",key:"⌘W",action:()=>WM.close(WM.active)}],r.left,r.bottom+4);return}
  return _openMenu2(m,el)};
/* Control Center tile */
const _ccRender=CC.render;
CC.render=function(){_ccRender();const t=html(`<div class="cc-tile" data-t="mc"><div class="cir">${SVG.grid}</div>Mission Control</div>`);t.onclick=()=>{$("#cc").classList.remove("show");MC.enter()};$("#cc").insertBefore(t,$("#cc .cc-wide"))};

/* ================= boot ================= */
/* boot is started by nimbus-mail2.js */
