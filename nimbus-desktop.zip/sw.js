// Nimbus offline cache: app shell + engines. Installed web apps live in the "nimbus-apps" cache.
const CACHE = "nimbus-v4";
const FILES = ["./", "./index.html", "./manifest.webmanifest", "./libv86.js", "./v86.wasm", "./bios.js", "./nimbus-extra.js", "./nimbus-apps.js", "./nimbus-mail.js", "./hdd.js", "./lib/fflate.js", "./icon-180.png", "./icon-192.png", "./icon-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE && k !== "nimbus-apps").map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== location.origin) return;
  const isApp = new URL(e.request.url).pathname.includes("/installed/");
  e.respondWith(caches.match(e.request, { ignoreSearch: isApp }).then(r => r || (isApp ? new Response("Not installed", { status: 404 }) : fetch(e.request).then(resp => {
    if (resp.ok) { const copy = resp.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
    return resp;
  }))).catch(() => caches.match("./index.html")));
});
