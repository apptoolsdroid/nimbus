// Nimbus offline cache.
// Nimbus's own files (index.html, nimbus-*.js, version.json) load from the network first,
// so a new upload to GitHub Pages shows up on the next launch; the cache is the offline fallback.
// Heavy engines and libraries are cache-first. Installed web apps live in the "nimbus-apps" cache.
const CACHE = "nimbus-v12";
const FILES = ["./", "./index.html", "./manifest.webmanifest", "./version.json", "./libv86.js", "./v86.wasm", "./bios.js",
  "./nimbus-extra.js", "./nimbus-apps.js", "./nimbus-mail.js", "./nimbus-browser.js", "./nimbus-mail2.js", "./nimbus-neo.js",
  "./nimbus-cloud.js", "./nimbus-folders.js", "./nimbus-media.js", "./nimbus-sync.js", "./nimbus-v4.js", "./nimbus-bookmarks.js", "./hdd.js", "./lib/fflate.js",
  "./lib/xterm/xterm.js", "./lib/xterm/addon-fit.js", "./lib/xterm/xterm.css",
  "./icon-180.png", "./icon-192.png", "./icon-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE && k !== "nimbus-apps").map(k => caches.delete(k)))).then(() => self.clients.claim())); });

const isShell = url => {
  const p = url.pathname;
  return p.endsWith("/") || /\/(index\.html|version\.json|manifest\.webmanifest|nimbus-[\w-]+\.js)$/.test(p);
};
const put = (req, resp) => { if (resp && resp.ok) { const copy = resp.clone(); caches.open(CACHE).then(c => c.put(req, copy)); } return resp; };
const timeout = (ms, p) => new Promise((res, rej) => { const t = setTimeout(() => rej(new Error("timeout")), ms); p.then(v => { clearTimeout(t); res(v); }, err => { clearTimeout(t); rej(err); }); });

self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  if (url.pathname.includes("/installed/")) {
    e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(r => r || new Response("Not installed", { status: 404 })));
    return;
  }
  if (url.pathname.endsWith("/version.json")) { e.respondWith(fetch(e.request, { cache: "no-store" }).catch(() => caches.match("./version.json"))); return; }
  if (isShell(url) || e.request.mode === "navigate") {
    e.respondWith(timeout(5000, fetch(e.request, { cache: "no-cache" })).then(r => put(e.request, r))
      .catch(() => caches.match(e.request, { ignoreSearch: true }).then(r => r || caches.match("./index.html"))));
    return;
  }
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).then(resp => put(e.request, resp))).catch(() => caches.match("./index.html")));
});
