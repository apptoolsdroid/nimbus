/* Nimbus Desktop — Cloud Drive: Google Drive + OneDrive inside Nimbus (browse, open in Nimbus apps, save back,
   upload, new folder, rename, delete), Files sidebar shortcuts, and a Viewer for PDF / video / audio. */
"use strict";

document.head.appendChild(html(`<style>
.cd{flex:1;display:flex;min-width:0;min-height:0}
.cd .sidebar{width:230px;display:flex;flex-direction:column}
.cd .si .pb{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:5px;color:#fff;font-size:10px;font-weight:800;flex:none}
.cd .si.sub{padding-left:32px;font-size:12.5px}
.cd .grid .fi .ic,.cd .grid .fi img.thumb{width:56px;height:52px}
.cd .grid .fi img.thumb{object-fit:cover;border-radius:6px;box-shadow:0 1px 4px rgba(0,0,0,.25)}
.cd .gbadge{position:absolute;right:-4px;bottom:-2px;font-size:9px;font-weight:800;color:#fff;border-radius:4px;padding:1px 3px}
.cd .banner{margin:14px;background:var(--field);border-radius:14px;padding:14px 16px;font-size:13px;line-height:1.5}
.cd .banner h4{margin:0 0 6px;font-size:14px}
.cd .crumbs{display:flex;gap:4px;align-items:center;font-weight:600;font-size:13.5px;flex:1;min-width:0;overflow:hidden;white-space:nowrap}
.cd .crumbs a{cursor:pointer;color:var(--text2)}.cd .crumbs a:last-child{color:var(--text)}
.cd .loading{display:flex;justify-content:center;padding:50px}
.vw{flex:1;display:flex;flex-direction:column;min-width:0;min-height:0;background:#525659}
.vw .pages{flex:1;overflow:auto;-webkit-overflow-scrolling:touch;padding:16px 0;display:flex;flex-direction:column;align-items:center;gap:14px}
.vw .pages canvas{background:#fff;box-shadow:0 4px 18px rgba(0,0,0,.35);max-width:calc(100% - 24px)}
.vw video,.vw audio{max-width:100%;max-height:100%;margin:auto;display:block;outline:none}
.vw .media{flex:1;display:flex;align-items:center;justify-content:center;min-height:0;background:#000}
</style>`));

/* ================= icons ================= */
Object.assign(ICON,{
  clouddrive:()=>squircle("cdv","#5ac8fa","#0a6ad8",`<path d="M45 44H21a9 9 0 0 1-1.2-17.9A12 12 0 0 1 43 23.5 10.3 10.3 0 0 1 45 44z" fill="#fff"/><path d="M32 30v10M27.5 34.5 32 30l4.5 4.5" fill="none" stroke="#0a6ad8" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>`),
  viewer:()=>squircle("vwr","#ff6b6b","#c2255c",`<rect x="17" y="11" width="30" height="42" rx="4" fill="#fff"/><text x="32" y="38" font-size="11" font-weight="800" text-anchor="middle" fill="#c2255c" font-family="-apple-system,sans-serif">PDF</text>`)
});
const PROV={g:{name:"Google Drive",short:"Drive",color:"#1fa463",letter:"G"},m:{name:"OneDrive",short:"OneDrive",color:"#0364b8",letter:"O"}};
const pbadge=k=>`<span class="pb" style="background:${PROV[k].color}">${PROV[k].letter}</span>`;
const GNATIVE={"application/vnd.google-apps.document":["docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document","#4285f4","Docs"],
  "application/vnd.google-apps.spreadsheet":["xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","#0f9d58","Sheets"],
  "application/vnd.google-apps.presentation":["pdf","application/pdf","#f4b400","Slides"],"application/vnd.google-apps.drawing":["png","image/png","#db4437","Drawing"]};

/* ================= provider adapters ================= */
const GD="https://www.googleapis.com/drive/v3",GU="https://www.googleapis.com/upload/drive/v3";
const GFIELDS="nextPageToken,files(id,name,mimeType,size,modifiedTime,thumbnailLink,webViewLink,parents)";
async function apiRaw(a,url,opt={}){const tok=await tokenFor(a);const r=await fetch(url,{...opt,headers:{Authorization:"Bearer "+tok,...(opt.headers||{})}});
  if(r.status===401){const t=MT.tokens[a.id];if(t)t.exp=0;throw new NeedAuth(a,"Session expired")}if(!r.ok){let m="HTTP "+r.status;try{const j=await r.json();m=(j.error&&(j.error.message||j.error))||m}catch(e){}throw new Error(m)}return r}
const hasDrive=a=>{const t=MT.tokens[a.id];if(!t)return false;return kindOf(a)==="g"?/auth\/drive(\s|$)/.test(t.scope||""):/Files\./i.test(t.scope||"")};
const gItem=f=>({id:f.id,name:f.name,folder:f.mimeType==="application/vnd.google-apps.folder",size:f.size?+f.size:null,mtime:Date.parse(f.modifiedTime),mime:f.mimeType,web:f.webViewLink,thumb:f.thumbnailLink,gnative:!!GNATIVE[f.mimeType]||(f.mimeType.startsWith("application/vnd.google-apps.")&&f.mimeType!=="application/vnd.google-apps.folder")});
const mBase=it=>it&&it.drive?`${GR.replace(/\/me$/,"")}/drives/${it.drive}/items/${it.id}`:it&&it.id&&it.id!=="root"?`${GR}/drive/items/${it.id}`:`${GR}/drive/root`;
const mItem=x=>{const r=x.remoteItem;const src=r||x;return {id:src.id,drive:r?r.parentReference?.driveId:null,name:x.name||src.name,folder:!!(src.folder||x.folder),size:src.size??x.size??null,mtime:Date.parse(x.lastModifiedDateTime||src.lastModifiedDateTime),
  mime:(src.file||x.file||{}).mimeType||"",web:x.webUrl||src.webUrl,thumb:(x.thumbnails&&x.thumbnails[0]&&(x.thumbnails[0].medium||x.thumbnails[0].small||{}).url)||null}};
const CloudAPI={
  async list(a,where,folder,q){const k=kindOf(a);
    if(k==="g"){let qq,order="folder,name_natural",size=200;
      if(q){qq=`name contains '${q.replace(/'/g,"\\'")}' and trashed=false`;order="modifiedTime desc";size=60}
      else if(where==="shared")qq="sharedWithMe and trashed=false";else if(where==="recent"){qq="trashed=false and mimeType != 'application/vnd.google-apps.folder'";order="viewedByMeTime desc";size=50}
      else if(where==="starred")qq="starred=true and trashed=false";else qq=`'${folder?folder.id:"root"}' in parents and trashed=false`;
      const out=[];let page=null;do{const j=await api(a,`${GD}/files?${qs({q:qq,fields:GFIELDS,orderBy:order,pageSize:String(size),pageToken:page,supportsAllDrives:"true",includeItemsFromAllDrives:"true"})}`);out.push(...(j.files||[]).map(gItem));page=where==="recent"||q?null:j.nextPageToken}while(page&&out.length<1000);return out}
    const sel="$select=id,name,size,file,folder,lastModifiedDateTime,webUrl,remoteItem,parentReference&$expand=thumbnails";
    let url;if(q)url=`${GR}/drive/root/search(q='${encodeURIComponent(q.replace(/'/g,"''"))}')?$top=60`;else if(where==="shared")url=`${GR}/drive/sharedWithMe`;else if(where==="recent")url=`${GR}/drive/recent`;
    else url=`${mBase(folder)}/children?$top=200&${sel}`;
    const out=[];while(url&&out.length<1000){const j=await api(a,url);out.push(...(j.value||[]).map(mItem));url=j["@odata.nextLink"]||null}
    out.sort((x,y)=>x.folder!==y.folder?(x.folder?-1:1):x.name.localeCompare(y.name,undefined,{numeric:true}));return out},
  async download(a,it){const k=kindOf(a);
    if(k==="g"){if(it.gnative){const ex=GNATIVE[it.mime]||["pdf","application/pdf"];const r=await apiRaw(a,`${GD}/files/${it.id}/export?mimeType=${enc(ex[1])}`);return {blob:await r.blob(),name:it.name.replace(/\.[^.]+$/,"")+"."+ex[0],exported:true}}
      const r=await apiRaw(a,`${GD}/files/${it.id}?alt=media&supportsAllDrives=true`);return {blob:await r.blob(),name:it.name}}
    const j=await api(a,`${mBase(it)}?$select=id,name,@microsoft.graph.downloadUrl`);const u=j["@microsoft.graph.downloadUrl"];
    const r=u?await fetch(u):await apiRaw(a,`${mBase(it)}/content`);if(!r.ok)throw new Error("Download failed ("+r.status+")");return {blob:await r.blob(),name:it.name}},
  async update(a,it,blob){if(kindOf(a)==="g"){const r=await apiRaw(a,`${GU}/files/${it.id}?uploadType=media&supportsAllDrives=true&fields=id,name,modifiedTime`,{method:"PATCH",headers:{"Content-Type":blob.type||"application/octet-stream"},body:blob});return r.json()}
    const r=await apiRaw(a,`${mBase(it)}/content`,{method:"PUT",headers:{"Content-Type":blob.type||"application/octet-stream"},body:blob});return r.json()},
  async create(a,parent,name,blob){if(kindOf(a)==="g"){const B="nimbus"+rnd(8);const meta={name,parents:[parent&&parent.id?parent.id:"root"]};
      const body=new Blob([`--${B}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${B}\r\nContent-Type: ${blob.type||"application/octet-stream"}\r\n\r\n`,blob,`\r\n--${B}--`]);
      const r=await apiRaw(a,`${GU}/files?uploadType=multipart&supportsAllDrives=true&fields=id,name,mimeType,size,modifiedTime,webViewLink`,{method:"POST",headers:{"Content-Type":`multipart/related; boundary=${B}`},body});return gItem(await r.json())}
    const base=parent&&parent.id&&parent.id!=="root"?(parent.drive?`${GR.replace(/\/me$/,"")}/drives/${parent.drive}/items/${parent.id}`:`${GR}/drive/items/${parent.id}`):`${GR}/drive/root`;
    const r=await apiRaw(a,`${base}:/${encodeURIComponent(name)}:/content?@microsoft.graph.conflictBehavior=rename`,{method:"PUT",headers:{"Content-Type":blob.type||"application/octet-stream"},body:blob});return mItem(await r.json())},
  async mkdir(a,parent,name){if(kindOf(a)==="g")return gItem(await api(a,`${GD}/files?supportsAllDrives=true&fields=id,name,mimeType,modifiedTime`,{method:"POST",body:JSON.stringify({name,mimeType:"application/vnd.google-apps.folder",parents:[parent&&parent.id?parent.id:"root"]})}));
    return mItem(await api(a,`${mBase(parent)}/children`,{method:"POST",body:JSON.stringify({name,folder:{},"@microsoft.graph.conflictBehavior":"rename"})}))},
  async rename(a,it,name){if(kindOf(a)==="g")return api(a,`${GD}/files/${it.id}?supportsAllDrives=true`,{method:"PATCH",body:JSON.stringify({name})});return api(a,mBase(it),{method:"PATCH",body:JSON.stringify({name})})},
  async remove(a,it){if(kindOf(a)==="g")return api(a,`${GD}/files/${it.id}?supportsAllDrives=true`,{method:"PATCH",body:JSON.stringify({trashed:true})});return api(a,mBase(it),{method:"DELETE"})}
};

/* ================= open in Nimbus apps & save back ================= */
const Cloud={
  async ensureCache(){if(!(await DB.fs.get("cloudcache")))await DB.fs.put({id:"cloudcache",parent:"root",name:"Cloud Cache",type:"folder",mtime:Date.now()})},
  async open(a,it){await Cloud.ensureCache();UI.toast("Opening",it.name,"clouddrive");
    const d=await CloudAPI.download(a,it);const all=await DB.fs.children("cloudcache");const old=all.find(e=>e.cloud&&e.cloud.id===it.id&&e.cloud.acc===a.id);
    const now=Date.now();const e=old||{id:uid(),parent:"cloudcache",type:"file"};
    Object.assign(e,{name:d.name,mime:d.blob.type||guessMime(d.name),size:d.blob.size,mtime:now,blob:d.blob,cloud:{acc:a.id,id:it.id,drive:it.drive||null,parent:it.parentRef||null,name:it.name,exported:!!d.exported,web:it.web,syncedAt:now}});
    await _fsPut.call(DB.fs,e);
    if(isDocx(e)||isSheet(e)||isCode(e)||isText(e)||isImage(e)||/pdf$/i.test(e.mime)||/^(video|audio)\//.test(e.mime))return openEntry(e);
    const r=await UI.dialog({title:it.name,text:`Nimbus can't open this type of file (${esc(e.mime||"unknown")}).`,ok:"Open on the Web",cancel:"Save to Nimbus Files"});
    if(r)openInBrowser(it.web);else{await FS.addBlob("downloads",d.name,d.blob);UI.toast("Saved","Files › Downloads › "+d.name,"files")}},
  timers:{},
  queue(e){clearTimeout(Cloud.timers[e.id]);Cloud.timers[e.id]=setTimeout(()=>Cloud.sync(e.id),1200)},
  async sync(id){const e=await DB.fs.get(id);if(!e||!e.cloud)return;const a=mailAccounts().find(x=>x.id===e.cloud.acc);if(!a)return;const where=PROV[kindOf(a)].name;
    try{if(e.cloud.exported){const ok=await UI.confirm("Save a copy?",`“${e.cloud.name}” is a Google ${(e.name.endsWith(".xlsx")?"Sheet":"Doc")}. Nimbus will save your changes as “${e.name}” next to it in ${where}.`,"Save Copy");if(!ok)return;
        const parent=e.cloud.parent?{id:e.cloud.parent}:null;const made=await CloudAPI.create(a,parent,e.name,e.blob);e.cloud={...e.cloud,id:made.id,exported:false,name:e.name}}
      else await CloudAPI.update(a,{id:e.cloud.id,drive:e.cloud.drive},e.blob);
      e.cloud.syncedAt=Date.now()+1000;await _fsPut.call(DB.fs,e);UI.toast(`Saved to ${where}`,e.name,"clouddrive");WM.wins.filter(w=>w.app==="drive").forEach(w=>w.hooks.refresh&&w.hooks.refresh())}
    catch(err){if(err instanceof NeedAuth)UI.toast(`Couldn't save to ${where}`,`Sign in again: Files › ${where} › Reconnect. Your changes are kept in Nimbus.`,"clouddrive");else UI.toast(`Couldn't save to ${where}`,String(err.message||err).slice(0,120),"clouddrive")}}
};
const _fsPut=DB.fs.put;
DB.fs.put=async function(e){const r=await _fsPut.call(DB.fs,e);if(e&&e.cloud&&e.type==="file"&&e.blob&&e.mtime>(e.cloud.syncedAt||0)+500)Cloud.queue(e);return r};

/* ================= Cloud Drive window ================= */
const driveAccounts=()=>mailAccounts().filter(a=>kindOf(a));
APPS.drive={name:"Cloud Drive",icon:"clouddrive",w:960,h:620,
  create(w,opts){
    const st={acc:opts.acc||null,where:"files",path:[],items:[],view:"grid",sel:null,q:""};
    const accs=()=>driveAccounts();
    if(!st.acc){const c=accs().find(a=>hasDrive(a))||accs()[0];st.acc=c&&c.id}
    const A=()=>accs().find(a=>a.id===st.acc);
    w.tools.innerHTML=`<input class="field" data-q placeholder="Search" style="width:180px;padding:5px 10px" enterkeyhint="search">`;
    const qi=$("[data-q]",w.tools);qi.onkeydown=e=>{if(e.key==="Enter"){st.q=qi.value.trim();load()}};qi.oninput=()=>{if(!qi.value&&st.q){st.q="";load()}};
    const shell=()=>{w.body.innerHTML=`<div class="cd"><div class="sidebar" data-side></div><div class="main"><div class="toolbar"><button class="btn icon" data-a="back">${SVG.back}</button><div class="crumbs" data-crumbs></div>
        <button class="btn icon" data-a="view">${SVG.listv}</button><button class="btn icon" data-a="mkdir" title="New folder">${SVG.folderPlus}</button><button class="btn" data-a="upload">${SVG.share}Upload</button>
        <button class="btn icon" data-a="refresh" title="Refresh"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg></button></div>
        <div class="scroll" data-area></div><div class="toolbar muted" style="border-top:1px solid var(--hair);border-bottom:0;font-size:11.5px;justify-content:center" data-status></div></div></div>`;
      $$("[data-a]",w.body).forEach(b=>b.onclick=()=>action(b.dataset.a,b));
      const area=$("[data-area]",w.body);area.addEventListener("dragover",e=>{e.preventDefault();area.classList.add("dropzone")});area.addEventListener("dragleave",()=>area.classList.remove("dropzone"));
      area.addEventListener("drop",e=>{e.preventDefault();area.classList.remove("dropzone");const fl=[...(e.dataTransfer?.files||[])];if(fl.length)upload(fl)})};
    const drawSide=()=>{const side=$("[data-side]",w.body);if(!side)return;
      side.innerHTML=`<h5>Cloud</h5>${accs().map(a=>{const k=kindOf(a),act=a.id===st.acc;return `<div class="si ${act&&st.where==="files"&&!st.path.length?"act":""}" data-acc="${a.id}">${pbadge(k)}<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${PROV[k].short} · ${esc(accLabel(a))}</span></div>
          ${act&&hasDrive(a)?[["files",k==="g"?"My Drive":"My Files"],["recent","Recent"],["shared","Shared with me"],...(k==="g"?[["starred","Starred"]]:[])].map(([wh,l])=>`<div class="si sub ${st.where===wh?"act":""}" data-where="${wh}">${l}</div>`).join(""):""}`}).join("")||`<div class="muted" style="font-size:12px;padding:6px 8px">No Google or Microsoft accounts yet.</div>`}
        <div style="flex:1"></div><button class="btn addacc" data-adddrive>${SVG.plus} Add Google Drive / OneDrive</button><button class="btn addacc" data-local style="margin-top:0">Nimbus Files</button>`;
      $$("[data-acc]",side).forEach(s=>s.onclick=()=>{st.acc=s.dataset.acc;st.where="files";st.path=[];st.q="";qi.value="";drawSide();load()});
      $$("[data-where]",side).forEach(s=>s.onclick=()=>{st.where=s.dataset.where;st.path=[];st.q="";qi.value="";drawSide();load()});
      $("[data-adddrive]",side).onclick=addDrive;$("[data-local]",side).onclick=()=>WM.open("files")};
    const status=t=>{const s=$("[data-status]",w.body);if(s)s.textContent=t};
    const crumbs=()=>{const c=$("[data-crumbs]",w.body);if(!c)return;const a=A();const k=a&&kindOf(a);const root=st.q?`Search “${st.q}”`:st.where==="files"?(k==="g"?"My Drive":"My Files"):{recent:"Recent",shared:"Shared with me",starred:"Starred"}[st.where];
      c.innerHTML=[`<a data-i="-1">${esc(root||"")}</a>`,...st.path.map((p,i)=>`<a data-i="${i}">${esc(p.name)}</a>`)].join(`<span class="muted">›</span>`);
      $$("a",c).forEach(x=>x.onclick=()=>{st.path=st.path.slice(0,+x.dataset.i+1);load()});w.setTitle(a?`${PROV[k].name} — ${accLabel(a)}`:"Cloud Drive")};
    const banner=htmlStr=>{const area=$("[data-area]",w.body);area.innerHTML=`<div class="banner">${htmlStr}</div>`;return area};
    const load=async()=>{if(!$("[data-area]",w.body))shell();drawSide();crumbs();const a=A();const area=$("[data-area]",w.body);
      if(SANDBOXED){banner(`<h4>Cloud Drive needs the installed version</h4>This preview page can't connect to Google or Microsoft. Open Nimbus from your Home Screen.`);return}
      if(!a){const b=banner(`<h4>Add Google Drive or OneDrive</h4>Your Google and Microsoft accounts from Mail are used here. Add one to see your files inside Nimbus.<div style="margin-top:10px"><button class="btn primary" data-go>Add Account</button></div>`);$("[data-go]",b).onclick=addDrive;return}
      const k=kindOf(a);
      if(!MT.canConnect(a)){const b=banner(`<h4>One-time setup needed</h4>Register Nimbus with ${k==="g"?"Google":"Microsoft"} first (the same setup Mail uses). Add the <code>${k==="g"?"drive":"Files.ReadWrite.All"}</code> permission too.<div style="margin-top:10px"><button class="btn primary" data-go>Connection setup…</button></div>`);$("[data-go]",b).onclick=()=>setupSheet(w.el);return}
      if(!hasDrive(a)){const b=banner(`<h4>${MT.connected(a)?"Allow":"Connect"} ${PROV[k].name} for ${esc(accLabel(a))}</h4>${MT.connected(a)?"This account is connected for Mail. Sign in once more to also allow access to your files.":"Sign in once and your files appear here — open them in Nimbus apps and Save writes straight back."}
          <div style="margin-top:10px"><button class="btn primary" data-go>${MT.connected(a)?"Allow Drive access":"Connect"}</button></div><p class="muted" style="font-size:11.5px;margin:10px 0 0">If you set up Google/Microsoft before this update, also add the <code>${k==="g"?"drive":"Files.ReadWrite.All"}</code> permission in their console (see Mail › Connection setup › Show steps).</p>`);
        $("[data-go]",b).onclick=async()=>{await DB.set("oauth-reopen-app",{app:"drive",acc:a.id});connectAccount(a)};return}
      area.innerHTML=`<div class="loading"><div class="spin" style="width:24px;height:24px;border-radius:50%;border:2.5px solid var(--hair);border-top-color:var(--accent);animation:spin .8s linear infinite"></div></div>`;
      try{const folder=st.path[st.path.length-1]||null;st.items=await CloudAPI.list(a,st.path.length?"files":st.where,folder,st.q);st.items.forEach(it=>it.parentRef=folder?folder.id:null);draw()}
      catch(e){if(e instanceof NeedAuth){const b=banner(`<h4>Sign in again</h4>${esc(accLabel(a))}'s session has expired.<div style="margin-top:10px"><button class="btn primary" data-go>Reconnect</button></div>`);$("[data-go]",b).onclick=async()=>{await DB.set("oauth-reopen-app",{app:"drive",acc:a.id});connectAccount(a,{silent:true})};return}
        banner(`<h4>Couldn't load files</h4>${esc(String(e.message||e))}`)}};
    const icon=it=>{if(it.folder)return ICON.folder();const g=GNATIVE[it.mime];if(g)return letterIcon("gn"+g[3],g[3].slice(0,2),g[2])();return fileIcon({name:it.name,type:"file",mime:it.mime})};
    const draw=()=>{const area=$("[data-area]",w.body);const its=st.items;status(`${its.length} item${its.length===1?"":"s"}`);
      if(!its.length){area.innerHTML=`<div class="empty">${st.q?"No matches.":"This folder is empty."}<br>Tap <b>Upload</b> to add files from your iPad or Nimbus.</div>`;return}
      if(st.view==="grid")area.innerHTML=`<div class="grid">${its.map((it,i)=>`<div class="fi ${st.sel===it.id?"sel":""}" data-i="${i}" style="position:relative">${it.thumb&&/^image\//.test(it.mime)?`<img class="thumb" src="${esc(it.thumb)}" referrerpolicy="no-referrer" onerror="this.replaceWith(document.createRange().createContextualFragment(this.dataset.fb))" data-fb="${esc(icon(it))}">`:icon(it)}<span>${esc(it.name)}</span></div>`).join("")}</div>`;
      else area.innerHTML=`<div class="list"><div class="row hdr"><span></span><span>Name</span><span>Size</span><span>Modified</span></div>${its.map((it,i)=>`<div class="row ${st.sel===it.id?"sel":""}" data-i="${i}">${icon(it)}<span>${esc(it.name)}</span><span>${it.folder?"—":fmtSize(it.size)}</span><span>${it.mtime?fmtDate(it.mtime):""}</span></div>`).join("")}</div>`;
      $$("[data-i]",area).forEach(el=>{const it=its[+el.dataset.i];
        el.onclick=e=>{st.sel=it.id;$$("[data-i]",area).forEach(x=>x.classList.toggle("sel",x===el));if(e.pointerType==="touch"||e.detail>=2)openItem(it)};
        longPress(el,e=>itemMenu(it,e.clientX,e.clientY))})};
    const openItem=async it=>{const a=A();if(it.folder){st.path.push(it);st.sel=null;st.q="";qi.value="";load();return}
      try{await Cloud.open(a,it)}catch(e){if(e instanceof NeedAuth)return load();UI.toast("Couldn't open",String(e.message||e).slice(0,120),"clouddrive")}};
    const itemMenu=(it,x,y)=>{const a=A();UI.menu([{label:"Open",action:()=>openItem(it)},...(it.web?[{label:"Open on the Web",action:()=>openInBrowser(it.web)},{label:"Copy Link",action:()=>{try{navigator.clipboard.writeText(it.web);UI.toast("Link copied",it.name,"clouddrive")}catch(_){}}}]:[]),
      ...(it.folder?[]:[{label:"Save a Copy to Nimbus Files",action:async()=>{try{const d=await CloudAPI.download(a,it);await FS.addBlob("downloads",d.name,d.blob);UI.toast("Saved","Files › Downloads › "+d.name,"files")}catch(e){UI.toast("Couldn't download",String(e.message||e),"clouddrive")}}}]),"-",
      {label:"Rename…",action:async()=>{const n=await UI.prompt("Rename",it.name);if(n&&n!==it.name){try{await CloudAPI.rename(a,it,n);load()}catch(e){UI.toast("Couldn't rename",String(e.message||e),"clouddrive")}}}},
      {label:"Delete",action:async()=>{if(await UI.confirm(`Delete “${it.name}”?`,kindOf(a)==="g"?"It moves to your Google Drive trash.":"It moves to your OneDrive recycle bin.","Delete",true)){try{await CloudAPI.remove(a,it);load()}catch(e){UI.toast("Couldn't delete",String(e.message||e),"clouddrive")}}}}],x,y)};
    const upload=async files=>{const a=A();if(!a||!hasDrive(a))return;const parent=st.path[st.path.length-1]||null;let n=0;
      for(const f of files){try{UI.toast("Uploading",f.name,"clouddrive");await CloudAPI.create(a,parent,f.name,f);n++}catch(e){UI.toast("Upload failed",f.name+": "+String(e.message||e).slice(0,80),"clouddrive")}}
      if(n)UI.toast("Uploaded",`${n} file${n>1?"s":""} to ${PROV[kindOf(a)].name}`,"clouddrive");load()};
    const action=async(k,btn)=>{const a=A();
      if(k==="back"){if(st.path.length){st.path.pop();load()}else if(st.q){st.q="";qi.value="";load()}}
      if(k==="view"){st.view=st.view==="grid"?"list":"grid";draw()}
      if(k==="refresh")load();
      if(k==="mkdir"&&a&&hasDrive(a)){const n=await UI.prompt("New Folder","untitled folder");if(n){try{await CloudAPI.mkdir(a,st.path[st.path.length-1]||null,n);load()}catch(e){UI.toast("Couldn't create folder",String(e.message||e),"clouddrive")}}}
      if(k==="upload"&&a&&hasDrive(a)){const r=btn.getBoundingClientRect();UI.menu([{label:"From the iPad…",action:()=>pickFiles(upload)},
        {label:"From Nimbus Files…",action:async()=>{const all=(await DB.fs.all()).filter(x=>x.type==="file"&&x.parent!=="cloudcache").sort((p,q)=>q.mtime-p.mtime).slice(0,25);
          UI.menu(all.length?all.map(x=>({label:x.name,action:()=>upload([new File([x.blob],x.name,{type:x.mime||"application/octet-stream"})])})):[{label:"No files yet",disabled:true}],r.left,r.bottom+4)}}],r.left,r.bottom+4)}};
    const addDrive=async()=>{if(!MT.canConnect({provider:"gmail"})&&!MT.canConnect({provider:"outlook"}))return setupSheet(w.el);
      const candidates=accs().filter(a=>!hasDrive(a));
      UI.menu([...candidates.map(a=>({label:`${PROV[kindOf(a)].name} · ${a.email}`,action:async()=>{st.acc=a.id;await DB.set("oauth-reopen-app",{app:"drive",acc:a.id});connectAccount(a)}})),candidates.length?"-":null,
        {label:"Add a Google or Microsoft account…",action:()=>accountSheet(w.el,null,acc=>{if(acc&&kindOf(acc)){st.acc=acc.id;load()}})}].filter(Boolean),innerWidth/2-150,innerHeight/2-60)};
    shell();load();
    return {refresh:()=>{if(st.items)load()},reopenDrive(o){if(o&&o.acc){st.acc=o.acc;st.where="files";st.path=[];load()}}}},
  reopen(w,o){w.hooks.reopenDrive&&w.hooks.reopenDrive(o)}
};

/* ================= Files sidebar: Cloud shortcuts ================= */
const _filesCreate=APPS.files.create;
APPS.files.create=function(w,opts){const hooks=_filesCreate(w,opts);const side=$(".sidebar",w.body);if(!side)return hooks;
  const box=html(`<div data-cloud></div>`);const loc=$$("h5",side).find(h=>/Locations/i.test(h.textContent));side.insertBefore(box,loc||null);
  const draw=()=>{const accs=driveAccounts();box.innerHTML=`<h5>Cloud</h5>${accs.map(a=>`<div class="si" data-cacc="${a.id}">${pbadge(kindOf(a)).replace('class="pb"','class="pb" style="width:16px;height:16px;border-radius:4px;color:#fff;font-size:9px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;background:'+PROV[kindOf(a)].color+'"')}${PROV[kindOf(a)].short} · ${esc(accLabel(a))}</div>`).join("")}
    <div class="si" data-cadd>${SVG.plus.replace("<svg",'<svg style="color:var(--accent)"')}Google Drive / OneDrive…</div>`;
    $$("[data-cacc]",box).forEach(s=>s.onclick=()=>WM.open("drive",{acc:s.dataset.cacc}));$("[data-cadd]",box).onclick=()=>WM.open("drive")};draw();return hooks};
/* upload a Nimbus file to the cloud from its menu */
const _fileMenu3=fileMenu;
fileMenu=async function(id,x,y,after){await _fileMenu3(id,x,y,after);const e=await DB.fs.get(id);const m=$(".menu");if(!m||!e||e.type!=="file")return;const accs=driveAccounts().filter(hasDrive);if(!accs.length)return;
  const it=html(`<div class="it"><span>Upload to Cloud…</span></div>`);it.onclick=ev=>{ev.stopPropagation();UI.closeMenus();
    UI.menu(accs.map(a=>({label:`${PROV[kindOf(a)].name} · ${accLabel(a)}`,action:async()=>{try{UI.toast("Uploading",e.name,"clouddrive");await CloudAPI.create(a,null,e.name,e.blob);UI.toast("Uploaded",`${e.name} → ${PROV[kindOf(a)].name}`,"clouddrive")}catch(err){UI.toast("Upload failed",String(err.message||err).slice(0,100),"clouddrive")}}})),x,y)};
  m.insertBefore(it,m.children[2]||null)};

/* ================= Viewer: PDF, video, audio ================= */
APPS.viewer={name:"Viewer",icon:"viewer",w:820,h:680,hidden:true,
  create(w,opts){let url=null,zoom=1,pdf=null;
    const close=()=>{url&&URL.revokeObjectURL(url)};
    (async()=>{const e=await DB.fs.get(opts.id);if(!e)return;w.setTitle(e.name);url=URL.createObjectURL(e.blob);
      if(/^(video|audio)\//.test(e.mime||"")){const tag=e.mime.startsWith("video/")?"video":"audio";
        w.body.innerHTML=`<div class="vw"><div class="toolbar" style="background:var(--win-bg)"><span class="muted">${fmtSize(e.size)}</span><button class="btn icon" data-sh style="margin-left:auto">${SVG.share}</button></div><div class="media"><${tag} controls playsinline webkit-playsinline src="${url}" ${tag==="video"?'disablepictureinpicture':""}></${tag}></div></div>`;
        $("[data-sh]",w.body).onclick=()=>shareFile(e);return}
      w.body.innerHTML=`<div class="vw"><div class="toolbar" style="background:var(--win-bg)"><span class="muted" data-info>Loading…</span><span style="flex:1"></span><button class="btn icon" data-z="-">−</button><button class="btn icon" data-z="+">+</button><button class="btn icon" data-sh>${SVG.share}</button></div><div class="pages" data-pages></div></div>`;
      $("[data-sh]",w.body).onclick=()=>shareFile(e);
      try{const lib=await import(new URL("lib/pdfjs/pdf.min.mjs",location.href).href);lib.GlobalWorkerOptions.workerSrc=new URL("lib/pdfjs/pdf.worker.min.mjs",location.href).href;
        pdf=await lib.getDocument({data:new Uint8Array(await e.blob.arrayBuffer())}).promise;$("[data-info]",w.body).textContent=`${pdf.numPages} page${pdf.numPages>1?"s":""} · ${fmtSize(e.size)}`;render()}
      catch(err){$("[data-pages]",w.body).innerHTML=`<div class="empty" style="color:#fff">Couldn't show this PDF: ${esc(err.message||err)}</div>`}
      $$("[data-z]",w.body).forEach(b=>b.onclick=()=>{zoom=Math.max(.5,Math.min(3,zoom*(b.dataset.z==="+"?1.25:.8)));render()})})();
    let renderId=0;
    const render=async()=>{if(!pdf)return;const id=++renderId;const box=$("[data-pages]",w.body);box.innerHTML="";const width=box.clientWidth-40;
      for(let n=1;n<=pdf.numPages;n++){if(id!==renderId)return;const page=await pdf.getPage(n);const v1=page.getViewport({scale:1});const scale=Math.max(.3,width/v1.width)*zoom;const vp=page.getViewport({scale:scale*Math.min(2,devicePixelRatio||1)});
        const c=document.createElement("canvas");c.width=vp.width;c.height=vp.height;c.style.width=(vp.width/Math.min(2,devicePixelRatio||1))+"px";box.appendChild(c);
        await page.render({canvasContext:c.getContext("2d"),viewport:vp}).promise}};
    return {close,resize(){clearTimeout(w._rz);w._rz=setTimeout(render,250)}}}
};
const _openEntry3=openEntry;
openEntry=async function(e){if(e&&e.type==="file"&&(/pdf$/i.test(e.mime||"")||/\.pdf$/i.test(e.name)||/^(video|audio)\//.test(e.mime||"")))return WM.open("viewer",{id:e.id});return _openEntry3(e)};
